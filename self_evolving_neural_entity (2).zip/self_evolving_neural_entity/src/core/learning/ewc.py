# src/core/learning/ewc.py
import torch
import torch.nn as nn
import numpy as np
from collections import OrderedDict

class EWC:
    """
    Elastic Weight Consolidation - Prevents catastrophic forgetting in neural networks.
    
    Based on: "Overcoming catastrophic forgetting in neural networks" 
    by Kirkpatrick et al. (2017)
    """
    
    def __init__(self, model: nn.Module, importance=1000.0):
        self.model = model
        self.importance = importance
        self.registered_params = OrderedDict()  # Stores Fisher matrix and optimal weights
        self.task_count = 0
        
    def register_important_weights(self, dataset, num_samples=100):
        """
        Register current neural weights as important for the current task.
        
        Args:
            dataset: Dataset from the current task
            num_samples: Number of samples to use for Fisher information calculation
        """
        self.task_count += 1
        task_key = f"task_{self.task_count}"
        
        print(f"🔐 Registering weights for {task_key} with EWC...")
        
        # Store current optimal parameters
        optimal_params = {}
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                optimal_params[name] = param.data.clone()
        
        # Compute Fisher information matrix
        fisher_matrix = self._compute_fisher_matrix(dataset, num_samples)
        
        # Store both Fisher and optimal parameters
        self.registered_params[task_key] = {
            'fisher': fisher_matrix,
            'optimal_params': optimal_params,
            'num_samples': num_samples,
            'timestamp': torch.tensor(0.0)  # Could store actual timestamp
        }
        
        print(f"✅ Registered {len(optimal_params)} parameter groups for {task_key}")
    
    def _compute_fisher_matrix(self, dataset, num_samples):
        """Compute Fisher information matrix for importance weighting"""
        fisher_matrix = OrderedDict()
        
        # Initialize Fisher matrices
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                fisher_matrix[name] = torch.zeros_like(param)
        
        # Store original mode
        original_mode = self.model.training
        self.model.eval()
        
        # Sample from dataset to compute Fisher information
        sample_count = min(num_samples, len(dataset))
        if sample_count == 0:
            return fisher_matrix
            
        for i in range(sample_count):
            # Get sample (handle different dataset formats)
            if hasattr(dataset, '__getitem__'):
                data = dataset[i]
                if isinstance(data, (tuple, list)):
                    data = data[0]  # Assume first element is input
            else:
                # For reinforcement learning environments
                data = torch.FloatTensor(dataset.reset())
            
            self.model.zero_grad()
            
            # Forward pass
            output = self.model(data)
            
            # For Fisher, we need a loss that represents the task
            # Use negative log likelihood of current output distribution
            if output.dim() == 1:
                output = output.unsqueeze(0)
                
            # Create a dummy target based on current predictions
            with torch.no_grad():
                fake_target = torch.softmax(output, dim=-1)
            
            # Compute loss and gradients
            loss = -torch.sum(fake_target * torch.log_softmax(output, dim=-1))
            loss.backward()
            
            # Accumulate squared gradients (Fisher information approximation)
            for name, param in self.model.named_parameters():
                if param.grad is not None:
                    fisher_matrix[name] += param.grad.data.pow(2) / sample_count
        
        self.model.train(original_mode)
        return fisher_matrix
    
    def compute_penalty(self):
        """
        Compute EWC penalty loss to prevent forgetting of previous tasks.
        
        Returns:
            ewc_loss: Penalty term to add to main loss function
        """
        if not self.registered_params:
            return torch.tensor(0.0)
        
        ewc_loss = torch.tensor(0.0)
        
        for task_key, task_data in self.registered_params.items():
            fisher_matrix = task_data['fisher']
            optimal_params = task_data['optimal_params']
            
            for name, param in self.model.named_parameters():
                if name in fisher_matrix and name in optimal_params:
                    fisher = fisher_matrix[name]
                    optimal = optimal_params[name]
                    ewc_loss += (fisher * (param - optimal).pow(2)).sum()
        
        return self.importance * ewc_loss
    
    def get_memory_usage(self):
        """Get information about EWC memory usage"""
        total_params = 0
        for task_data in self.registered_params.values():
            for param in task_data['optimal_params'].values():
                total_params += param.numel()
        
        return {
            'tasks_registered': len(self.registered_params),
            'total_parameters_stored': total_params,
            'memory_mb_approx': (total_params * 4) / (1024 * 1024),  # Assuming float32
            'importance_factor': self.importance
        }
    
    def forget_task(self, task_key=None):
        """Forget a specific task or the oldest task"""
        if not self.registered_params:
            return False, "No tasks registered"
        
        if task_key is None:
            # Remove oldest task
            task_key = next(iter(self.registered_params.keys()))
        
        if task_key in self.registered_params:
            del self.registered_params[task_key]
            return True, f"Forgot task: {task_key}"
        else:
            return False, f"Task {task_key} not found"