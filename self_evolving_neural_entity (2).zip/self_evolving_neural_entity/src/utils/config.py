# src/utils/config.py
import yaml
import json
import os
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from pathlib import Path

@dataclass
class SENEConfig:
    """
    Configuration dataclass for Self-Evolving Neural Entity.
    
    Contains all configurable parameters for the SENE system.
    """
    
    # Core System Configuration
    system_name: str = "Self-Evolving Neural Entity"
    version: str = "1.0.0"
    debug_mode: bool = False
    log_level: str = "INFO"
    
    # Neural Network Configuration
    input_dim: int = 4
    hidden_dims: List[int] = None
    output_dim: int = 2
    learning_rate: float = 1e-3
    activation_function: str = "relu"
    
    # Evolution Configuration
    evolution_strategy: str = "balanced"  # conservative, balanced, aggressive
    mutation_rate: float = 0.3
    max_layers: int = 10
    min_layers: int = 1
    max_neurons_per_layer: int = 512
    
    # Training Configuration
    training_episodes: int = 1000
    batch_size: int = 32
    replay_buffer_size: int = 10000
    update_frequency: int = 4
    
    # Safety Configuration
    safety_enabled: bool = True
    max_parameter_count: int = 1000000
    stability_threshold: float = 0.6
    performance_threshold: float = 0.3
    auto_rollback: bool = True
    
    # Voice Interaction Configuration
    wake_word: str = "sene"
    speech_rate: int = 150
    speech_volume: float = 0.8
    energy_threshold: int = 300
    
    # Memory Configuration
    max_conversation_memory: int = 10000
    max_decision_logs: int = 5000
    context_window_tokens: int = 4000
    
    # Internet Access Configuration
    allowed_domains: List[str] = None
    daily_request_limit: int = 100
    request_timeout: int = 10
    
    # Application Configuration
    default_environment: str = "cartpole"
    auto_save_interval: int = 100  # episodes
    
    def __post_init__(self):
        """Initialize default values for lists."""
        if self.hidden_dims is None:
            self.hidden_dims = [64, 64]
        if self.allowed_domains is None:
            self.allowed_domains = [
                'arxiv.org', 'pytorch.org', 'github.com', 
                'towardsdatascience.com', 'keras.io'
            ]

class ConfigManager:
    """
    Configuration manager for loading, saving, and managing SENE configurations.
    """
    
    def __init__(self, config_dir: str = "configs"):
        self.config_dir = Path(config_dir)
        self.config_dir.mkdir(exist_ok=True)
        
        self.default_config = SENEConfig()
        self.current_config = self.default_config
        self.config_history = []
        
        print(f"⚙️  Config Manager initialized (config dir: {self.config_dir})")
    
    def load_config(self, config_name: str = "default") -> SENEConfig:
        """
        Load configuration from file.
        
        Args:
            config_name: Name of the configuration file (without extension)
            
        Returns:
            config: Loaded configuration object
        """
        config_path = self.config_dir / f"{config_name}.yaml"
        
        if not config_path.exists():
            print(f"📝 Config file not found: {config_path}. Using defaults.")
            return self.default_config
        
        try:
            with open(config_path, 'r') as f:
                config_data = yaml.safe_load(f)
            
            # Convert dict to SENEConfig
            config_dict = asdict(self.default_config)
            config_dict.update(config_data)
            
            self.current_config = SENEConfig(**config_dict)
            self.config_history.append(('load', config_name, config_path))
            
            print(f"✅ Loaded configuration: {config_name}")
            return self.current_config
            
        except Exception as e:
            print(f"❌ Error loading config {config_name}: {e}")
            return self.default_config
    
    def save_config(self, config: SENEConfig, config_name: str = "default") -> bool:
        """
        Save configuration to file.
        
        Args:
            config: Configuration object to save
            config_name: Name for the configuration file
            
        Returns:
            success: Whether save was successful
        """
        config_path = self.config_dir / f"{config_name}.yaml"
        
        try:
            config_dict = asdict(config)
            
            with open(config_path, 'w') as f:
                yaml.dump(config_dict, f, default_flow_style=False, indent=2)
            
            self.config_history.append(('save', config_name, config_path))
            self.current_config = config
            
            print(f"💾 Saved configuration: {config_name}")
            return True
            
        except Exception as e:
            print(f"❌ Error saving config {config_name}: {e}")
            return False
    
    def create_preset(self, preset_name: str, **kwargs) -> SENEConfig:
        """
        Create a configuration preset with specific settings.
        
        Args:
            preset_name: Name of the preset
            **kwargs: Configuration parameters to override
            
        Returns:
            config: New configuration preset
        """
        config_dict = asdict(self.default_config)
        config_dict.update(kwargs)
        
        preset_config = SENEConfig(**config_dict)
        
        # Save the preset
        self.save_config(preset_config, preset_name)
        
        print(f"🎛️  Created preset: {preset_name}")
        return preset_config
    
    def list_configs(self) -> List[str]:
        """List all available configuration files."""
        config_files = list(self.config_dir.glob("*.yaml"))
        return [f.stem for f in config_files]
    
    def get_preset(self, preset_type: str) -> SENEConfig:
        """
        Get a predefined configuration preset.
        
        Args:
            preset_type: Type of preset ('conservative', 'balanced', 'aggressive', 'research')
            
        Returns:
            config: Preset configuration
        """
        presets = {
            'conservative': {
                'evolution_strategy': 'conservative',
                'mutation_rate': 0.1,
                'safety_enabled': True,
                'max_layers': 6
            },
            'balanced': {
                'evolution_strategy': 'balanced', 
                'mutation_rate': 0.3,
                'safety_enabled': True,
                'max_layers': 10
            },
            'aggressive': {
                'evolution_strategy': 'aggressive',
                'mutation_rate': 0.5,
                'safety_enabled': False,
                'max_layers': 15
            },
            'research': {
                'evolution_strategy': 'balanced',
                'training_episodes': 5000,
                'max_layers': 20,
                'allowed_domains': [
                    'arxiv.org', 'paperswithcode.com', 'research.google',
                    'openreview.net', 'distill.pub'
                ]
            }
        }
        
        if preset_type not in presets:
            print(f"❌ Unknown preset: {preset_type}. Using balanced.")
            preset_type = 'balanced'
        
        return self.create_preset(preset_type, **presets[preset_type])
    
    def validate_config(self, config: SENEConfig) -> Dict[str, List[str]]:
        """
        Validate configuration for consistency and safety.
        
        Args:
            config: Configuration to validate
            
        Returns:
            validation_results: Dictionary of validation results
        """
        issues = {'warnings': [], 'errors': []}
        
        # Neural network validation
        if config.input_dim <= 0:
            issues['errors'].append("Input dimension must be positive")
        if config.output_dim <= 0:
            issues['errors'].append("Output dimension must be positive")
        if any(dim <= 0 for dim in config.hidden_dims):
            issues['errors'].append("All hidden dimensions must be positive")
        
        # Evolution validation
        if not 0 <= config.mutation_rate <= 1:
            issues['errors'].append("Mutation rate must be between 0 and 1")
        if config.max_layers < config.min_layers:
            issues['errors'].append("Max layers cannot be less than min layers")
        
        # Safety validation
        if config.max_parameter_count > 10000000:  # 10M parameters
            issues['warnings'].append("Very high parameter count limit")
        if config.mutation_rate > 0.8 and config.safety_enabled:
            issues['warnings'].append("High mutation rate with safety enabled")
        
        # Training validation
        if config.batch_size <= 0:
            issues['errors'].append("Batch size must be positive")
        if config.replay_buffer_size < config.batch_size:
            issues['warnings'].append("Replay buffer smaller than batch size")
        
        return issues
    
    def export_config(self, config: SENEConfig, filepath: str, format: str = 'json') -> bool:
        """
        Export configuration to various formats.
        
        Args:
            config: Configuration to export
            filepath: Output file path
            format: Export format ('json', 'yaml', 'txt')
            
        Returns:
            success: Whether export was successful
        """
        try:
            config_dict = asdict(config)
            
            if format == 'json':
                with open(filepath, 'w') as f:
                    json.dump(config_dict, f, indent=2)
            elif format == 'yaml':
                with open(filepath, 'w') as f:
                    yaml.dump(config_dict, f, default_flow_style=False, indent=2)
            elif format == 'txt':
                with open(filepath, 'w') as f:
                    for key, value in config_dict.items():
                        f.write(f"{key}: {value}\n")
            else:
                print(f"❌ Unsupported format: {format}")
                return False
            
            print(f"📤 Exported config to: {filepath} ({format})")
            return True
            
        except Exception as e:
            print(f"❌ Export failed: {e}")
            return False
    
    def get_config_info(self, config: SENEConfig) -> Dict[str, Any]:
        """Get comprehensive information about a configuration."""
        config_dict = asdict(config)
        validation = self.validate_config(config)
        
        return {
            'parameters': config_dict,
            'validation': validation,
            'estimated_parameters': self._estimate_network_parameters(config),
            'compatibility': self._check_compatibility(config)
        }
    
    def _estimate_network_parameters(self, config: SENEConfig) -> int:
        """Estimate total parameters for the neural network."""
        layers = [config.input_dim] + config.hidden_dims + [config.output_dim]
        total_params = 0
        
        for i in range(len(layers) - 1):
            # Weights + biases
            total_params += layers[i] * layers[i + 1] + layers[i + 1]
        
        return total_params
    
    def _check_compatibility(self, config: SENEConfig) -> Dict[str, bool]:
        """Check configuration compatibility with system capabilities."""
        return {
            'neural_network': config.input_dim > 0 and config.output_dim > 0,
            'evolution': 0 <= config.mutation_rate <= 1,
            'training': config.batch_size > 0 and config.training_episodes > 0,
            'memory': config.max_conversation_memory > 0,
            'safety': config.stability_threshold > 0
        }