# src/environments/__init__.py
"""
Environment modules for the Self-Evolving Neural Entity.

This module contains various training environments and simulation frameworks
where the neural network can learn, test, and evolve its capabilities.
"""

from .base_env import BaseEnvironment
from .cartpole import CartPoleEnvironment

__all__ = [
    'BaseEnvironment',
    'CartPoleEnvironment'
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Training environments for neural network learning and evolution'

print("🎮 SENE Environments module loaded - Training environments ready")