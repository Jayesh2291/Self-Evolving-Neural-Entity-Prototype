# src/interaction/internet_tools/data_scraper.py
import requests
import pandas as pd
import json
import time
from typing import Dict, List, Optional, Any
from datetime import datetime
import re

from self_evolving_neural_entity.src.interaction.internet_tools.safe_browser import SafeBrowser

class DataScraper:
    """
    Safe data scraper for gathering training data and information.
    
    Provides controlled data collection capabilities for
    enhancing the SENE system's knowledge and training data.
    """
    
    def __init__(self):
        self.browser = SafeBrowser()
        self.scraping_history = []
        self.data_sources = {
            'weather': 'https://api.weather.gov/',
            'financial': 'https://api.polygon.io/',
            'news': 'https://newsapi.org/',
            'academic': 'http://api.semanticscholar.org/'
        }
        
        # Data patterns for different types of information
        self.data_patterns = {
            'numerical_data': r'\b\d+\.?\d*\b',
            'dates': r'\b\d{4}-\d{2}-\d{2}\b',
            'urls': r'https?://[^\s]+',
            'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        }
        
        print("📊 Data Scraper initialized")
    
    def scrape_web_data(self, url: str, data_type: str = 'text') -> Optional[Dict[str, Any]]:
        """
        Safely scrape data from a webpage.
        
        Args:
            url: URL to scrape
            data_type: Type of data to extract
            
        Returns:
            scraped_data: Structured scraped data
        """
        print(f"📊 Scraping {data_type} data from: {url}")
        
        response = self.browser.safe_get(url)
        if not response:
            return None
        
        try:
            if data_type == 'text':
                return self._extract_text_data(response.text, url)
            elif data_type == 'tabular':
                return self._extract_tabular_data(response.text, url)
            elif data_type == 'structured':
                return self._extract_structured_data(response.text, url)
            else:
                print(f"❌ Unknown data type: {data_type}")
                return None
                
        except Exception as e:
            print(f"❌ Data scraping error: {e}")
            return None
    
    def _extract_text_data(self, html: str, url: str) -> Dict[str, Any]:
        """Extract text data from HTML content."""
        from bs4 import BeautifulSoup
        
        soup = BeautifulSoup(html, 'html.parser')
        
        # Remove script and style elements
        for script in soup(["script", "style"]):
            script.decompose()
        
        # Get text and clean it
        text = soup.get_text()
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        text = ' '.join(chunk for chunk in chunks if chunk)
        
        # Extract patterns
        patterns_found = {}
        for pattern_name, pattern in self.data_patterns.items():
            matches = re.findall(pattern, text)
            patterns_found[pattern_name] = matches[:10]  # Limit matches
        
        # Extract key sections (simplified)
        title = soup.title.string.strip() if soup.title else 'No title'
        paragraphs = [p.get_text().strip() for p in soup.find_all('p')][:5]
        
        result = {
            'url': url,
            'title': title,
            'text_content': text[:1000] + '...' if len(text) > 1000 else text,
            'paragraph_count': len(paragraphs),
            'sample_paragraphs': paragraphs,
            'patterns_found': patterns_found,
            'timestamp': datetime.now().isoformat(),
            'data_type': 'text'
        }
        
        self._record_scraping_session(url, 'text', result)
        return result
    
    def _extract_tabular_data(self, html: str, url: str) -> Optional[Dict[str, Any]]:
        """Extract tabular data from HTML content."""
        try:
            # Try to find tables using pandas
            tables = pd.read_html(html)
            
            table_data = []
            for i, table in enumerate(tables):
                table_info = {
                    'table_index': i,
                    'shape': table.shape,
                    'columns': table.columns.tolist(),
                    'sample_data': table.head(3).to_dict('records'),
                    'data_types': table.dtypes.astype(str).to_dict()
                }
                table_data.append(table_info)
            
            result = {
                'url': url,
                'tables_found': len(tables),
                'table_data': table_data,
                'timestamp': datetime.now().isoformat(),
                'data_type': 'tabular'
            }
            
            self._record_scraping_session(url, 'tabular', result)
            return result
            
        except Exception as e:
            print(f"❌ No tables found or error: {e}")
            return None
    
    def _extract_structured_data(self, html: str, url: str) -> Dict[str, Any]:
        """Extract structured data from HTML content."""
        from bs4 import BeautifulSoup
        
        soup = BeautifulSoup(html, 'html.parser')
        
        # Look for JSON-LD structured data
        structured_data = []
        script_tags = soup.find_all('script', type='application/ld+json')
        
        for script in script_tags:
            try:
                data = json.loads(script.string)
                structured_data.append(data)
            except:
                pass
        
        # Extract meta tags
        meta_tags = {}
        for meta in soup.find_all('meta'):
            name = meta.get('name') or meta.get('property')
            content = meta.get('content')
            if name and content:
                meta_tags[name] = content
        
        result = {
            'url': url,
            'structured_data_found': len(structured_data),
            'structured_data': structured_data[:3],  # Limit
            'meta_tags': meta_tags,
            'timestamp': datetime.now().isoformat(),
            'data_type': 'structured'
        }
        
        self._record_scraping_session(url, 'structured', result)
        return result
    
    def _record_scraping_session(self, url: str, data_type: str, result: Dict):
        """Record scraping session for history."""
        session = {
            'timestamp': datetime.now().isoformat(),
            'url': url,
            'data_type': data_type,
            'success': bool(result),
            'data_points': len(result.get('text_content', '')) if data_type == 'text' else 
                          result.get('tables_found', 0) if data_type == 'tabular' else
                          result.get('structured_data_found', 0)
        }
        
        self.scraping_history.append(session)
    
    def scrape_multiple_sources(self, urls: List[str], data_type: str = 'text') -> List[Dict[str, Any]]:
        """
        Scrape data from multiple sources.
        
        Args:
            urls: List of URLs to scrape
            data_type: Type of data to extract
            
        Returns:
            all_data: List of scraped data from all sources
        """
        all_data = []
        
        for url in urls:
            data = self.scrape_web_data(url, data_type)
            if data:
                all_data.append(data)
            
            # Be respectful with requests
            time.sleep(1)
        
        print(f"✅ Scraped {len(all_data)} out of {len(urls)} sources")
        return all_data
    
    def get_training_data(self, topic: str, sample_size: int = 10) -> Optional[Dict[str, Any]]:
        """
        Get training data for a specific topic.
        
        Args:
            topic: Topic to get data for
            sample_size: Number of data points to gather
            
        Returns:
            training_data: Structured training data
        """
        print(f"📊 Gathering training data for: {topic}")
        
        # Generate search URLs based on topic
        search_urls = self._generate_training_urls(topic, sample_size)
        
        # Scrape data from generated URLs
        scraped_data = self.scrape_multiple_sources(search_urls, 'text')
        
        if not scraped_data:
            return None
        
        # Process and structure the data
        processed_data = self._process_training_data(scraped_data, topic)
        
        return processed_data
    
    def _generate_training_urls(self, topic: str, sample_size: int) -> List[str]:
        """
        Generate URLs for training data collection.
        
        Args:
            topic: Data topic
            sample_size: Number of URLs to generate
            
        Returns:
            urls: List of URLs to scrape
        """
        # This is a simplified implementation
        # In practice, you'd use search APIs or curated sources
        
        base_urls = [
            f"https://en.wikipedia.org/wiki/{topic.replace(' ', '_')}",
            f"https://towardsdatascience.com/tagged/{topic.replace(' ', '-')}",
            f"https://arxiv.org/search/?query={topic.replace(' ', '+')}&searchtype=all&source=header"
        ]
        
        # For demo purposes, return base URLs
        return base_urls[:min(sample_size, len(base_urls))]
    
    def _process_training_data(self, scraped_data: List[Dict], topic: str) -> Dict[str, Any]:
        """
        Process scraped data into training format.
        
        Args:
            scraped_data: Raw scraped data
            topic: Data topic
            
        Returns:
            training_data: Processed training data
        """
        # Combine all text content
        all_text = ' '.join([data.get('text_content', '') for data in scraped_data])
        
        # Extract features (simplified)
        word_count = len(all_text.split())
        unique_words = len(set(all_text.lower().split()))
        data_points = sum(len(data.get('text_content', '')) for data in scraped_data)
        
        # Create training samples (simplified)
        samples = []
        for data in scraped_data[:5]:  # Limit samples
            text = data.get('text_content', '')[:500]  # Truncate
            if text:
                samples.append({
                    'text': text,
                    'source': data.get('url', ''),
                    'length': len(text)
                })
        
        return {
            'topic': topic,
            'total_data_points': data_points,
            'word_count': word_count,
            'unique_words': unique_words,
            'samples': samples,
            'sources_used': [data.get('url') for data in scraped_data],
            'timestamp': datetime.now().isoformat(),
            'data_quality': 'medium'  # Could be calculated based on content
        }
    
    def get_scraping_stats(self) -> Dict[str, Any]:
        """Get data scraping statistics."""
        successful_scrapes = sum(1 for session in self.scraping_history if session['success'])
        total_data_points = sum(session['data_points'] for session in self.scraping_history)
        
        # Count by data type
        type_counts = {}
        for session in self.scraping_history:
            data_type = session['data_type']
            type_counts[data_type] = type_counts.get(data_type, 0) + 1
        
        return {
            'total_scraping_sessions': len(self.scraping_history),
            'successful_scrapes': successful_scrapes,
            'success_rate': f"{(successful_scrapes/len(self.scraping_history)*100) if self.scraping_history else 0:.1f}%",
            'total_data_points_collected': total_data_points,
            'data_type_breakdown': type_counts,
            'browser_stats': self.browser.get_browser_stats()
        }