# src/interaction/command_parser/action_mapping.py
from typing import Dict, List, Any, Optional
from datetime import datetime

class ActionMapper:
    """
    Maps recognized intents to concrete system actions.
    
    This class translates high-level intents into specific
    function calls and parameter configurations.
    """
    
    def __init__(self):
        self.action_map = self._initialize_action_map()
        self.action_history = []
        
        print("🔄 Action Mapper initialized")
    
    def _initialize_action_map(self) -> Dict[str, Dict[str, Any]]:
        """Initialize the mapping from intents to system actions."""
        return {
            # Architecture Evolution Actions
            'evolution_add_layer': {
                'function': 'add_neural_layer',
                'parameters': {'size': 'auto', 'position': 'end'},
                'risk_level': 'low',
                'requires_approval': False,
                'description': 'Add a new hidden layer to the neural network'
            },
            'evolution_remove_layer': {
                'function': 'remove_neural_layer', 
                'parameters': {'position': 'auto'},
                'risk_level': 'medium',
                'requires_approval': True,
                'description': 'Remove a hidden layer from the neural network'
            },
            'evolution_change_architecture': {
                'function': 'modify_architecture',
                'parameters': {'change_type': 'optimize'},
                'risk_level': 'medium',
                'requires_approval': True,
                'description': 'Change the neural network architecture'
            },
            
            # Training Actions
            'start_training': {
                'function': 'start_training_session',
                'parameters': {'environment': 'cartpole', 'episodes': 1000},
                'risk_level': 'low',
                'requires_approval': False,
                'description': 'Start training the neural network'
            },
            'stop_training': {
                'function': 'stop_training_session',
                'parameters': {},
                'risk_level': 'low', 
                'requires_approval': False,
                'description': 'Stop current training session'
            },
            'reset_training': {
                'function': 'reset_training_progress',
                'parameters': {'keep_architecture': True},
                'risk_level': 'medium',
                'requires_approval': True,
                'description': 'Reset training progress'
            },
            
            # Evolution Actions
            'trigger_evolution': {
                'function': 'trigger_evolution_cycle',
                'parameters': {'strategy': 'auto'},
                'risk_level': 'medium',
                'requires_approval': False,
                'description': 'Trigger neural network evolution'
            },
            'auto_evolve': {
                'function': 'enable_auto_evolution',
                'parameters': {'frequency': 'continuous'},
                'risk_level': 'high',
                'requires_approval': True,
                'description': 'Enable automatic evolution mode'
            },
            
            # Information Actions
            'get_network_info': {
                'function': 'get_network_information',
                'parameters': {'detail_level': 'full'},
                'risk_level': 'none',
                'requires_approval': False,
                'description': 'Get neural network architecture information'
            },
            'get_status': {
                'function': 'get_system_status',
                'parameters': {'include_performance': True},
                'risk_level': 'none',
                'requires_approval': False,
                'description': 'Get current system status'
            },
            'get_performance': {
                'function': 'get_performance_metrics',
                'parameters': {'trends': True},
                'risk_level': 'none',
                'requires_approval': False,
                'description': 'Get performance metrics and trends'
            },
            
            # Research Actions
            'research': {
                'function': 'conduct_research',
                'parameters': {'source': 'auto', 'depth': 'standard'},
                'risk_level': 'low',
                'requires_approval': False,
                'description': 'Research information online'
            },
            
            # Application Actions
            'create_application': {
                'function': 'create_application',
                'parameters': {'type': 'auto'},
                'risk_level': 'medium',
                'requires_approval': True,
                'description': 'Create a new application instance'
            },
            'run_application': {
                'function': 'run_application',
                'parameters': {'application': 'current'},
                'risk_level': 'low',
                'requires_approval': False,
                'description': 'Run an existing application'
            },
            
            # Safety Actions
            'emergency_stop': {
                'function': 'emergency_stop',
                'parameters': {'level': 'immediate'},
                'risk_level': 'none',
                'requires_approval': False,
                'description': 'Immediately stop all operations'
            },
            'enable_safety': {
                'function': 'set_safety_mode',
                'parameters': {'enabled': True},
                'risk_level': 'none',
                'requires_approval': False,
                'description': 'Enable safety protocols'
            },
            'disable_safety': {
                'function': 'set_safety_mode',
                'parameters': {'enabled': False},
                'risk_level': 'high',
                'requires_approval': True,
                'description': 'Disable safety protocols (expert mode)'
            },
            
            # Configuration Actions
            'change_strategy': {
                'function': 'set_evolution_strategy',
                'parameters': {'strategy': 'auto'},
                'risk_level': 'low',
                'requires_approval': False,
                'description': 'Change evolution strategy'
            },
            'set_preference': {
                'function': 'set_user_preferences',
                'parameters': {'preferences': 'auto'},
                'risk_level': 'low',
                'requires_approval': False,
                'description': 'Set user preferences'
            },
            
            # Memory Actions
            'show_memory': {
                'function': 'show_conversation_memory',
                'parameters': {'limit': 10},
                'risk_level': 'none',
                'requires_approval': False,
                'description': 'Show conversation history'
            },
            'clear_memory': {
                'function': 'clear_conversation_memory',
                'parameters': {'confirm': True},
                'risk_level': 'medium',
                'requires_approval': True,
                'description': 'Clear conversation history'
            }
        }
    
    def map_intent_to_action(self, intent: str, context: Dict = None) -> Optional[Dict[str, Any]]:
        """
        Map an intent to a concrete system action.
        
        Args:
            intent: The recognized intent
            context: Additional context information
            
        Returns:
            action_spec: Detailed action specification or None
        """
        if intent not in self.action_map:
            print(f"❌ Unknown intent: {intent}")
            return None
        
        # Get base action specification
        action_spec = self.action_map[intent].copy()
        
        # Enhance with context information
        if context:
            action_spec = self._enhance_with_context(action_spec, context)
        
        # Add execution metadata
        action_spec['execution_id'] = f"action_{len(self.action_history)}_{datetime.now().strftime('%H%M%S')}"
        action_spec['timestamp'] = datetime.now().isoformat()
        action_spec['original_intent'] = intent
        
        # Record action
        self.action_history.append(action_spec.copy())
        
        return action_spec
    
    def _enhance_with_context(self, action_spec: Dict, context: Dict) -> Dict:
        """
        Enhance action specification with context information.
        
        Args:
            action_spec: The action specification
            context: Context information
            
        Returns:
            enhanced_spec: Enhanced action specification
        """
        # Extract parameters from context if available
        if 'parameters' in action_spec and context:
            # Auto-detect strategy from performance
            if action_spec['function'] == 'set_evolution_strategy' and context.get('performance'):
                performance = context['performance']
                if performance < 0.3:
                    action_spec['parameters']['strategy'] = 'aggressive'
                elif performance > 0.8:
                    action_spec['parameters']['strategy'] = 'conservative'
                else:
                    action_spec['parameters']['strategy'] = 'balanced'
            
            # Auto-detect application type from context
            if action_spec['function'] == 'create_application' and context.get('conversation_history'):
                # Analyze recent conversation to guess application type
                recent_text = ' '.join([msg.get('text', '') for msg in context.get('conversation_history', [])[-3:]])
                if 'stock' in recent_text.lower() or 'price' in recent_text.lower():
                    action_spec['parameters']['type'] = 'stock_predictor'
                elif 'game' in recent_text.lower() or 'play' in recent_text.lower():
                    action_spec['parameters']['type'] = 'game_ai'
        
        return action_spec
    
    def execute_action(self, action_spec: Dict, system_interface) -> Any:
        """
        Execute an action using the provided system interface.
        
        Args:
            action_spec: The action specification
            system_interface: Interface to the SENE system
            
        Returns:
            result: The result of the action execution
        """
        try:
            function_name = action_spec['function']
            parameters = action_spec.get('parameters', {})
            
            # Check if function exists in system interface
            if not hasattr(system_interface, function_name):
                print(f"❌ Function not found: {function_name}")
                return None
            
            # Execute the function
            function = getattr(system_interface, function_name)
            result = function(**parameters)
            
            # Update action history with result
            for action in self.action_history:
                if action.get('execution_id') == action_spec.get('execution_id'):
                    action['execution_result'] = 'success'
                    action['result'] = result
                    break
            
            return result
            
        except Exception as e:
            print(f"❌ Error executing action: {e}")
            
            # Update action history with error
            for action in self.action_history:
                if action.get('execution_id') == action_spec.get('execution_id'):
                    action['execution_result'] = 'error'
                    action['error'] = str(e)
                    break
            
            return None
    
    def get_action_stats(self) -> Dict[str, Any]:
        """Get statistics about action mapping and execution."""
        total_actions = len(self.action_history)
        successful_actions = sum(1 for action in self.action_history if action.get('execution_result') == 'success')
        failed_actions = sum(1 for action in self.action_history if action.get('execution_result') == 'error')
        
        # Count actions by type
        action_counts = {}
        risk_levels = {}
        
        for action in self.action_history:
            intent = action.get('original_intent', 'unknown')
            action_counts[intent] = action_counts.get(intent, 0) + 1
            
            risk = action.get('risk_level', 'unknown')
            risk_levels[risk] = risk_levels.get(risk, 0) + 1
        
        return {
            'total_actions_mapped': total_actions,
            'successful_executions': successful_actions,
            'failed_executions': failed_actions,
            'success_rate': f"{(successful_actions/total_actions*100) if total_actions > 0 else 0:.1f}%",
            'action_distribution': action_counts,
            'risk_distribution': risk_levels,
            'available_actions': len(self.action_map)
        }
    
    def add_custom_action(self, intent: str, action_spec: Dict):
        """
        Add a custom action mapping.
        
        Args:
            intent: The intent to map
            action_spec: The action specification
        """
        required_fields = ['function', 'description', 'risk_level']
        for field in required_fields:
            if field not in action_spec:
                print(f"❌ Missing required field: {field}")
                return
        
        self.action_map[intent] = action_spec
        print(f"✅ Added custom action for intent: {intent}")