# src/decision_engine/__init__.py
"""
Decision Engine for the Self-Evolving Neural Entity.

This module handles collaborative decision-making between the human user
and the AI system. It manages suggestions, approvals, and ensures safe
evolution of the neural network.
"""

from .collaborative_decider import CollaborativeDecider
from .suggestion_engine import SuggestionEngine
from .approval_manager import ApprovalManager

__all__ = [
    'CollaborativeDecider',
    'SuggestionEngine', 
    'ApprovalManager'
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Collaborative decision-making system for safe AI evolution'

print("🤖 SENE Decision Engine loaded - Collaborative AI decision making ready")