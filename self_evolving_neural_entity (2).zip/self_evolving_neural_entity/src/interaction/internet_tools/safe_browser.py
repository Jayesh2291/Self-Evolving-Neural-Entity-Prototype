# src/interaction/internet_tools/safe_browser.py
import requests
from bs4 import BeautifulSoup
import time
import re
from typing import Dict, List, Optional, Tuple, Any
from urllib.parse import urljoin, urlparse
import json

class SafeBrowser:
    """
    Safe web browser with controlled internet access.
    
    Provides secure, limited web access for research and information
    gathering while maintaining safety protocols.
    """
    
    def __init__(self, request_delay: float = 1.0, max_retries: int = 3):
        self.request_delay = request_delay
        self.max_retries = max_retries
        
        # Approved domains for safe browsing
        self.approved_domains = {
            'research': [
                'arxiv.org', 'paperswithcode.com', 'towardsdatascience.com',
                'distill.pub', 'openreview.net', 'research.google'
            ],
            'documentation': [
                'pytorch.org', 'tensorflow.org', 'keras.io', 'scikit-learn.org',
                'numpy.org', 'python.org', 'docs.python.org'
            ],
            'news': [
                'news.mit.edu', 'ai.googleblog.com', 'openai.com/blog',
                'deepmind.com/blog', 'ai.facebook.com/blog'
            ],
            'data': [
                'kaggle.com', 'uci.edu', 'data.gov', 'github.com'
            ]
        }
        
        # Session with safe headers
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'SENE-Research-Bot/1.0 (Safe AI Research Agent)',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive'
        })
        
        # Browsing history and limits
        self.browsing_history = []
        self.daily_request_limit = 100
        self.request_count = 0
        
        # Safety filters
        self.content_filters = [
            r'malware', r'virus', r'exploit', r'hack', r'crack',
            r'warez', r'torrent', r'pirate', r'illegal'
        ]
        
        print("🌐 Safe Browser initialized with approved domains")
    
    def is_domain_approved(self, url: str, category: str = None) -> bool:
        """
        Check if a domain is approved for access.
        
        Args:
            url: The URL to check
            category: Specific category to check against
            
        Returns:
            approved: Whether domain is approved
        """
        try:
            domain = urlparse(url).netloc.lower()
            
            if category:
                # Check specific category
                if category in self.approved_domains:
                    return any(approved_domain in domain for approved_domain in self.approved_domains[category])
                return False
            else:
                # Check all categories
                for category_domains in self.approved_domains.values():
                    if any(approved_domain in domain for approved_domain in category_domains):
                        return True
                return False
                
        except Exception as e:
            print(f"❌ Domain check error: {e}")
            return False
    
    def safe_get(self, url: str, category: str = None, timeout: int = 10) -> Optional[requests.Response]:
        """
        Safely fetch a URL with approval checks and rate limiting.
        
        Args:
            url: URL to fetch
            category: Domain category for approval check
            timeout: Request timeout in seconds
            
        Returns:
            response: HTTP response or None if failed
        """
        # Check domain approval
        if not self.is_domain_approved(url, category):
            print(f"❌ Domain not approved: {url}")
            return None
        
        # Check request limits
        if self.request_count >= self.daily_request_limit:
            print("❌ Daily request limit reached")
            return None
        
        # Rate limiting
        time.sleep(self.request_delay)
        
        # Retry logic
        for attempt in range(self.max_retries):
            try:
                response = self.session.get(url, timeout=timeout)
                self.request_count += 1
                
                # Record browsing history
                self.browsing_history.append({
                    'url': url,
                    'timestamp': time.time(),
                    'status_code': response.status_code,
                    'category': category
                })
                
                if response.status_code == 200:
                    # Check content safety
                    if self._is_content_safe(response.text):
                        return response
                    else:
                        print("❌ Content safety check failed")
                        return None
                else:
                    print(f"❌ HTTP {response.status_code} for {url}")
                    
            except requests.exceptions.RequestException as e:
                print(f"❌ Request failed (attempt {attempt + 1}): {e}")
                if attempt == self.max_retries - 1:
                    return None
                time.sleep(2 ** attempt)  # Exponential backoff
        
        return None
    
    def _is_content_safe(self, content: str) -> bool:
        """
        Check if content passes safety filters.
        
        Args:
            content: Web content to check
            
        Returns:
            safe: Whether content is safe
        """
        content_lower = content.lower()
        
        # Check for filtered terms
        for pattern in self.content_filters:
            if re.search(pattern, content_lower):
                return False
        
        # Additional safety checks can be added here
        return True
    
    def search_arxiv(self, query: str, max_results: int = 5) -> List[Dict[str, Any]]:
        """
        Search arXiv for research papers.
        
        Args:
            query: Search query
            max_results: Maximum number of results
            
        Returns:
            papers: List of paper information
        """
        print(f"🔍 Searching arXiv for: {query}")
        
        try:
            # arXiv API endpoint
            url = "http://export.arxiv.org/api/query"
            params = {
                'search_query': f'all:{query}',
                'start': 0,
                'max_results': max_results,
                'sortBy': 'relevance',
                'sortOrder': 'descending'
            }
            
            response = self.safe_get(url, category='research')
            if not response or response.status_code != 200:
                return []
            
            # Parse arXiv RSS response
            soup = BeautifulSoup(response.content, 'xml')
            entries = soup.find_all('entry')
            
            papers = []
            for entry in entries:
                paper = {
                    'title': entry.title.text.strip() if entry.title else 'No title',
                    'summary': entry.summary.text.strip()[:300] + '...' if entry.summary else 'No summary',
                    'authors': [author.find('name').text if author.find('name') else 'Unknown' 
                               for author in entry.find_all('author')],
                    'published': entry.published.text[:10] if entry.published else 'Unknown',
                    'url': entry.id.text if entry.id else '',
                    'pdf_url': entry.find('link', {'title': 'pdf'})['href'] if entry.find('link', {'title': 'pdf'}) else '',
                    'categories': [cat.text for cat in entry.find_all('category')],
                    'source': 'arxiv'
                }
                papers.append(paper)
            
            print(f"✅ Found {len(papers)} papers on arXiv")
            return papers
            
        except Exception as e:
            print(f"❌ arXiv search error: {e}")
            return []
    
    def get_webpage_summary(self, url: str) -> Optional[Dict[str, Any]]:
        """
        Get a safe summary of a webpage.
        
        Args:
            url: Webpage URL
            
        Returns:
            summary: Page summary or None
        """
        response = self.safe_get(url)
        if not response:
            return None
        
        try:
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract key information
            title = soup.title.string.strip() if soup.title else 'No title'
            
            # Try to get meta description
            meta_desc = soup.find('meta', attrs={'name': 'description'})
            description = meta_desc['content'] if meta_desc else ''
            
            # Extract main content (simplified)
            paragraphs = soup.find_all('p')
            content = ' '.join([p.get_text().strip() for p in paragraphs[:5]])[:500] + '...'
            
            # Extract links (limited)
            links = []
            for link in soup.find_all('a', href=True)[:10]:
                href = link['href']
                full_url = urljoin(url, href)
                if self.is_domain_approved(full_url):
                    links.append({
                        'text': link.get_text().strip()[:50],
                        'url': full_url
                    })
            
            summary = {
                'title': title,
                'description': description,
                'content_preview': content,
                'links': links,
                'url': url,
                'timestamp': time.time()
            }
            
            return summary
            
        except Exception as e:
            print(f"❌ Webpage summary error: {e}")
            return None
    
    def add_approved_domain(self, domain: str, category: str = 'general'):
        """
        Add a new approved domain.
        
        Args:
            domain: Domain to approve
            category: Domain category
        """
        if category not in self.approved_domains:
            self.approved_domains[category] = []
        
        if domain not in self.approved_domains[category]:
            self.approved_domains[category].append(domain)
            print(f"✅ Added approved domain: {domain} to category: {category}")
    
    def get_browser_stats(self) -> Dict[str, Any]:
        """Get browser usage statistics."""
        today = time.time() - 86400  # 24 hours ago
        recent_requests = [req for req in self.browsing_history if req['timestamp'] > today]
        
        # Count requests by category
        category_counts = {}
        for req in self.browsing_history:
            category = req.get('category', 'unknown')
            category_counts[category] = category_counts.get(category, 0) + 1
        
        return {
            'total_requests_today': len(recent_requests),
            'daily_limit': self.daily_request_limit,
            'requests_remaining': self.daily_request_limit - len(recent_requests),
            'category_breakdown': category_counts,
            'total_approved_domains': sum(len(domains) for domains in self.approved_domains.values()),
            'browsing_history_size': len(self.browsing_history)
        }
    
    def reset_request_count(self):
        """Reset daily request count (for testing)."""
        self.request_count = 0
        print("🔄 Request count reset")