# run_sene.py (place this in the root directory)
"""
Launcher for Self-Evolving Neural Entity
"""

import sys
import os
import argparse

# Add the src directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, 'src')
sys.path.insert(0, src_dir)

def main():
    parser = argparse.ArgumentParser(prog="run_sene", add_help=True)
    parser.add_argument("--mode", choices=["both", "voice", "text", "demo"], default="both")
    args = parser.parse_args()

    try:
        from main import demo_sene_system, create_sene_system
        print("🚀 Launching Self-Evolving Neural Entity...")

        if args.mode == "demo":
            demo_sene_system()
            return

        sene = create_sene_system("balanced")

        if args.mode == "voice":
            sene.start_system()
            print("Press Ctrl+C to stop...")
            try:
                while True:
                    pass
            except KeyboardInterrupt:
                pass
            finally:
                sene.stop_system()
        elif args.mode == "text":
            try:
                sene.start_text_cli()
            except KeyboardInterrupt:
                pass
            finally:
                sene.stop_system()
        elif args.mode == "both":
            try:
                # Start voice in background threads, then run CLI in foreground
                sene.start_system()
                sene.start_text_cli()
            except KeyboardInterrupt:
                pass
            finally:
                sene.stop_system()
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("Please make sure all required dependencies are installed.")
        print("Run: pip install -r requirements.txt")
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()