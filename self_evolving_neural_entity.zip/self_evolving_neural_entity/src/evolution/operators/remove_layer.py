# src/evolution/operators/remove_layer.py
import torch.nn as nn
import random
from typing import Tuple, Dict, Any

class RemoveLayerOperator:
    """
    Evolution operator that removes neural layers from the network.
    
    This operator reduces network complexity, which can help with:
    - Overfitting reduction
    - Computational efficiency
    - Training stability
    """
    
    def __init__(self, min_layers: int = 1):
        self.min_layers = min_layers
        self.operation_count = 0
        
        print(f"🧬 RemoveLayerOperator initialized (min_layers: {min_layers})")
    
    def apply(self, enn: nn.Module, context: Dict = None) -> Tuple[bool, str]:
        """
        Remove a neural layer from the network.
        
        Args:
            enn: The neural network to modify
            context: Additional context information
            
        Returns:
            success: Whether operation was successful
            message: Description of what was done
        """
        # Check if we have enough layers to remove one
        if len(enn.blocks) <= self.min_layers:
            return False, f"Minimum layers ({self.min_layers}) reached"
        
        # Select which layer to remove
        position = self._select_removal_position(enn, context)
        
        # Remove the layer
        success = enn.remove_block(position)
        
        if success:
            self.operation_count += 1
            message = f"Removed layer at position {position}"
            return True, message
        else:
            return False, "Failed to remove layer"
    
    def _select_removal_position(self, enn: nn.Module, context: Dict) -> int:
        """
        Select which layer to remove based on various strategies.
        
        Strategies:
        - Least important: Remove layer with least impact (simulated)
        - Random: Random removal for exploration
        - End: Remove last layer (often least critical)
        - Middle: Remove middle layer for architectural exploration
        """
        strategies = ['end', 'random', 'middle']
        
        # Weight strategies based on context
        if context and context.get('stability', 1.0) < 0.7:
            # Unstable - prefer safe removal from end
            strategy_weights = [0.7, 0.2, 0.1]
        else:
            # Stable - explore different removals
            strategy_weights = [0.4, 0.4, 0.2]
        
        strategy = random.choices(strategies, weights=strategy_weights)[0]
        
        if strategy == 'end':
            return len(enn.blocks) - 1  # Remove last layer
        elif strategy == 'middle' and len(enn.blocks) > 2:
            return random.randint(1, len(enn.blocks) - 2)  # Remove middle layer
        else:
            return random.randint(0, len(enn.blocks) - 1)  # Random removal
    
    def get_operator_stats(self) -> Dict[str, Any]:
        """Get statistics about this operator's usage."""
        return {
            'operator_type': 'remove_layer',
            'operation_count': self.operation_count,
            'min_layers': self.min_layers
        }