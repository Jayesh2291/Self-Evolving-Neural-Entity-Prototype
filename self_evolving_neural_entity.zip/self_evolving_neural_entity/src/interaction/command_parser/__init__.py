# src/interaction/command_parser/__init__.py
"""
Command Parser for voice and text commands.

This module processes natural language commands and converts them
into actionable instructions for the Self-Evolving Neural Entity.
"""

from .intent_recognition import IntentRecognizer
from .action_mapping import ActionMapper
from .context_tracker import ContextTracker

__all__ = [
    'IntentRecognizer',
    'ActionMapper', 
    'ContextTracker'
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Natural language command processing for SENE'

print("🎯 SENE Command Parser loaded - Voice command understanding ready")