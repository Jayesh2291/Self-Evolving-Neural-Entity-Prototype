# src/applications/game_ai.py
import gym
import torch
from datetime import datetime

class GameAI:
    """SENE for game playing and reinforcement learning"""
    
    def __init__(self, sene_core, game_name='CartPole-v1'):
        self.sene = sene_core
        self.game_name = game_name
        self.environment = None
        self.training_history = []
        
    def initialize_environment(self, game_name=None):
        """Initialize the game environment"""
        try:
            if game_name:
                self.game_name = game_name
            self.environment = gym.make(self.game_name)
            return True, f"Initialized {self.game_name} environment"
        except Exception as e:
            return False, f"Error initializing environment: {e}"
        
    def train_on_game(self, episodes=1000, render=False):
        """Train SENE to play the game"""
        if self.environment is None:
            success, message = self.initialize_environment()
            if not success:
                return False, message
        
        best_score = 0
        print(f"🎮 Starting training on {self.game_name} for {episodes} episodes...")
        
        for episode in range(episodes):
            state = self.environment.reset()
            if isinstance(state, tuple):
                state = state[0]
                
            total_reward = 0
            done = False
            steps = 0
            
            while not done and steps < 500:  # Prevent infinite episodes
                # Use SENE to decide action
                with torch.no_grad():
                    q_values = self.sene.neural_network(state)
                    action = torch.argmax(q_values).item()
                
                next_state, reward, done, info = self.environment.step(action)
                total_reward += reward
                
                # Store experience
                self.sene.neural_network.store_experience(state, action, reward, next_state, done)
                
                # Learn periodically
                if steps % 4 == 0:
                    self.sene.neural_network.update(batch_size=32)
                
                state = next_state
                steps += 1
                
                if render and episode % 50 == 0:
                    self.environment.render()
            
            self.training_history.append({
                'episode': episode,
                'score': total_reward,
                'steps': steps,
                'timestamp': datetime.now().isoformat()
            })
            
            if total_reward > best_score:
                best_score = total_reward
                print(f"🏆 New best score: {best_score} at episode {episode}")
            
            # Evolve if performance plateaus
            if episode % 50 == 0 and episode > 0:
                recent_scores = [h['score'] for h in self.training_history[-20:]]
                avg_recent = sum(recent_scores) / len(recent_scores)
                
                success, message = self.sene.evolution_engine.propose_evolution(
                    self.sene.neural_network, 
                    {'performance': avg_recent / 500.0}  # Normalize
                )
                if success:
                    print(f"🧠 Evolution: {message}")
            
            if episode % 100 == 0:
                print(f"📊 Episode {episode}: Score = {total_reward}, Best = {best_score}")
        
        self.environment.close()
        return True, f"Training completed. Best score: {best_score}"
    
    def play_game(self, episodes=5, render=True):
        """Play the game using the trained network"""
        if self.environment is None:
            success, message = self.initialize_environment()
            if not success:
                return False, message
        
        print(f"🎮 Playing {self.game_name} for {episodes} episodes...")
        
        for episode in range(episodes):
            state = self.environment.reset()
            if isinstance(state, tuple):
                state = state[0]
                
            total_reward = 0
            done = False
            
            while not done:
                with torch.no_grad():
                    q_values = self.sene.neural_network(state)
                    action = torch.argmax(q_values).item()
                
                next_state, reward, done, info = self.environment.step(action)
                total_reward += reward
                state = next_state
                
                if render:
                    self.environment.render()
            
            print(f"🎯 Episode {episode + 1}: Score = {total_reward}")
        
        self.environment.close()
        return True, "Game play completed"
    
    def get_training_stats(self):
        """Get training statistics"""
        if not self.training_history:
            return "No training data available"
        
        recent_scores = [h['score'] for h in self.training_history[-20:]]
        avg_score = sum(recent_scores) / len(recent_scores) if recent_scores else 0
        best_score = max([h['score'] for h in self.training_history]) if self.training_history else 0
        
        return f"""
🎮 Game AI Statistics:
• Game: {self.game_name}
• Training Episodes: {len(self.training_history)}
• Recent Average Score: {avg_score:.1f}
• Best Score: {best_score}
• Neural Architecture: {self.sene.neural_network.get_architecture()}
        """.strip()