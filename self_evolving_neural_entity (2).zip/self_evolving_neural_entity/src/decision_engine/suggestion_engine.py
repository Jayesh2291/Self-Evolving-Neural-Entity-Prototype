# src/decision_engine/suggestion_engine.py
import random
import numpy as np
from datetime import datetime
from typing import Dict, List, Any
import torch

class SuggestionEngine:
    """
    Generates intelligent suggestions for neural network evolution
    based on current performance and system state.
    """
    
    def __init__(self):
        self.suggestion_templates = {
            'add_layer': {
                'type': 'architecture',
                'description': 'Add a new hidden layer to increase capacity',
                'risk_level': 'low',
                'expected_benefit': 15.0,
                'complexity_change': 10.0
            },
            'remove_layer': {
                'type': 'architecture', 
                'description': 'Remove a hidden layer to reduce complexity',
                'risk_level': 'medium',
                'expected_benefit': -5.0,
                'complexity_change': -15.0
            },
            'increase_neurons': {
                'type': 'capacity',
                'description': 'Increase neurons in existing layers',
                'risk_level': 'low',
                'expected_benefit': 8.0,
                'complexity_change': 5.0
            },
            'change_activation': {
                'type': 'optimization',
                'description': 'Change activation function for better learning',
                'risk_level': 'medium', 
                'expected_benefit': 12.0,
                'complexity_change': 2.0
            },
            'adjust_learning_rate': {
                'type': 'optimization',
                'description': 'Adjust learning rate for stable training',
                'risk_level': 'low',
                'expected_benefit': 10.0,
                'complexity_change': 0.0
            },
            'add_attention': {
                'type': 'advanced',
                'description': 'Add attention mechanism for complex patterns',
                'risk_level': 'high',
                'expected_benefit': 25.0,
                'complexity_change': 20.0
            }
        }
        
        self.suggestion_history = []
        self.performance_trend = []
        
        print("💡 Suggestion Engine initialized")
    
    def generate_suggestions(self, current_state: Dict, max_suggestions: int = 3) -> List[Dict]:
        """
        Generate evolution suggestions based on current system state.
        
        Args:
            current_state: Current neural network and performance state
            max_suggestions: Maximum number of suggestions to generate
            
        Returns:
            suggestions: List of suggestion dictionaries
        """
        suggestions = []
        
        # Analyze current state to determine what type of suggestions are needed
        state_analysis = self._analyze_current_state(current_state)
        
        # Generate appropriate suggestions
        available_templates = self._get_relevant_templates(state_analysis)
        
        for template_key in available_templates[:max_suggestions]:
            suggestion = self._create_suggestion_from_template(template_key, current_state)
            if suggestion:
                suggestions.append(suggestion)
        
        # Record suggestions
        for suggestion in suggestions:
            self.suggestion_history.append({
                'timestamp': datetime.now().isoformat(),
                'suggestion': suggestion,
                'state_analysis': state_analysis
            })
        
        print(f"💡 Generated {len(suggestions)} evolution suggestions")
        return suggestions
    
    def _analyze_current_state(self, current_state: Dict) -> Dict:
        """Analyze current system state to determine needs"""
        performance = current_state.get('performance', 0.5)
        stability = current_state.get('stability', 0.5)
        complexity = current_state.get('complexity', 0.5)
        
        analysis = {
            'needs_capacity': performance < 0.6 and stability > 0.7,
            'needs_simplification': complexity > 0.8 and performance < 0.7,
            'needs_optimization': stability < 0.6,
            'needs_innovation': performance > 0.8 and stability > 0.8,
            'performance_trend': 'improving' if len(self.performance_trend) > 1 and self.performance_trend[-1] > self.performance_trend[-2] else 'declining'
        }
        
        return analysis
    
    def _get_relevant_templates(self, state_analysis: Dict) -> List[str]:
        """Get relevant suggestion templates based on state analysis"""
        relevant_templates = []
        
        if state_analysis['needs_capacity']:
            relevant_templates.extend(['add_layer', 'increase_neurons'])
        
        if state_analysis['needs_simplification']:
            relevant_templates.extend(['remove_layer'])
        
        if state_analysis['needs_optimization']:
            relevant_templates.extend(['adjust_learning_rate', 'change_activation'])
        
        if state_analysis['needs_innovation']:
            relevant_templates.extend(['add_attention'])
        
        # Always include some basic options
        if not relevant_templates:
            relevant_templates = ['adjust_learning_rate', 'add_layer', 'change_activation']
        
        # Shuffle to provide variety
        random.shuffle(relevant_templates)
        
        return relevant_templates
    
    def _create_suggestion_from_template(self, template_key: str, current_state: Dict) -> Dict:
        """Create a detailed suggestion from a template"""
        if template_key not in self.suggestion_templates:
            return None
        
        template = self.suggestion_templates[template_key].copy()
        
        # Customize based on current state
        performance = current_state.get('performance', 0.5)
        
        # Adjust expected benefit based on current performance
        if performance > 0.8:
            # High performance - conservative benefits
            template['expected_benefit'] *= 0.7
            template['risk_level'] = 'low' if template['risk_level'] == 'medium' else template['risk_level']
        elif performance < 0.3:
            # Low performance - more aggressive benefits
            template['expected_benefit'] *= 1.3
            template['benefit_confidence'] = 0.6  # Lower confidence for struggling systems
        else:
            template['benefit_confidence'] = 0.8
        
        # Add implementation details
        template['implementation'] = self._generate_implementation_details(template_key, current_state)
        template['id'] = len(self.suggestion_history)
        template['timestamp'] = datetime.now().isoformat()
        
        return template
    
    def _generate_implementation_details(self, template_key: str, current_state: Dict) -> Dict:
        """Generate specific implementation details for a suggestion"""
        implementation = {}
        
        if template_key == 'add_layer':
            current_size = current_state.get('current_architecture', [4, 64, 64, 2])
            avg_size = sum(current_size[1:-1]) / len(current_size[1:-1]) if len(current_size) > 2 else 64
            new_size = max(32, min(256, int(avg_size * random.uniform(0.8, 1.2))))
            implementation['new_layer_size'] = new_size
            implementation['position'] = 'end'  # or 'middle' based on strategy
            
        elif template_key == 'adjust_learning_rate':
            current_lr = current_state.get('learning_rate', 1e-3)
            if current_state.get('stability', 0.5) < 0.6:
                # Unstable - decrease learning rate
                new_lr = current_lr * 0.7
                implementation['direction'] = 'decrease'
            else:
                # Stable but slow - increase learning rate
                new_lr = current_lr * 1.3
                implementation['direction'] = 'increase'
            implementation['new_learning_rate'] = max(1e-6, min(1e-1, new_lr))
        
        return implementation
    
    def record_suggestion_outcome(self, suggestion_id: int, was_implemented: bool, 
                                actual_benefit: float = None, user_feedback: str = ""):
        """Record the outcome of a suggestion for learning"""
        if 0 <= suggestion_id < len(self.suggestion_history):
            record = self.suggestion_history[suggestion_id]
            record['outcome'] = {
                'was_implemented': was_implemented,
                'actual_benefit': actual_benefit,
                'user_feedback': user_feedback,
                'outcome_timestamp': datetime.now().isoformat()
            }
    
    def get_suggestion_stats(self) -> Dict:
        """Get suggestion engine statistics"""
        total_suggestions = len(self.suggestion_history)
        implemented = sum(1 for s in self.suggestion_history if s.get('outcome', {}).get('was_implemented', False))
        
        return {
            'total_suggestions_generated': total_suggestions,
            'implementation_rate': f"{(implemented/total_suggestions*100) if total_suggestions > 0 else 0:.1f}%",
            'available_templates': len(self.suggestion_templates),
            'suggestion_types_used': len(set(s['suggestion']['type'] for s in self.suggestion_history))
        }