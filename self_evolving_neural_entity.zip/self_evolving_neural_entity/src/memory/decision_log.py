# src/memory/decision_log.py
import json
import pickle
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from collections import defaultdict
import hashlib

class DecisionLogger:
    """
    Comprehensive logging of all system decisions and their outcomes.
    
    Tracks evolution decisions, training choices, and user interactions
    to enable learning from past experiences and improve future decisions.
    """
    
    def __init__(self, log_file: str = "decision_logs.pkl", max_logs: int = 5000):
        self.log_file = log_file
        self.max_logs = max_logs
        
        # Decision storage
        self.decision_logs = []
        self.decision_outcomes = {}
        self.performance_metrics = defaultdict(list)
        
        # Analytics
        self.analytics = {
            'total_decisions': 0,
            'successful_decisions': 0,
            'failed_decisions': 0,
            'average_confidence': 0.0,
            'decision_categories': defaultdict(int)
        }
        
        # Load existing logs
        self._load_logs()
        
        print(f"📊 Decision Logger initialized ({len(self.decision_logs)} decisions loaded)")
    
    def _load_logs(self):
        """Load decision logs from disk."""
        try:
            with open(self.log_file, 'rb') as f:
                saved_data = pickle.load(f)
                self.decision_logs = saved_data.get('decision_logs', [])
                self.decision_outcomes = saved_data.get('decision_outcomes', {})
                self.performance_metrics = saved_data.get('performance_metrics', defaultdict(list))
                self.analytics = saved_data.get('analytics', self.analytics)
            
            print(f"✅ Loaded {len(self.decision_logs)} decision logs")
            
        except FileNotFoundError:
            print("📝 No existing decision logs found. Starting fresh.")
        except Exception as e:
            print(f"❌ Error loading decision logs: {e}. Starting fresh.")
    
    def save_logs(self):
        """Save decision logs to disk."""
        try:
            log_data = {
                'decision_logs': self.decision_logs[-self.max_logs:],  # Keep only recent logs
                'decision_outcomes': self.decision_outcomes,
                'performance_metrics': dict(self.performance_metrics),
                'analytics': self.analytics,
                'metadata': {
                    'saved_at': datetime.now().isoformat(),
                    'total_decisions': len(self.decision_logs)
                }
            }
            
            with open(self.log_file, 'wb') as f:
                pickle.dump(log_data, f)
            
            print(f"💾 Decision logs saved: {len(self.decision_logs)} decisions")
            
        except Exception as e:
            print(f"❌ Error saving decision logs: {e}")
    
    def log_decision(self, decision_type: str, decision_data: Dict[str, Any], 
                    context: Dict[str, Any] = None) -> str:
        """
        Log a system decision.
        
        Args:
            decision_type: Type of decision (evolution, training, safety, etc.)
            decision_data: The decision details
            context: Context in which decision was made
            
        Returns:
            decision_id: Unique ID for the decision
        """
        decision_id = self._generate_decision_id(decision_type, decision_data)
        
        decision_log = {
            'decision_id': decision_id,
            'timestamp': datetime.now().isoformat(),
            'decision_type': decision_type,
            'decision_data': decision_data,
            'context': context or {},
            'confidence': decision_data.get('confidence', 0.5),
            'risk_level': decision_data.get('risk_level', 'medium'),
            'expected_benefit': decision_data.get('expected_benefit', 0.0),
            'outcome': None,  # Will be updated later
            'learned_lessons': []
        }
        
        self.decision_logs.append(decision_log)
        self.analytics['total_decisions'] += 1
        self.analytics['decision_categories'][decision_type] += 1
        
        # Update average confidence
        total_conf = self.analytics['average_confidence'] * (self.analytics['total_decisions'] - 1)
        self.analytics['average_confidence'] = (total_conf + decision_log['confidence']) / self.analytics['total_decisions']
        
        # Auto-save periodically
        if len(self.decision_logs) % 50 == 0:
            self.save_logs()
        
        print(f"📝 Logged decision: {decision_type} (ID: {decision_id})")
        return decision_id
    
    def _generate_decision_id(self, decision_type: str, decision_data: Dict) -> str:
        """Generate a unique decision ID."""
        content = f"{decision_type}_{json.dumps(decision_data, sort_keys=True)}_{datetime.now().isoformat()}"
        return hashlib.md5(content.encode()).hexdigest()[:12]
    
    def update_decision_outcome(self, decision_id: str, outcome: Dict[str, Any]):
        """
        Update the outcome of a decision.
        
        Args:
            decision_id: ID of the decision to update
            outcome: Outcome details including success/failure
        """
        for decision in self.decision_logs:
            if decision['decision_id'] == decision_id:
                decision['outcome'] = outcome
                decision['outcome_timestamp'] = datetime.now().isoformat()
                
                # Update analytics
                success = outcome.get('success', False)
                if success:
                    self.analytics['successful_decisions'] += 1
                else:
                    self.analytics['failed_decisions'] += 1
                
                # Store outcome for quick lookup
                self.decision_outcomes[decision_id] = outcome
                
                # Extract lessons learned
                lessons = self._extract_lessons(decision, outcome)
                decision['learned_lessons'] = lessons
                
                print(f"✅ Updated outcome for decision {decision_id}: {'SUCCESS' if success else 'FAILURE'}")
                break
        
        self.save_logs()
    
    def _extract_lessons(self, decision: Dict, outcome: Dict) -> List[str]:
        """Extract lessons learned from decision outcomes."""
        lessons = []
        success = outcome.get('success', False)
        
        if success:
            # Positive lessons
            if decision['confidence'] > 0.8:
                lessons.append("High confidence decisions in this context tend to succeed")
            if decision['risk_level'] == 'low':
                lessons.append("Low-risk approaches work well here")
        else:
            # Negative lessons
            if decision['confidence'] > 0.8:
                lessons.append("Be more cautious with high-confidence predictions in this context")
            if decision['risk_level'] == 'high':
                lessons.append("High-risk decisions often fail in similar situations")
        
        # Context-specific lessons
        context = decision.get('context', {})
        if context.get('performance', 0) < 0.3 and not success:
            lessons.append("Avoid major changes when performance is very low")
        
        return lessons
    
    def log_performance_metric(self, metric_name: str, value: float, context: Dict = None):
        """
        Log a performance metric.
        
        Args:
            metric_name: Name of the metric
            value: Metric value
            context: Context for the metric
        """
        metric_entry = {
            'timestamp': datetime.now().isoformat(),
            'value': value,
            'context': context or {}
        }
        
        self.performance_metrics[metric_name].append(metric_entry)
        
        # Keep metrics within reasonable limits
        if len(self.performance_metrics[metric_name]) > 1000:
            self.performance_metrics[metric_name] = self.performance_metrics[metric_name][-1000:]
    
    def get_decision_history(self, decision_type: str = None, limit: int = 10) -> List[Dict]:
        """Get decision history, optionally filtered by type."""
        logs = self.decision_logs
        
        if decision_type:
            logs = [log for log in logs if log['decision_type'] == decision_type]
        
        return logs[-limit:]
    
    def find_similar_decisions(self, current_decision: Dict, max_results: int = 5) -> List[Dict]:
        """Find similar past decisions for reference."""
        similar_decisions = []
        current_type = current_decision.get('decision_type')
        current_context = current_decision.get('context', {})
        
        for decision in reversed(self.decision_logs):
            if decision['decision_type'] == current_type:
                similarity = self._calculate_decision_similarity(decision, current_decision)
                if similarity > 0.6:  # Similarity threshold
                    similar_decisions.append({
                        'decision': decision,
                        'similarity': similarity,
                        'outcome': self.decision_outcomes.get(decision['decision_id'])
                    })
                    
                    if len(similar_decisions) >= max_results:
                        break
        
        return similar_decisions
    
    def _calculate_decision_similarity(self, decision1: Dict, decision2: Dict) -> float:
        """Calculate similarity between two decisions."""
        similarity = 0.0
        
        # Type similarity
        if decision1['decision_type'] == decision2['decision_type']:
            similarity += 0.3
        
        # Context similarity (simplified)
        context1 = decision1.get('context', {})
        context2 = decision2.get('context', {})
        
        common_keys = set(context1.keys()) & set(context2.keys())
        if common_keys:
            key_similarity = sum(1 for key in common_keys if context1[key] == context2[key]) / len(common_keys)
            similarity += key_similarity * 0.7
        
        return min(1.0, similarity)
    
    def get_decision_analytics(self) -> Dict[str, Any]:
        """Get comprehensive decision analytics."""
        success_rate = (
            self.analytics['successful_decisions'] / self.analytics['total_decisions'] * 100
        ) if self.analytics['total_decisions'] > 0 else 0
        
        # Recent performance (last 100 decisions)
        recent_decisions = self.decision_logs[-100:]
        recent_successes = sum(1 for d in recent_decisions if d.get('outcome', {}).get('success', False))
        recent_success_rate = (recent_successes / len(recent_decisions) * 100) if recent_decisions else 0
        
        # Risk analysis
        risk_distribution = defaultdict(int)
        for decision in self.decision_logs:
            risk_distribution[decision['risk_level']] += 1
        
        return {
            'total_decisions': self.analytics['total_decisions'],
            'success_rate': f"{success_rate:.1f}%",
            'recent_success_rate': f"{recent_success_rate:.1f}%",
            'average_confidence': f"{self.analytics['average_confidence']:.3f}",
            'decision_categories': dict(self.analytics['decision_categories']),
            'risk_distribution': dict(risk_distribution),
            'performance_metrics_tracked': list(self.performance_metrics.keys()),
            'outcomes_recorded': len(self.decision_outcomes)
        }
    
    def get_performance_trends(self, metric_name: str, window: int = 50) -> Dict[str, Any]:
        """Get performance trends for a specific metric."""
        if metric_name not in self.performance_metrics:
            return {'error': f"Metric '{metric_name}' not found"}
        
        metrics = self.performance_metrics[metric_name][-window:]
        if not metrics:
            return {'error': 'No data available'}
        
        values = [m['value'] for m in metrics]
        timestamps = [m['timestamp'] for m in metrics]
        
        # Calculate trends
        if len(values) > 1:
            trend = (values[-1] - values[0]) / values[0] * 100  # Percentage change
            moving_avg = sum(values[-5:]) / min(5, len(values)) if len(values) >= 5 else values[-1]
        else:
            trend = 0.0
            moving_avg = values[0]
        
        return {
            'metric': metric_name,
            'current_value': values[-1],
            'trend_percentage': f"{trend:+.1f}%",
            'moving_average': moving_avg,
            'min_value': min(values),
            'max_value': max(values),
            'data_points': len(values),
            'time_period': f"{len(values)} records"
        }
    
    def export_decision_data(self, filepath: str) -> bool:
        """Export decision data to JSON for analysis."""
        try:
            export_data = {
                'decision_logs': self.decision_logs,
                'performance_metrics': dict(self.performance_metrics),
                'analytics': self.analytics,
                'exported_at': datetime.now().isoformat()
            }
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)
            
            print(f"📤 Decision data exported to: {filepath}")
            return True
            
        except Exception as e:
            print(f"❌ Export failed: {e}")
            return False