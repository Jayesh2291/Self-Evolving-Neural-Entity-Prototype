# src/applications/__init__.py
"""
Applications module for Self-Evolving Neural Entity.

This module contains real-world applications and specialized implementations
of the SENE system for different domains.
"""

from .stock_predictor import StockPredictorSENE
from .game_ai import GameAI

__all__ = [
    'StockPredictorSENE',
    'GameAI'
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Real-world applications for the Self-Evolving Neural Entity'

print("🧠 SENE Applications module loaded - Stock prediction and Game AI available")