# src/interaction/__init__.py
"""
Interaction module for the Self-Evolving Neural Entity.

This module provides natural language interaction capabilities including
voice recognition, command processing, and internet research tools
for seamless human-AI collaboration.
"""

from .command_parser import IntentRecognizer, ActionMapper, ContextTracker
from .internet_tools import SafeBrowser, ResearchAssistant, DataScraper
from .voice_interface import VoiceInterface, TextToSpeech, WakeWordDetector

__all__ = [
    # Command Parser
    'IntentRecognizer',
    'ActionMapper', 
    'ContextTracker',
    
    # Internet Tools
    'SafeBrowser',
    'ResearchAssistant',
    'DataScraper',
    
    # Voice Interface
    'VoiceInterface',
    'TextToSpeech',
    'WakeWordDetector'
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Natural interaction system for voice and command processing'

print("💬 SENE Interaction module loaded - Voice and command processing ready")