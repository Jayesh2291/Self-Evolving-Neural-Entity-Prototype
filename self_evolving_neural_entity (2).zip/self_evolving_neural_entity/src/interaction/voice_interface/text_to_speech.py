# src/interaction/voice_interface/text_to_speech.py
import pyttsx3
import threading
import queue
import time
from typing import Optional, Callable, List, Dict, Any
from datetime import datetime

class TextToSpeech:
    """
    Text-to-speech engine for vocal responses.
    
    Provides natural voice feedback and system responses
    using offline TTS capabilities.
    """
    
    def __init__(self, rate: int = 150, volume: float = 0.8, voice_id: int = None):
        self.rate = rate
        self.volume = volume
        self.voice_id = voice_id
        
        # TTS engine
        self.engine = None
        self.available_voices = []
        self.current_voice = None
        
        # Speech queue and state
        self.speech_queue = queue.Queue()
        self.is_speaking = False
        self.speech_thread = None
        self.is_initialized = False
        
        # Speech statistics
        self.speech_stats = {
            'total_utterances': 0,
            'total_characters': 0,
            'last_utterance': None,
            'average_speech_time': 0
        }
        
        # Callbacks
        self.on_speech_start = None
        self.on_speech_end = None
        self.on_error = None
        
        # Initialize TTS engine
        self._initialize_engine()
        
        print("🗣️ Text-to-Speech engine initialized")
    
    def _initialize_engine(self):
        """Initialize the TTS engine with configured settings."""
        try:
            self.engine = pyttsx3.init()
            
            # Configure engine properties
            self.engine.setProperty('rate', self.rate)
            self.engine.setProperty('volume', self.volume)
            
            # Get available voices
            self.available_voices = self.engine.getProperty('voices')
            
            # Set voice
            if self.voice_id is not None and self.voice_id < len(self.available_voices):
                self.current_voice = self.available_voices[self.voice_id]
            else:
                # Use first available voice
                self.current_voice = self.available_voices[0] if self.available_voices else None
            
            if self.current_voice:
                self.engine.setProperty('voice', self.current_voice.id)
            
            # Set up event callbacks
            self.engine.connect('started-utterance', self._on_speech_start)
            self.engine.connect('finished-utterance', self._on_speech_end)
            
            self.is_initialized = True
            print(f"✅ TTS engine ready with {len(self.available_voices)} available voices")
            print(f"   Rate: {self.rate}, Volume: {self.volume}")
            
        except Exception as e:
            print(f"❌ TTS engine initialization failed: {e}")
            self.is_initialized = False
    
    def _on_speech_start(self, name: str, completed: bool):
        """Handle speech start event."""
        self.is_speaking = True
        if self.on_speech_start:
            self.on_speech_start(name)
    
    def _on_speech_end(self, name: str, completed: bool):
        """Handle speech end event."""
        self.is_speaking = False
        if self.on_speech_end:
            self.on_speech_end(name, completed)
    
    def speak(self, text: str, async_mode: bool = True) -> bool:
        """
        Speak text aloud.
        
        Args:
            text: Text to speak
            async_mode: Whether to speak asynchronously
            
        Returns:
            success: Whether speech was queued successfully
        """
        if not self.is_initialized or not text.strip():
            return False
        
        try:
            if async_mode:
                # Add to queue for background processing
                self.speech_queue.put(text)
                
                # Start speech thread if not running
                if not self.speech_thread or not self.speech_thread.is_alive():
                    self.speech_thread = threading.Thread(
                        target=self._speech_worker,
                        daemon=True,
                        name="TTSWorker"
                    )
                    self.speech_thread.start()
                
                return True
            else:
                # Speak synchronously (blocks until done)
                return self._speak_sync(text)
                
        except Exception as e:
            print(f"❌ Error queuing speech: {e}")
            if self.on_error:
                self.on_error(f"Speech queuing error: {e}")
            return False
    
    def _speech_worker(self):
        """Background worker for processing speech queue."""
        print("🎙️ TTS worker started...")
        
        while True:
            try:
                # Get text from queue with timeout
                text = self.speech_queue.get(timeout=1.0)
                
                # Speak the text
                self._speak_sync(text)
                
                # Mark task as done
                self.speech_queue.task_done()
                
            except queue.Empty:
                # No more speech in queue, check if we should continue
                if self.speech_queue.empty():
                    break
            except Exception as e:
                print(f"❌ TTS worker error: {e}")
                if self.on_error:
                    self.on_error(f"TTS worker error: {e}")
        
        print("🎙️ TTS worker finished")
    
    def _speak_sync(self, text: str) -> bool:
        """
        Speak text synchronously.
        
        Args:
            text: Text to speak
            
        Returns:
            success: Whether speech was successful
        """
        try:
            start_time = time.time()
            
            # Update statistics
            self.speech_stats['total_utterances'] += 1
            self.speech_stats['total_characters'] += len(text)
            self.speech_stats['last_utterance'] = datetime.now().isoformat()
            
            # Speak the text
            self.engine.say(text)
            self.engine.runAndWait()
            
            # Calculate speech time
            speech_time = time.time() - start_time
            self.speech_stats['average_speech_time'] = (
                (self.speech_stats['average_speech_time'] * (self.speech_stats['total_utterances'] - 1) + speech_time) 
                / self.speech_stats['total_utterances']
            )
            
            print(f"🗣️ Spoke: '{text[:50]}{'...' if len(text) > 50 else ''}'")
            return True
            
        except Exception as e:
            print(f"❌ Speech error: {e}")
            if self.on_error:
                self.on_error(f"Speech error: {e}")
            return False
    
    def speak_multiple(self, texts: List[str], delay: float = 0.5):
        """
        Speak multiple texts with delays between them.
        
        Args:
            texts: List of texts to speak
            delay: Delay between texts in seconds
        """
        for i, text in enumerate(texts):
            self.speak(text, async_mode=False)
            if i < len(texts) - 1:  # Don't delay after last text
                time.sleep(delay)
    
    def set_voice(self, voice_index: int) -> bool:
        """
        Change the TTS voice.
        
        Args:
            voice_index: Index of the voice to use
            
        Returns:
            success: Whether voice was changed successfully
        """
        if not self.is_initialized or voice_index >= len(self.available_voices):
            return False
        
        try:
            self.current_voice = self.available_voices[voice_index]
            self.engine.setProperty('voice', self.current_voice.id)
            self.voice_id = voice_index
            
            print(f"🎭 Voice changed to index: {voice_index}")
            return True
            
        except Exception as e:
            print(f"❌ Voice change error: {e}")
            return False
    
    def set_speech_rate(self, rate: int):
        """Set speech rate (words per minute)."""
        self.rate = max(50, min(300, rate))  # Reasonable bounds
        self.engine.setProperty('rate', self.rate)
        print(f"📊 Speech rate set to: {self.rate} wpm")
    
    def set_volume(self, volume: float):
        """Set speech volume (0.0 to 1.0)."""
        self.volume = max(0.0, min(1.0, volume))
        self.engine.setProperty('volume', self.volume)
        print(f"🔊 Volume set to: {self.volume}")
    
    def get_available_voices(self) -> List[Dict[str, Any]]:
        """Get list of available voices with details."""
        voices = []
        for i, voice in enumerate(self.available_voices):
            voices.append({
                'index': i,
                'id': voice.id,
                'name': voice.name,
                'gender': getattr(voice, 'gender', 'unknown'),
                'languages': getattr(voice, 'languages', [])
            })
        return voices
    
    def stop_speech(self):
        """Stop current speech immediately."""
        if self.engine:
            self.engine.stop()
            self.is_speaking = False
            print("⏹️ Speech stopped")
    
    def wait_until_finished(self, timeout: float = None) -> bool:
        """
        Wait until all speech is finished.
        
        Args:
            timeout: Maximum time to wait in seconds
            
        Returns:
            finished: Whether speech finished within timeout
        """
        start_time = time.time()
        while self.is_speaking:
            if timeout and (time.time() - start_time) > timeout:
                return False
            time.sleep(0.1)
        return True
    
    def get_speech_stats(self) -> Dict[str, Any]:
        """Get TTS statistics."""
        return {
            'is_initialized': self.is_initialized,
            'is_speaking': self.is_speaking,
            'total_utterances': self.speech_stats['total_utterances'],
            'total_characters': self.speech_stats['total_characters'],
            'average_speech_time': self.speech_stats['average_speech_time'],
            'last_utterance': self.speech_stats['last_utterance'],
            'queue_size': self.speech_queue.qsize(),
            'current_voice': self.current_voice.name if self.current_voice else 'None',
            'speech_rate': self.rate,
            'volume': self.volume
        }
    
    def reset_stats(self):
        """Reset speech statistics."""
        self.speech_stats = {
            'total_utterances': 0,
            'total_characters': 0,
            'last_utterance': None,
            'average_speech_time': 0
        }
        print("🔄 TTS statistics reset")
    
    # Callback setters
    def set_speech_start_callback(self, callback: Callable):
        """Set callback for speech start."""
        self.on_speech_start = callback
    
    def set_speech_end_callback(self, callback: Callable):
        """Set callback for speech end."""
        self.on_speech_end = callback
    
    def set_error_callback(self, callback: Callable):
        """Set callback for error handling."""
        self.on_error = callback
    
    def __del__(self):
        """Clean up TTS engine."""
        try:
            eng = getattr(self, 'engine', None)
            if eng is not None:
                try:
                    eng.stop()
                except Exception:
                    pass
        finally:
            try:
                self.engine = None
            except Exception:
                pass