# src/decision_engine/approval_manager.py
from datetime import datetime
from typing import Dict, List, Any, Optional
import json

class ApprovalManager:
    """
    Manages approval workflows for significant system changes,
    ensuring human oversight for critical decisions.
    """
    
    def __init__(self):
        self.pending_approvals = []
        self.approval_history = []
        self.approval_rules = {
            'architecture_changes': 'medium',  # low, medium, high, critical
            'learning_parameter_changes': 'low',
            'safety_mechanism_changes': 'critical',
            'data_source_changes': 'high',
            'evolution_operations': 'medium'
        }
        
        # Approval thresholds (0-1, higher = more strict)
        self.approval_thresholds = {
            'low': 0.3,
            'medium': 0.5,
            'high': 0.7,
            'critical': 0.9
        }
        
        print("✅ Approval Manager initialized")
    
    def requires_approval(self, change_type: str, change_details: Dict, 
                         auto_approval_confidence: float) -> bool:
        """
        Determine if a change requires human approval.
        
        Args:
            change_type: Type of change being proposed
            change_details: Detailed information about the change
            auto_approval_confidence: System's confidence in the change (0-1)
            
        Returns:
            requires_approval: Whether human approval is needed
        """
        # Get required approval level for this change type
        required_level = self.approval_rules.get(change_type, 'medium')
        threshold = self.approval_thresholds.get(required_level, 0.5)
        
        # Check if auto-approval confidence meets threshold
        if auto_approval_confidence >= threshold:
            return False
        
        # Special cases that always require approval
        if change_details.get('risk_level') == 'critical':
            return True
        
        if change_details.get('affects_safety', False):
            return True
        
        return True
    
    def submit_for_approval(self, change_request: Dict) -> str:
        """
        Submit a change request for human approval.
        
        Args:
            change_request: Complete change request details
            
        Returns:
            approval_id: Unique ID for tracking this approval request
        """
        approval_id = f"approval_{len(self.pending_approvals)}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        approval_request = {
            'approval_id': approval_id,
            'timestamp': datetime.now().isoformat(),
            'change_request': change_request,
            'status': 'pending',
            'submission_reason': change_request.get('reason', 'Evolution suggestion'),
            'risk_assessment': self._assess_risk(change_request)
        }
        
        self.pending_approvals.append(approval_request)
        
        print(f"📋 Approval submitted: {approval_id} - {change_request.get('type', 'unknown')}")
        return approval_id
    
    def _assess_risk(self, change_request: Dict) -> Dict:
        """Assess the risk level of a change request"""
        risk_factors = {
            'architecture_complexity': change_request.get('complexity_change', 0) / 100.0,
            'system_impact': change_request.get('system_impact', 0.5),
            'rollback_difficulty': change_request.get('rollback_difficulty', 0.3),
            'data_dependencies': change_request.get('data_dependencies', 0.2)
        }
        
        overall_risk = sum(risk_factors.values()) / len(risk_factors)
        
        return {
            'overall_risk': overall_risk,
            'risk_factors': risk_factors,
            'risk_level': 'low' if overall_risk < 0.3 else 'medium' if overall_risk < 0.6 else 'high'
        }
    
    def get_pending_approvals(self) -> List[Dict]:
        """Get list of pending approval requests"""
        return self.pending_approvals.copy()
    
    def approve_change(self, approval_id: str, approver: str = "user", 
                      notes: str = "") -> bool:
        """
        Approve a pending change request.
        
        Args:
            approval_id: ID of the approval request
            approver: Who is approving the change
            notes: Additional notes about the approval
            
        Returns:
            success: Whether approval was successful
        """
        for i, approval in enumerate(self.pending_approvals):
            if approval['approval_id'] == approval_id:
                approval['status'] = 'approved'
                approval['approved_by'] = approver
                approval['approval_timestamp'] = datetime.now().isoformat()
                approval['approval_notes'] = notes
                
                # Move to history
                self.approval_history.append(approval)
                self.pending_approvals.pop(i)
                
                print(f"✅ Change approved: {approval_id}")
                return True
        
        print(f"❌ Approval not found: {approval_id}")
        return False
    
    def reject_change(self, approval_id: str, rejecter: str = "user",
                     reason: str = "") -> bool:
        """
        Reject a pending change request.
        
        Args:
            approval_id: ID of the approval request
            rejecter: Who is rejecting the change
            reason: Reason for rejection
            
        Returns:
            success: Whether rejection was successful
        """
        for i, approval in enumerate(self.pending_approvals):
            if approval['approval_id'] == approval_id:
                approval['status'] = 'rejected'
                approval['rejected_by'] = rejecter
                approval['rejection_timestamp'] = datetime.now().isoformat()
                approval['rejection_reason'] = reason
                
                # Move to history
                self.approval_history.append(approval)
                self.pending_approvals.pop(i)
                
                print(f"❌ Change rejected: {approval_id}")
                return True
        
        print(f"❌ Approval not found: {approval_id}")
        return False
    
    def get_approval_stats(self) -> Dict:
        """Get approval management statistics"""
        total_processed = len(self.approval_history)
        approved = sum(1 for a in self.approval_history if a['status'] == 'approved')
        rejected = sum(1 for a in self.approval_history if a['status'] == 'rejected')
        
        return {
            'pending_approvals': len(self.pending_approvals),
            'total_processed': total_processed,
            'approval_rate': f"{(approved/total_processed*100) if total_processed > 0 else 0:.1f}%",
            'approved_count': approved,
            'rejected_count': rejected,
            'average_processing_time': 'N/A'  # Could calculate from timestamps
        }
    
    def update_approval_rules(self, new_rules: Dict):
        """Update approval rules based on experience or user preference"""
        self.approval_rules.update(new_rules)
        print("📝 Approval rules updated")