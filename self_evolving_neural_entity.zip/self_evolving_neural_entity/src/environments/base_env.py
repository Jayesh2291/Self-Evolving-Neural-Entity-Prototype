# src/environments/base_env.py
from abc import ABC, abstractmethod
from typing import Any, Tuple, Dict
import numpy as np

class BaseEnvironment(ABC):
    """
    Abstract base class for all training environments.
    
    This defines the interface that all environments must implement
    to be compatible with the Self-Evolving Neural Entity.
    """
    
    def __init__(self, name: str = "BaseEnvironment"):
        self.name = name
        self.episode_count = 0
        self.total_steps = 0
        self.is_rendering = False
        
    @abstractmethod
    def reset(self) -> Any:
        """
        Reset the environment to initial state.
        
        Returns:
            observation: Initial observation/state
        """
        pass
    
    @abstractmethod
    def step(self, action: Any) -> Tuple[Any, float, bool, Dict]:
        """
        Take a step in the environment.
        
        Args:
            action: Action to take in the environment
            
        Returns:
            observation: New observation/state
            reward: Reward received
            done: Whether episode is complete
            info: Additional information
        """
        pass
    
    @abstractmethod
    def get_action_space(self) -> Any:
        """
        Get the action space of the environment.
        
        Returns:
            action_space: Description of possible actions
        """
        pass
    
    @abstractmethod
    def get_observation_space(self) -> Any:
        """
        Get the observation space of the environment.
        
        Returns:
            observation_space: Description of possible observations
        """
        pass
    
    def render(self) -> None:
        """Render the current state of the environment."""
        print(f"Rendering {self.name} - Override this method for visual rendering")
    
    def close(self) -> None:
        """Clean up environment resources."""
        print(f"Closing {self.name}")
    
    def get_stats(self) -> Dict:
        """Get environment statistics."""
        return {
            'name': self.name,
            'episode_count': self.episode_count,
            'total_steps': self.total_steps,
            'is_rendering': self.is_rendering
        }
    
    def seed(self, seed: int) -> None:
        """Set random seed for reproducibility."""
        np.random.seed(seed)
        print(f"🎲 Environment seeded with: {seed}")