# src/interaction/internet_tools/__init__.py
"""
Internet tools for research and data access.

This module provides safe, controlled internet access for the
Self-Evolving Neural Entity to research information and gather data.
"""

from .safe_browser import SafeBrowser
from .research_assistant import ResearchAssistant
from .data_scraper import DataScraper

__all__ = [
    'SafeBrowser',
    'ResearchAssistant', 
    'DataScraper'
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Safe internet access and research tools'

print("🌐 SENE Internet Tools loaded - Safe web access ready")