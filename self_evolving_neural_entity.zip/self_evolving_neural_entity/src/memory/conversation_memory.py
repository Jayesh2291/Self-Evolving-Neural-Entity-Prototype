# src/memory/conversation_memory.py
import json
import pickle
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from collections import defaultdict, deque
import numpy as np

class ConversationMemory:
    """
    Persistent conversation memory for long-term interaction history.
    
    Stores and retrieves conversation history, user preferences,
    and interaction patterns to enable personalized responses.
    """
    
    def __init__(self, max_memory_size: int = 10000, memory_file: str = "conversation_memory.pkl"):
        self.max_memory_size = max_memory_size
        self.memory_file = memory_file
        
        # Memory storage
        self.conversations = deque(maxlen=max_memory_size)
        self.user_preferences = {}
        self.interaction_patterns = defaultdict(list)
        
        # Memory statistics
        self.memory_stats = {
            'total_conversations': 0,
            'active_conversations': 0,
            'memory_usage_mb': 0,
            'last_saved': None
        }
        
        # Load existing memory
        self._load_memory()
        
        print(f"💭 Conversation Memory initialized ({len(self.conversations)} conversations loaded)")
    
    def _load_memory(self):
        """Load conversation memory from disk."""
        try:
            with open(self.memory_file, 'rb') as f:
                saved_data = pickle.load(f)
                self.conversations = saved_data.get('conversations', deque(maxlen=self.max_memory_size))
                self.user_preferences = saved_data.get('user_preferences', {})
                self.interaction_patterns = saved_data.get('interaction_patterns', defaultdict(list))
                
            self.memory_stats['total_conversations'] = len(self.conversations)
            self.memory_stats['last_saved'] = datetime.now().isoformat()
            print(f"✅ Loaded {len(self.conversations)} conversations from memory")
            
        except FileNotFoundError:
            print("📝 No existing memory file found. Starting fresh.")
        except Exception as e:
            print(f"❌ Error loading memory: {e}. Starting fresh.")
    
    def save_memory(self):
        """Save conversation memory to disk."""
        try:
            memory_data = {
                'conversations': self.conversations,
                'user_preferences': self.user_preferences,
                'interaction_patterns': self.interaction_patterns,
                'metadata': {
                    'saved_at': datetime.now().isoformat(),
                    'version': '1.0',
                    'total_entries': len(self.conversations)
                }
            }
            
            with open(self.memory_file, 'wb') as f:
                pickle.dump(memory_data, f)
            
            self.memory_stats['last_saved'] = datetime.now().isoformat()
            print(f"💾 Memory saved: {len(self.conversations)} conversations")
            
        except Exception as e:
            print(f"❌ Error saving memory: {e}")
    
    def add_conversation(self, user_input: str, system_response: str, 
                        metadata: Dict[str, Any] = None) -> str:
        """
        Add a conversation turn to memory.
        
        Args:
            user_input: What the user said
            system_response: How the system responded
            metadata: Additional context information
            
        Returns:
            conversation_id: Unique ID for the conversation entry
        """
        conversation_id = f"conv_{len(self.conversations)}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        conversation_entry = {
            'id': conversation_id,
            'timestamp': datetime.now().isoformat(),
            'user_input': user_input,
            'system_response': system_response,
            'metadata': metadata or {},
            'topics': self._extract_topics(user_input + " " + system_response),
            'sentiment': self._analyze_sentiment(user_input),
            'interaction_type': self._classify_interaction(user_input)
        }
        
        self.conversations.append(conversation_entry)
        self.memory_stats['total_conversations'] = len(self.conversations)
        
        # Update interaction patterns
        self._update_interaction_patterns(conversation_entry)
        
        # Auto-save periodically
        if len(self.conversations) % 10 == 0:
            self.save_memory()
        
        return conversation_id
    
    def _extract_topics(self, text: str) -> List[str]:
        """Extract topics from conversation text."""
        # Simple keyword-based topic extraction
        # In practice, you might use NLP libraries like spaCy or NLTK
        topics = []
        text_lower = text.lower()
        
        topic_keywords = {
            'architecture': ['layer', 'network', 'neural', 'architecture', 'structure'],
            'training': ['train', 'learn', 'practice', 'episode', 'reward', 'loss'],
            'evolution': ['evolve', 'improve', 'optimize', 'enhance', 'better', 'upgrade'],
            'research': ['research', 'search', 'find', 'look up', 'information', 'paper'],
            'safety': ['safe', 'danger', 'risk', 'careful', 'protection', 'secure'],
            'performance': ['performance', 'speed', 'efficient', 'fast', 'slow'],
            'applications': ['app', 'application', 'project', 'stock', 'game', 'predict']
        }
        
        for topic, keywords in topic_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                topics.append(topic)
        
        return topics if topics else ['general']
    
    def _analyze_sentiment(self, text: str) -> str:
        """Analyze sentiment of user input."""
        # Simple sentiment analysis
        # In practice, use a proper sentiment analysis model
        positive_words = ['good', 'great', 'excellent', 'awesome', 'thanks', 'thank you', 'perfect']
        negative_words = ['bad', 'terrible', 'wrong', 'error', 'mistake', 'fix', 'broken']
        
        text_lower = text.lower()
        
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            return 'positive'
        elif negative_count > positive_count:
            return 'negative'
        else:
            return 'neutral'
    
    def _classify_interaction(self, user_input: str) -> str:
        """Classify the type of interaction."""
        input_lower = user_input.lower()
        
        if any(word in input_lower for word in ['how', 'what', 'when', 'where', 'why']):
            return 'question'
        elif any(word in input_lower for word in ['do', 'make', 'create', 'build', 'add', 'remove']):
            return 'command'
        elif any(word in input_lower for word in ['thanks', 'thank you', 'good job']):
            return 'appreciation'
        elif any(word in input_lower for word in ['help', 'assist', 'support']):
            return 'help_request'
        else:
            return 'conversation'
    
    def _update_interaction_patterns(self, conversation: Dict):
        """Update interaction patterns based on new conversation."""
        interaction_type = conversation['interaction_type']
        topics = conversation['topics']
        sentiment = conversation['sentiment']
        
        # Track frequency of interaction types
        self.interaction_patterns['type_frequency'].append(interaction_type)
        
        # Track topic preferences
        for topic in topics:
            self.interaction_patterns['topic_preferences'].append(topic)
        
        # Track sentiment patterns
        self.interaction_patterns['sentiment_history'].append(sentiment)
        
        # Keep patterns within reasonable limits
        for key in self.interaction_patterns:
            if len(self.interaction_patterns[key]) > 1000:
                self.interaction_patterns[key] = self.interaction_patterns[key][-1000:]
    
    def get_recent_conversations(self, count: int = 10) -> List[Dict]:
        """Get recent conversations."""
        return list(self.conversations)[-count:] if self.conversations else []
    
    def search_conversations(self, query: str, max_results: int = 5) -> List[Dict]:
        """Search conversations by content."""
        results = []
        query_lower = query.lower()
        
        for conversation in reversed(self.conversations):
            if (query_lower in conversation['user_input'].lower() or 
                query_lower in conversation['system_response'].lower()):
                results.append(conversation)
                if len(results) >= max_results:
                    break
        
        return results
    
    def get_conversations_by_topic(self, topic: str, max_results: int = 5) -> List[Dict]:
        """Get conversations about a specific topic."""
        return [conv for conv in self.conversations if topic in conv['topics']][-max_results:]
    
    def get_user_preferences(self) -> Dict[str, Any]:
        """Get learned user preferences."""
        # Analyze interaction patterns to infer preferences
        if not self.interaction_patterns:
            return {}
        
        preferences = {}
        
        # Infer preferred interaction style
        type_counts = defaultdict(int)
        for interaction_type in self.interaction_patterns.get('type_frequency', []):
            type_counts[interaction_type] += 1
        
        if type_counts:
            preferred_interaction = max(type_counts, key=type_counts.get)
            preferences['interaction_style'] = preferred_interaction
        
        # Infer topic preferences
        topic_counts = defaultdict(int)
        for topic in self.interaction_patterns.get('topic_preferences', []):
            topic_counts[topic] += 1
        
        if topic_counts:
            top_topics = sorted(topic_counts.items(), key=lambda x: x[1], reverse=True)[:3]
            preferences['preferred_topics'] = [topic for topic, count in top_topics]
        
        # Infer risk tolerance from sentiment and command patterns
        negative_count = self.interaction_patterns.get('sentiment_history', []).count('negative')
        total_sentiments = len(self.interaction_patterns.get('sentiment_history', []))
        
        if total_sentiments > 0:
            negative_ratio = negative_count / total_sentiments
            if negative_ratio < 0.1:
                preferences['risk_tolerance'] = 'high'
            elif negative_ratio < 0.3:
                preferences['risk_tolerance'] = 'medium'
            else:
                preferences['risk_tolerance'] = 'low'
        
        return preferences
    
    def update_user_preference(self, key: str, value: Any):
        """Explicitly update a user preference."""
        self.user_preferences[key] = {
            'value': value,
            'source': 'explicit',
            'updated_at': datetime.now().isoformat()
        }
        self.save_memory()
    
    def get_conversation_statistics(self) -> Dict[str, Any]:
        """Get comprehensive conversation statistics."""
        if not self.conversations:
            return {'total_conversations': 0}
        
        # Calculate various statistics
        total_conversations = len(self.conversations)
        
        # Interaction type distribution
        type_counts = defaultdict(int)
        for conv in self.conversations:
            type_counts[conv['interaction_type']] += 1
        
        # Topic distribution
        topic_counts = defaultdict(int)
        for conv in self.conversations:
            for topic in conv['topics']:
                topic_counts[topic] += 1
        
        # Sentiment distribution
        sentiment_counts = defaultdict(int)
        for conv in self.conversations:
            sentiment_counts[conv['sentiment']] += 1
        
        # Recent activity (last 7 days)
        week_ago = datetime.now() - timedelta(days=7)
        recent_activity = sum(1 for conv in self.conversations 
                             if datetime.fromisoformat(conv['timestamp']) > week_ago)
        
        return {
            'total_conversations': total_conversations,
            'recent_activity_7d': recent_activity,
            'interaction_type_distribution': dict(type_counts),
            'topic_distribution': dict(topic_counts),
            'sentiment_distribution': dict(sentiment_counts),
            'memory_size_mb': self.memory_stats['memory_usage_mb'],
            'last_saved': self.memory_stats['last_saved'],
            'user_preferences_count': len(self.user_preferences)
        }
    
    def clear_memory(self, confirm: bool = False) -> bool:
        """Clear all conversation memory."""
        if not confirm:
            print("⚠️  Pass confirm=True to clear memory")
            return False
        
        self.conversations.clear()
        self.user_preferences.clear()
        self.interaction_patterns.clear()
        self.memory_stats['total_conversations'] = 0
        
        self.save_memory()
        print("🗑️  All conversation memory cleared")
        return True
    
    def export_memory(self, filepath: str) -> bool:
        """Export memory to JSON file for analysis."""
        try:
            export_data = {
                'conversations': list(self.conversations),
                'user_preferences': self.user_preferences,
                'interaction_patterns': dict(self.interaction_patterns),
                'statistics': self.get_conversation_statistics(),
                'exported_at': datetime.now().isoformat()
            }
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)
            
            print(f"📤 Memory exported to: {filepath}")
            return True
            
        except Exception as e:
            print(f"❌ Export failed: {e}")
            return False