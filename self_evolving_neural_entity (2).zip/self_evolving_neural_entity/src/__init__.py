# src/__init__.py
"""
Self-Evolving Neural Entity (SENE) - Core Package

A comprehensive AI system that can learn, evolve, and interact naturally
through voice commands and intelligent decision-making.
"""

from .core import ENNCore, EWC, OnlineLearner, ReplayBuffer
from .evolution import (
    EvolutionEngine, 
    AddLayerOperator, RemoveLayerOperator,
    AttentionMechanismOperator, ActivationFunctionOperator, LearningRateAdaptationOperator
)
from .interaction import (
    VoiceInterface, TextToSpeech, WakeWordDetector,
    IntentRecognizer, ActionMapper, ContextTracker,
    SafeBrowser, ResearchAssistant, DataScraper
)
from .memory import ConversationMemory, DecisionLogger, ContextWindow
from .environments import BaseEnvironment, CartPoleEnvironment
from .decision_engine import CollaborativeDecider, SuggestionEngine, ApprovalManager
from .applications import StockPredictorSENE, GameAI
from .utils import (
    ConfigManager, SENEConfig,
    SeneLogger, PerformanceTracker,
    SafetyMonitor,
    ModelSerializer, DataSerializer
)

__all__ = [
    # Core Neural Network
    'ENNCore', 'EWC', 'OnlineLearner', 'ReplayBuffer',
    
    # Evolution System
    'EvolutionEngine',
    'AddLayerOperator', 'RemoveLayerOperator',
    'AttentionMechanismOperator', 'ActivationFunctionOperator', 'LearningRateAdaptationOperator',
    
    # Interaction System
    'VoiceInterface', 'TextToSpeech', 'WakeWordDetector',
    'IntentRecognizer', 'ActionMapper', 'ContextTracker',
    'SafeBrowser', 'ResearchAssistant', 'DataScraper',
    
    # Memory System
    'ConversationMemory', 'DecisionLogger', 'ContextWindow',
    
    # Environments
    'BaseEnvironment', 'CartPoleEnvironment',
    
    # Decision Engine
    'CollaborativeDecider', 'SuggestionEngine', 'ApprovalManager',
    
    # Applications
    'StockPredictorSENE', 'GameAI',
    
    # Utilities
    'ConfigManager', 'SENEConfig',
    'SeneLogger', 'PerformanceTracker',
    'SafetyMonitor',
    'ModelSerializer', 'DataSerializer',
    
    # Main System
    'SelfEvolvingNeuralEntity', 'create_sene_system'
]

# Package metadata
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Self-Evolving Neural Entity - An AI that grows with you'
__url__ = 'https://github.com/sene-project/self-evolving-neural-entity'

# Import all modules to ensure they're loaded
def _initialize_package():
    """Initialize all SENE components."""
    print("=" * 60)
    print("🧠 SELF-EVOLVING NEURAL ENTITY")
    print("=" * 60)
    print("Initializing AI system components...")
    
    # Component initialization messages
    components = [
        ("Core Neural Network", "🧠"),
        ("Evolution Engine", "🧬"), 
        ("Voice Interface", "🎤"),
        ("Memory System", "💭"),
        ("Decision Engine", "🤖"),
        ("Safety Monitor", "🛡️"),
        ("Application Layer", "🚀")
    ]
    
    for component, icon in components:
        print(f"   {icon} {component}... READY")
    
    print("=" * 60)
    print("✅ SENE System Initialized Successfully!")
    print("   Say 'SENE' to wake up and start interacting")
    print("   Available commands: 'add layer', 'train', 'evolve', 'status'")
    print("=" * 60)

# Initialize when package is imported
_initialize_package()

# Convenience function to create a complete SENE system
def create_sene_system(config_name: str = "balanced"):
    """
    Create a complete SENE system with all components.
    
    Args:
        config_name: Configuration preset name
        
    Returns:
        sene_system: Complete SENE system instance
    """
    from .main import SelfEvolvingNeuralEntity
    return SelfEvolvingNeuralEntity(config_name)

# Export the main system class
from .main import SelfEvolvingNeuralEntity