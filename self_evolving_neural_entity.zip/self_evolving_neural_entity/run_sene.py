# run_sene.py (place this in the root directory)
"""
Launcher for Self-Evolving Neural Entity
"""

import sys
import os

# Add the src directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, 'src')
sys.path.insert(0, src_dir)

def main():
    """Main entry point for SENE system."""
    try:
        from main import demo_sene_system
        print("🚀 Launching Self-Evolving Neural Entity...")
        demo_sene_system()
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("Please make sure all required dependencies are installed.")
        print("Run: pip install -r requirements.txt")
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()