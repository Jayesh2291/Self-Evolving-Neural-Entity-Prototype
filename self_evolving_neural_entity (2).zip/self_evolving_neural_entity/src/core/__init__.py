# src/core/__init__.py
"""
Core neural network components for the Self-Evolving Neural Entity.

This module contains the main neural network architecture and learning algorithms
that enable the system to evolve and learn continuously.
"""

from .enn import ENNCore
from .learning import EWC, OnlineLearner, ReplayBuffer

__all__ = [
    'ENNCore',           # Main neural network
    'EWC',               # Elastic Weight Consolidation
    'OnlineLearner',     # Continuous learning manager
    'ReplayBuffer'       # Experience replay
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Core neural network and learning algorithms'

print("🧠 SENE Core module loaded - Neural network and learning algorithms ready")