# src/interaction/internet_tools/research_assistant.py
import time
from typing import Dict, List, Optional, Any
from datetime import datetime
from .safe_browser import SafeBrowser

class ResearchAssistant:
    """
    AI research assistant that helps gather and synthesize information.
    
    Provides intelligent research capabilities for the SENE system
    to learn from online resources and stay updated.
    """
    
    def __init__(self):
        self.browser = SafeBrowser()
        self.research_history = []
        self.research_topics = [
            'neural architecture search',
            'continual learning',
            'reinforcement learning',
            'transformers',
            'self-supervised learning',
            'explainable AI'
        ]
        
        # Research templates
        self.research_templates = {
            'paper_review': {
                'sources': ['arxiv'],
                'queries': ['latest research', 'state of the art', 'recent advances'],
                'max_results': 5
            },
            'tutorial_learning': {
                'sources': ['documentation'],
                'queries': ['tutorial', 'guide', 'how to', 'best practices'],
                'max_results': 3
            },
            'news_update': {
                'sources': ['news'],
                'queries': ['latest news', 'recent developments', 'breakthrough'],
                'max_results': 5
            }
        }
        
        print("🔬 Research Assistant initialized")
    
    def conduct_research(self, topic: str, research_type: str = 'paper_review') -> Dict[str, Any]:
        """
        Conduct research on a specific topic.
        
        Args:
            topic: Research topic
            research_type: Type of research to conduct
            
        Returns:
            research_results: Comprehensive research findings
        """
        print(f"🔬 Researching: {topic} ({research_type})")
        
        if research_type not in self.research_templates:
            print(f"❌ Unknown research type: {research_type}")
            return {'error': 'Unknown research type'}
        
        template = self.research_templates[research_type]
        all_findings = []
        
        # Generate search queries
        queries = self._generate_search_queries(topic, template['queries'])
        
        # Search across sources
        for source in template['sources']:
            for query in queries:
                if source == 'arxiv':
                    findings = self.browser.search_arxiv(query, template['max_results'])
                    for finding in findings:
                        finding['source'] = 'arxiv'
                        finding['search_query'] = query
                    all_findings.extend(findings)
                
                # Additional sources can be added here
        
        # Analyze and synthesize findings
        synthesized = self._synthesize_findings(all_findings, topic)
        
        # Record research session
        research_record = {
            'timestamp': datetime.now().isoformat(),
            'topic': topic,
            'research_type': research_type,
            'queries_used': queries,
            'findings_count': len(all_findings),
            'synthesized_summary': synthesized.get('summary', ''),
            'key_insights': synthesized.get('key_insights', [])
        }
        
        self.research_history.append(research_record)
        
        print(f"✅ Research completed: {len(all_findings)} findings synthesized")
        return synthesized
    
    def _generate_search_queries(self, topic: str, base_queries: List[str]) -> List[str]:
        """
        Generate search queries for a topic.
        
        Args:
            topic: Research topic
            base_queries: Base query templates
            
        Returns:
            queries: Generated search queries
        """
        queries = []
        for base_query in base_queries:
            queries.append(f"{topic} {base_query}")
            queries.append(f"{base_query} {topic}")
        
        # Add current year for recency
        current_year = datetime.now().year
        queries.append(f"{topic} {current_year}")
        queries.append(f"latest {topic} {current_year}")
        
        return queries
    
    def _synthesize_findings(self, findings: List[Dict], topic: str) -> Dict[str, Any]:
        """
        Synthesize research findings into a coherent summary.
        
        Args:
            findings: Raw research findings
            topic: Research topic
            
        Returns:
            synthesized: Synthesized research results
        """
        if not findings:
            return {
                'summary': f"No recent research found on {topic}",
                'key_insights': [],
                'sources': [],
                'recommendations': ['Try broadening the search terms']
            }
        
        # Extract key information
        recent_papers = [f for f in findings if f.get('source') == 'arxiv']
        titles = [f['title'] for f in recent_papers if 'title' in f]
        summaries = [f['summary'] for f in recent_papers if 'summary' in f]
        
        # Generate summary (in a real system, this would use NLP)
        summary = f"Found {len(recent_papers)} recent papers on {topic}. "
        if titles:
            summary += f"Key papers include: {', '.join(titles[:3])}. "
        
        # Extract key insights (simplified)
        key_insights = []
        for finding in recent_papers[:5]:
            insight = {
                'title': finding.get('title', 'Unknown'),
                'key_point': finding.get('summary', '')[:100] + '...',
                'source': finding.get('source', 'unknown'),
                'url': finding.get('url', '')
            }
            key_insights.append(insight)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(findings, topic)
        
        return {
            'summary': summary,
            'key_insights': key_insights,
            'sources': list(set(f.get('source', 'unknown') for f in findings)),
            'total_findings': len(findings),
            'recommendations': recommendations,
            'timestamp': datetime.now().isoformat()
        }
    
    def _generate_recommendations(self, findings: List[Dict], topic: str) -> List[str]:
        """
        Generate actionable recommendations based on research.
        
        Args:
            findings: Research findings
            topic: Research topic
            
        Returns:
            recommendations: List of recommendations
        """
        recommendations = []
        
        # Count findings by type
        arxiv_papers = [f for f in findings if f.get('source') == 'arxiv']
        
        if len(arxiv_papers) > 10:
            recommendations.append(f"Strong research activity in {topic} - consider implementing recent techniques")
        elif len(arxiv_papers) < 3:
            recommendations.append(f"Limited recent research on {topic} - consider alternative approaches")
        
        # Look for specific techniques mentioned
        technique_keywords = ['transformer', 'attention', 'reinforcement', 'self-supervised']
        for keyword in technique_keywords:
            if any(keyword in finding.get('title', '').lower() or 
                   keyword in finding.get('summary', '').lower() 
                   for finding in findings):
                recommendations.append(f"Consider exploring {keyword} techniques for {topic}")
        
        # Always include some general recommendations
        recommendations.extend([
            "Review the key papers for implementation details",
            "Consider testing the most cited approaches",
            "Evaluate computational requirements before implementation"
        ])
        
        return recommendations
    
    def research_ai_advancements(self) -> Dict[str, Any]:
        """
        Research latest AI advancements for system improvement.
        
        Returns:
            advancements: Latest AI advancements
        """
        print("🔬 Researching latest AI advancements...")
        
        all_advancements = []
        
        # Research multiple AI topics
        for topic in self.research_topics:
            advancements = self.conduct_research(topic, 'paper_review')
            if advancements and 'key_insights' in advancements:
                all_advancements.append({
                    'topic': topic,
                    'advancements': advancements['key_insights'],
                    'summary': advancements['summary']
                })
        
        # Generate overall AI landscape
        landscape = self._generate_ai_landscape(all_advancements)
        
        return {
            'ai_landscape': landscape,
            'topics_researched': [adv['topic'] for adv in all_advancements],
            'total_advancements_found': sum(len(adv['advancements']) for adv in all_advancements),
            'timestamp': datetime.now().isoformat()
        }
    
    def _generate_ai_landscape(self, advancements: List[Dict]) -> Dict[str, Any]:
        """
        Generate AI research landscape from advancements.
        
        Args:
            advancements: List of topic advancements
            
        Returns:
            landscape: AI research landscape
        """
        hot_topics = []
        emerging_trends = []
        
        for topic_adv in advancements:
            topic = topic_adv['topic']
            advancement_count = len(topic_adv['advancements'])
            
            if advancement_count >= 4:
                hot_topics.append(topic)
            elif advancement_count > 0:
                emerging_trends.append(topic)
        
        return {
            'hot_topics': hot_topics,
            'emerging_trends': emerging_trends,
            'research_intensity': len(advancements),
            'recommended_focus': hot_topics[:2] if hot_topics else emerging_trends[:2]
        }
    
    def get_research_stats(self) -> Dict[str, Any]:
        """Get research assistant statistics."""
        return {
            'total_research_sessions': len(self.research_history),
            'research_topics_covered': len(set(session['topic'] for session in self.research_history)),
            'average_findings_per_session': (
                sum(session['findings_count'] for session in self.research_history) / 
                len(self.research_history) if self.research_history else 0
            ),
            'browser_stats': self.browser.get_browser_stats(),
            'available_research_templates': list(self.research_templates.keys())
        }
    
    def add_research_topic(self, topic: str):
        """
        Add a new research topic.
        
        Args:
            topic: Topic to add
        """
        if topic not in self.research_topics:
            self.research_topics.append(topic)
            print(f"✅ Added research topic: {topic}")