# src/memory/context_window.py
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from collections import deque
import numpy as np

class ContextWindow:
    """
    Dynamic context window for managing short-term memory and attention.
    
    Maintains a sliding window of recent information to provide
    context-aware responses and prevent information overload.
    """
    
    def __init__(self, max_tokens: int = 4000, max_items: int = 100):
        self.max_tokens = max_tokens
        self.max_items = max_items
        
        # Context storage
        self.context_items = deque(maxlen=max_items)
        self.current_tokens = 0
        self.active_context = {}
        
        # Attention mechanisms
        self.attention_weights = {}
        self.relevance_scores = {}
        
        # Context categories
        self.context_categories = {
            'conversation': [],
            'system_state': {},
            'user_preferences': {},
            'recent_decisions': [],
            'active_tasks': []
        }
        
        print(f"🪟 Context Window initialized ({max_tokens} tokens, {max_items} items)")
    
    def add_context(self, item_type: str, content: Any, importance: float = 0.5, 
                   metadata: Dict[str, Any] = None) -> str:
        """
        Add an item to the context window.
        
        Args:
            item_type: Type of context item
            content: The context content
            importance: Importance weight (0.0 to 1.0)
            metadata: Additional metadata
            
        Returns:
            item_id: Unique ID for the context item
        """
        item_id = f"ctx_{len(self.context_items)}_{datetime.now().strftime('%H%M%S')}"
        
        context_item = {
            'id': item_id,
            'type': item_type,
            'content': content,
            'importance': max(0.0, min(1.0, importance)),
            'metadata': metadata or {},
            'timestamp': datetime.now().isoformat(),
            'tokens_estimate': self._estimate_tokens(content),
            'access_count': 0,
            'last_accessed': datetime.now().isoformat()
        }
        
        # Check if we have space
        if self.current_tokens + context_item['tokens_estimate'] > self.max_tokens:
            self._evict_least_important()
        
        self.context_items.append(context_item)
        self.current_tokens += context_item['tokens_estimate']
        
        # Update attention weights
        self._update_attention_weights()
        
        print(f"📝 Added context: {item_type} (importance: {importance:.2f})")
        return item_id
    
    def _estimate_tokens(self, content: Any) -> int:
        """Estimate token count for context management."""
        if isinstance(content, str):
            # Rough estimate: 1 token ≈ 4 characters for English
            return max(1, len(content) // 4)
        elif isinstance(content, (list, dict)):
            # Estimate for structured data
            return len(str(content)) // 4
        else:
            return 1
    
    def _evict_least_important(self):
        """Evict least important items when context window is full."""
        if not self.context_items:
            return
        
        # Calculate scores for eviction
        item_scores = []
        for item in self.context_items:
            score = self._calculate_eviction_score(item)
            item_scores.append((score, item))
        
        # Sort by score (lowest first = most likely to evict)
        item_scores.sort(key=lambda x: x[0])
        
        # Evict items until we have space
        target_tokens = self.max_tokens * 0.8  # Target 80% capacity
        
        while self.current_tokens > target_tokens and item_scores:
            _, item_to_remove = item_scores.pop(0)
            self.context_items.remove(item_to_remove)
            self.current_tokens -= item_to_remove['tokens_estimate']
            
            print(f"🗑️  Evicted context: {item_to_remove['type']} (score: {_[0]:.3f})")
    
    def _calculate_eviction_score(self, item: Dict) -> float:
        """Calculate eviction score for an item (lower = more likely to evict)."""
        # Factors: importance, recency, access frequency
        importance = item['importance']
        
        # Recency factor (newer items are more valuable)
        age_hours = (datetime.now() - datetime.fromisoformat(item['timestamp'])).total_seconds() / 3600
        recency = 1.0 / (1.0 + age_hours)  # Decay over time
        
        # Access frequency factor
        access_factor = min(1.0, item['access_count'] / 10.0)
        
        # Combined score (lower = more likely to evict)
        # We want to keep important, recent, frequently accessed items
        eviction_score = (1.0 - importance) * 0.4 + (1.0 - recency) * 0.4 + (1.0 - access_factor) * 0.2
        
        return eviction_score
    
    def _update_attention_weights(self):
        """Update attention weights based on recent context."""
        # Simple attention mechanism - in practice, could use more sophisticated approaches
        total_importance = sum(item['importance'] for item in self.context_items)
        
        if total_importance > 0:
            for item in self.context_items:
                self.attention_weights[item['id']] = item['importance'] / total_importance
        else:
            # Equal weights if no importance specified
            weight = 1.0 / len(self.context_items) if self.context_items else 0
            for item in self.context_items:
                self.attention_weights[item['id']] = weight
    
    def get_relevant_context(self, query: str = None, item_type: str = None, 
                           max_items: int = 10) -> List[Dict]:
        """
        Get relevant context items based on query or type.
        
        Args:
            query: Optional query to match against content
            item_type: Optional filter by item type
            max_items: Maximum number of items to return
            
        Returns:
            relevant_items: List of relevant context items
        """
        items = list(self.context_items)
        
        # Filter by type if specified
        if item_type:
            items = [item for item in items if item['type'] == item_type]
        
        # Calculate relevance scores if query provided
        if query:
            for item in items:
                item['relevance'] = self._calculate_relevance(item, query)
            
            # Sort by relevance
            items.sort(key=lambda x: x.get('relevance', 0), reverse=True)
        else:
            # Sort by importance and recency
            items.sort(key=lambda x: (
                x['importance'],
                -(datetime.now() - datetime.fromisoformat(x['timestamp'])).total_seconds()
            ), reverse=True)
        
        # Update access counts
        for item in items[:max_items]:
            item['access_count'] += 1
            item['last_accessed'] = datetime.now().isoformat()
        
        return items[:max_items]
    
    def _calculate_relevance(self, item: Dict, query: str) -> float:
        """Calculate relevance score between context item and query."""
        # Simple keyword-based relevance
        # In practice, use embeddings or more sophisticated NLP
        content_str = str(item['content']).lower()
        query_lower = query.lower()
        
        # Check for exact matches
        if query_lower in content_str:
            return 1.0
        
        # Check for partial matches
        query_words = query_lower.split()
        matches = sum(1 for word in query_words if word in content_str)
        
        if query_words:
            return matches / len(query_words)
        else:
            return 0.0
    
    def get_context_summary(self) -> Dict[str, Any]:
        """Get summary of current context window state."""
        type_distribution = {}
        for item in self.context_items:
            item_type = item['type']
            type_distribution[item_type] = type_distribution.get(item_type, 0) + 1
        
        # Calculate average importance
        avg_importance = np.mean([item['importance'] for item in self.context_items]) if self.context_items else 0
        
        return {
            'total_items': len(self.context_items),
            'token_usage': self.current_tokens,
            'token_capacity': self.max_tokens,
            'usage_percentage': f"{(self.current_tokens / self.max_tokens * 100):.1f}%",
            'type_distribution': type_distribution,
            'average_importance': f"{avg_importance:.3f}",
            'oldest_item': self.context_items[0]['timestamp'] if self.context_items else None,
            'newest_item': self.context_items[-1]['timestamp'] if self.context_items else None
        }
    
    def clear_context(self, item_type: str = None):
        """
        Clear context items, optionally by type.
        
        Args:
            item_type: If specified, only clear items of this type
        """
        if item_type:
            items_to_remove = [item for item in self.context_items if item['type'] == item_type]
            for item in items_to_remove:
                self.context_items.remove(item)
                self.current_tokens -= item['tokens_estimate']
            print(f"🗑️  Cleared {len(items_to_remove)} items of type: {item_type}")
        else:
            items_removed = len(self.context_items)
            self.context_items.clear()
            self.current_tokens = 0
            print(f"🗑️  Cleared all {items_removed} context items")
    
    def set_active_context(self, context_key: str, context_value: Any):
        """Set active context for immediate use."""
        self.active_context[context_key] = {
            'value': context_value,
            'set_at': datetime.now().isoformat()
        }
    
    def get_active_context(self, context_key: str = None) -> Any:
        """Get active context value."""
        if context_key:
            return self.active_context.get(context_key, {}).get('value')
        else:
            return self.active_context
    
    def update_category_context(self, category: str, data: Any):
        """Update context in specific categories."""
        if category in self.context_categories:
            if isinstance(self.context_categories[category], list):
                self.context_categories[category].append(data)
                # Keep list manageable
                if len(self.context_categories[category]) > 20:
                    self.context_categories[category] = self.context_categories[category][-10:]
            else:
                self.context_categories[category].update(data)
    
    def get_category_context(self, category: str) -> Any:
        """Get context from specific category."""
        return self.context_categories.get(category)
    
    def compress_context(self, target_tokens: int):
        """
        Compress context to fit within target token limit.
        
        Args:
            target_tokens: Target maximum tokens
        """
        if self.current_tokens <= target_tokens:
            return
        
        print(f"🗜️  Compressing context from {self.current_tokens} to {target_tokens} tokens...")
        
        while self.current_tokens > target_tokens and self.context_items:
            # Remove least important item
            least_important = min(self.context_items, key=lambda x: self._calculate_eviction_score(x))
            self.context_items.remove(least_important)
            self.current_tokens -= least_important['tokens_estimate']
        
        print(f"✅ Context compressed to {self.current_tokens} tokens")