# src/evolution/operators/__init__.py
"""
Evolution operators for neural architecture modification.

This module contains various operators that can modify, grow, or optimize
the neural network architecture during the evolution process.
"""

from .add_layer import AddLayerOperator
from .remove_layer import RemoveLayerOperator
from .advanced_operators import (
    AttentionMechanismOperator,
    ActivationFunctionOperator, 
    LearningRateAdaptationOperator
)

__all__ = [
    'AddLayerOperator',
    'RemoveLayerOperator',
    'AttentionMechanismOperator',
    'ActivationFunctionOperator',
    'LearningRateAdaptationOperator'
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Neural architecture evolution operators'

print("🧬 SENE Evolution Operators loaded - Neural network modification tools ready")