# src/core/learning/replay_buffer.py
import random
import numpy as np
from collections import deque
from datetime import datetime

class ReplayBuffer:
    """
    Experience replay buffer for reinforcement learning and continuous learning.
    
    Stores and samples experiences to break temporal correlations
    and improve learning stability.
    """
    
    def __init__(self, capacity=10000):
        self.buffer = deque(maxlen=capacity)
        self.capacity = capacity
        self.add_count = 0
        
    def add(self, state, action, reward, next_state, done, info=None):
        """
        Add an experience to the buffer.
        
        Args:
            state: Current state
            action: Action taken
            reward: Reward received
            next_state: Next state
            done: Whether episode ended
            info: Additional info (optional)
        """
        experience = {
            'state': state,
            'action': action,
            'reward': reward,
            'next_state': next_state,
            'done': done,
            'info': info or {},
            'timestamp': datetime.now().isoformat(),
            'id': self.add_count
        }
        
        self.buffer.append(experience)
        self.add_count += 1
        
    def sample(self, batch_size):
        """
        Sample a batch of experiences from the buffer.
        
        Args:
            batch_size: Number of experiences to sample
            
        Returns:
            batch: List of sampled experiences
        """
        if len(self.buffer) < batch_size:
            return random.sample(list(self.buffer), len(self.buffer))
        
        return random.sample(list(self.buffer), batch_size)
    
    def sample_prioritized(self, batch_size, priority_key='reward'):
        """
        Sample experiences with priority based on a key.
        
        Args:
            batch_size: Number of experiences to sample
            priority_key: Key to use for prioritization
            
        Returns:
            batch: List of prioritized experiences
        """
        if len(self.buffer) < batch_size:
            return list(self.buffer)
        
        # Simple prioritization based on absolute reward
        priorities = [abs(exp[priority_key]) for exp in self.buffer]
        total_priority = sum(priorities)
        
        if total_priority == 0:
            return self.sample(batch_size)
        
        # Normalize priorities
        probabilities = [p / total_priority for p in priorities]
        
        # Sample according to priorities
        indices = np.random.choice(
            len(self.buffer), 
            size=batch_size, 
            p=probabilities,
            replace=False
        )
        
        return [self.buffer[i] for i in indices]
    
    def clear(self):
        """Clear the replay buffer"""
        self.buffer.clear()
        print("🧹 Replay buffer cleared")
    
    def __len__(self):
        return len(self.buffer)
    
    def get_stats(self):
        """Get statistics about the replay buffer"""
        if not self.buffer:
            return {
                'size': 0,
                'capacity': self.capacity,
                'utilization': 0.0,
                'oldest_experience': None,
                'newest_experience': None
            }
        
        rewards = [exp['reward'] for exp in self.buffer]
        
        return {
            'size': len(self.buffer),
            'capacity': self.capacity,
            'utilization': len(self.buffer) / self.capacity,
            'average_reward': sum(rewards) / len(rewards),
            'min_reward': min(rewards),
            'max_reward': max(rewards),
            'oldest_experience': self.buffer[0]['timestamp'],
            'newest_experience': self.buffer[-1]['timestamp']
        }