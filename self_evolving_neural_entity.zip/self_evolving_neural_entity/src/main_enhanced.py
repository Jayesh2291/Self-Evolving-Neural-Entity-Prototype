# Let's create a enhanced main file with better feedback
# src/main_enhanced.py
import torch
import time
import threading
import json
from datetime import datetime

from self_evolving_neural_entity import SelfEvolvingNeuralEntity  # Add this import if the class is defined in another module

class EnhancedSENE(SelfEvolvingNeuralEntity):
    def __init__(self):
        super().__init__()
        self.conversation_history = []
        self.start_time = datetime.now()
        
    def process_voice_command(self, command_text):
        """Enhanced command processing with memory"""
        action, full_text = self.intent_recognizer.parse_neural_command(command_text)
        
        # Store conversation
        self.conversation_history.append({
            'timestamp': datetime.now().isoformat(),
            'user': command_text,
            'action': action
        })
        
        response = super().process_voice_command(command_text)
        
        # Store system response
        if len(self.conversation_history) > 0:
            self.conversation_history[-1]['system_response'] = response
            
        return response
    
    def get_enhanced_status(self):
        """Enhanced status with conversation history"""
        base_status = self.get_system_status()
        enhanced_status = f"""
{base_status}
• Session Duration: {datetime.now() - self.start_time}
• Conversations: {len(self.conversation_history)}
• Last Command: {self.conversation_history[-1]['user'] if self.conversation_history else 'None'}
• System: READY FOR LIVE INTERACTION
        """
        return enhanced_status.strip()

# Run the enhanced system
if __name__ == "__main__":
    print("🚀 ENHANCED SENE STARTING...")
    print("🎤 Say 'SENE' followed by any command")
    print("💡 Try: add layer, train, evolve, status, research, memory")
    
    enhanced_sene = EnhancedSENE()
    enhanced_sene.start_live_session()
    