# src/utils/logging.py
import logging
import sys
import json
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from pathlib import Path
import threading

class SeneLogger:
    """
    Advanced logging system for SENE with multiple outputs and structured logging.
    
    Provides comprehensive logging capabilities including file logging,
    console output, and structured JSON logging for analysis.
    """
    
    def __init__(self, name: str = "SENE", log_dir: str = "logs", level: str = "INFO"):
        self.name = name
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        
        # Set up logging level
        self.level = getattr(logging, level.upper())
        
        # Initialize logger
        self.logger = logging.getLogger(name)
        self.logger.setLevel(self.level)
        
        # Prevent duplicate handlers
        if not self.logger.handlers:
            self._setup_handlers()
        
        # Structured logging
        self.structured_logs = []
        self.max_structured_logs = 10000
        
        # Performance tracking
        self.performance_data = {}
        self.log_lock = threading.Lock()
        
        print(f"📝 SENE Logger initialized (level: {level})")
    
    def _setup_handlers(self):
        """Set up logging handlers for file and console output."""
        # File handler
        log_file = self.log_dir / f"sene_{datetime.now().strftime('%Y%m%d')}.log"
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(self.level)
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(self.level)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
    
    def info(self, message: str, **kwargs):
        """Log info message with optional structured data."""
        self.logger.info(message)
        self._log_structured('INFO', message, kwargs)
    
    def warning(self, message: str, **kwargs):
        """Log warning message with optional structured data."""
        self.logger.warning(message)
        self._log_structured('WARNING', message, kwargs)
    
    def error(self, message: str, **kwargs):
        """Log error message with optional structured data."""
        self.logger.error(message)
        self._log_structured('ERROR', message, kwargs)
    
    def debug(self, message: str, **kwargs):
        """Log debug message with optional structured data."""
        self.logger.debug(message)
        self._log_structured('DEBUG', message, kwargs)
    
    def critical(self, message: str, **kwargs):
        """Log critical message with optional structured data."""
        self.logger.critical(message)
        self._log_structured('CRITICAL', message, kwargs)
    
    def _log_structured(self, level: str, message: str, data: Dict[str, Any]):
        """Add structured log entry."""
        with self.log_lock:
            log_entry = {
                'timestamp': datetime.now().isoformat(),
                'level': level,
                'message': message,
                'data': data,
                'module': self._get_caller_module()
            }
            
            self.structured_logs.append(log_entry)
            
            # Maintain log size
            if len(self.structured_logs) > self.max_structured_logs:
                self.structured_logs = self.structured_logs[-self.max_structured_logs:]
    
    def _get_caller_module(self) -> str:
        """Get the name of the module that called the logger."""
        import inspect
        frame = inspect.currentframe()
        # Go back through the call stack to find the caller
        for i in range(5):  # Look through 5 frames max
            frame = frame.f_back
            if frame is None:
                return 'unknown'
            module = inspect.getmodule(frame)
            if module and module.__name__ != __name__:
                return module.__name__
        return 'unknown'
    
    def log_performance(self, metric_name: str, value: float, context: Dict = None):
        """
        Log performance metrics for analysis.
        
        Args:
            metric_name: Name of the performance metric
            value: Metric value
            context: Additional context information
        """
        if metric_name not in self.performance_data:
            self.performance_data[metric_name] = []
        
        performance_entry = {
            'timestamp': datetime.now().isoformat(),
            'value': value,
            'context': context or {}
        }
        
        self.performance_data[metric_name].append(performance_entry)
        
        # Keep performance data manageable
        if len(self.performance_data[metric_name]) > 1000:
            self.performance_data[metric_name] = self.performance_data[metric_name][-1000:]
    
    def get_performance_stats(self, metric_name: str, window: int = 100) -> Dict[str, Any]:
        """
        Get statistics for a performance metric.
        
        Args:
            metric_name: Name of the metric
            window: Number of recent entries to consider
            
        Returns:
            stats: Performance statistics
        """
        if metric_name not in self.performance_data:
            return {'error': f"Metric '{metric_name}' not found"}
        
        data = self.performance_data[metric_name][-window:]
        if not data:
            return {'error': 'No data available'}
        
        values = [entry['value'] for entry in data]
        
        stats = {
            'metric': metric_name,
            'current': values[-1],
            'average': sum(values) / len(values),
            'min': min(values),
            'max': max(values),
            'trend': 'stable'  # Simplified trend calculation
        }
        
        # Calculate trend
        if len(values) >= 2:
            recent_avg = sum(values[-5:]) / min(5, len(values))
            overall_avg = sum(values) / len(values)
            if recent_avg > overall_avg * 1.1:
                stats['trend'] = 'improving'
            elif recent_avg < overall_avg * 0.9:
                stats['trend'] = 'declining'
        
        return stats
    
    def export_logs(self, filepath: str, include_structured: bool = True) -> bool:
        """
        Export logs to file.
        
        Args:
            filepath: Output file path
            include_structured: Whether to include structured logs
            
        Returns:
            success: Whether export was successful
        """
        try:
            export_data = {
                'exported_at': datetime.now().isoformat(),
                'system': self.name,
                'total_structured_logs': len(self.structured_logs),
                'performance_metrics': list(self.performance_data.keys())
            }
            
            if include_structured:
                export_data['structured_logs'] = self.structured_logs
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)
            
            print(f"📤 Logs exported to: {filepath}")
            return True
            
        except Exception as e:
            self.error(f"Log export failed: {e}")
            return False
    
    def get_log_summary(self) -> Dict[str, Any]:
        """Get summary of logging activity."""
        # Count logs by level
        level_counts = {}
        for log in self.structured_logs:
            level = log['level']
            level_counts[level] = level_counts.get(level, 0) + 1
        
        # Recent activity (last hour)
        hour_ago = datetime.now() - timedelta(hours=1)
        recent_logs = [log for log in self.structured_logs 
                      if datetime.fromisoformat(log['timestamp']) > hour_ago]
        
        return {
            'total_structured_logs': len(self.structured_logs),
            'level_distribution': level_counts,
            'recent_activity_1h': len(recent_logs),
            'performance_metrics_tracked': len(self.performance_data),
            'log_directory': str(self.log_dir)
        }
    
    def clear_logs(self, confirm: bool = False) -> bool:
        """
        Clear all logs (use with caution).
        
        Args:
            confirm: Safety confirmation
            
        Returns:
            success: Whether logs were cleared
        """
        if not confirm:
            self.warning("Clear logs requires confirm=True")
            return False
        
        with self.log_lock:
            self.structured_logs.clear()
            self.performance_data.clear()
        
        self.info("All logs cleared")
        return True

class PerformanceTracker:
    """
    Specialized performance tracking for SENE components.
    
    Tracks execution times, resource usage, and system performance
    for optimization and monitoring.
    """
    
    def __init__(self):
        self.execution_times = {}
        self.resource_usage = {}
        self.component_metrics = {}
        self.tracking_enabled = True
        
        print("⏱️  Performance Tracker initialized")
    
    def track_execution(self, component: str, operation: str):
        """
        Decorator to track execution time of functions.
        
        Args:
            component: Component name (e.g., 'evolution', 'training')
            operation: Operation name (e.g., 'add_layer', 'train_step')
        """
        def decorator(func):
            def wrapper(*args, **kwargs):
                if not self.tracking_enabled:
                    return func(*args, **kwargs)
                
                start_time = datetime.now()
                try:
                    result = func(*args, **kwargs)
                    execution_time = (datetime.now() - start_time).total_seconds()
                    
                    self.record_execution_time(component, operation, execution_time)
                    return result
                except Exception as e:
                    execution_time = (datetime.now() - start_time).total_seconds()
                    self.record_execution_time(component, operation, execution_time, success=False)
                    raise e
            
            return wrapper
        return decorator
    
    def record_execution_time(self, component: str, operation: str, 
                            time_seconds: float, success: bool = True):
        """
        Record execution time for an operation.
        
        Args:
            component: Component name
            operation: Operation name  
            time_seconds: Execution time in seconds
            success: Whether operation was successful
        """
        key = f"{component}.{operation}"
        
        if key not in self.execution_times:
            self.execution_times[key] = []
        
        self.execution_times[key].append({
            'timestamp': datetime.now().isoformat(),
            'time_seconds': time_seconds,
            'success': success
        })
        
        # Keep only recent records
        if len(self.execution_times[key]) > 1000:
            self.execution_times[key] = self.execution_times[key][-1000:]
    
    def record_resource_usage(self, component: str, resource_type: str, 
                            usage: float, unit: str = "MB"):
        """
        Record resource usage.
        
        Args:
            component: Component name
            resource_type: Type of resource ('memory', 'cpu', 'gpu')
            usage: Usage amount
            unit: Unit of measurement
        """
        key = f"{component}.{resource_type}"
        
        if key not in self.resource_usage:
            self.resource_usage[key] = []
        
        self.resource_usage[key].append({
            'timestamp': datetime.now().isoformat(),
            'usage': usage,
            'unit': unit
        })
    
    def get_performance_report(self) -> Dict[str, Any]:
        """Generate comprehensive performance report."""
        report = {
            'execution_times': {},
            'resource_usage': {},
            'recommendations': []
        }
        
        # Analyze execution times
        for key, times in self.execution_times.items():
            if times:
                recent_times = [t['time_seconds'] for t in times[-50:] if t['success']]
                if recent_times:
                    report['execution_times'][key] = {
                        'average': sum(recent_times) / len(recent_times),
                        'min': min(recent_times),
                        'max': max(recent_times),
                        'recent_count': len(recent_times)
                    }
        
        # Analyze resource usage
        for key, usage in self.resource_usage.items():
            if usage:
                recent_usage = [u['usage'] for u in usage[-50:]]
                report['resource_usage'][key] = {
                    'average': sum(recent_usage) / len(recent_usage),
                    'max': max(recent_usage),
                    'unit': usage[0]['unit']
                }
        
        # Generate recommendations
        report['recommendations'] = self._generate_recommendations()
        
        return report
    
    def _generate_recommendations(self) -> List[str]:
        """Generate performance optimization recommendations."""
        recommendations = []
        
        # Check for slow operations
        slow_threshold = 1.0  # seconds
        for key, stats in self.get_performance_report()['execution_times'].items():
            if stats['average'] > slow_threshold:
                recommendations.append(f"Optimize {key} (avg: {stats['average']:.2f}s)")
        
        # Check for high memory usage
        memory_threshold = 500  # MB
        for key, stats in self.get_performance_report()['resource_usage'].items():
            if 'memory' in key and stats['average'] > memory_threshold:
                recommendations.append(f"Reduce memory usage for {key} (avg: {stats['average']:.1f}MB)")
        
        return recommendations
    
    def enable_tracking(self):
        """Enable performance tracking."""
        self.tracking_enabled = True
        print("✅ Performance tracking enabled")
    
    def disable_tracking(self):
        """Disable performance tracking."""
        self.tracking_enabled = False
        print("❌ Performance tracking disabled")