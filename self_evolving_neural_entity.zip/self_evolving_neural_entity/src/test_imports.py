# src/test_imports.py
"""
Test script to verify all imports work correctly
"""

import sys
import os

# Add current directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

def test_imports():
    """Test all module imports."""
    modules_to_test = [
        ("core.enn", "ENNCore"),
        ("core.learning.ewc", "EWC"),
        ("evolution.engine", "EvolutionEngine"),
        ("interaction.voice_interface.speech_to_text", "VoiceInterface"),
        ("memory.conversation_memory", "ConversationMemory"),
        ("utils.config", "ConfigManager"),
    ]
    
    print("🧪 Testing SENE Imports...")
    print("=" * 50)
    
    all_passed = True
    
    for module_path, class_name in modules_to_test:
        try:
            module = __import__(module_path, fromlist=[class_name])
            cls = getattr(module, class_name)
            print(f"✅ {module_path}.{class_name}")
        except ImportError as e:
            print(f"❌ {module_path}.{class_name} - {e}")
            all_passed = False
        except AttributeError as e:
            print(f"❌ {module_path}.{class_name} - {e}")
            all_passed = False
    
    print("=" * 50)
    if all_passed:
        print("🎉 All imports successful!")
        return True
    else:
        print("❌ Some imports failed")
        return False

if __name__ == "__main__":
    success = test_imports()
    sys.exit(0 if success else 1)