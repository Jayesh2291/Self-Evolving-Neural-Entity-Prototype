# src/utils/safety_monitor.py
import torch
import numpy as np
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import psutil
import gc

class SafetyMonitor:
    """
    Comprehensive safety monitoring for the SENE system.
    
    Monitors system health, resource usage, and potential issues
    to ensure safe operation and prevent system failures.
    """
    
    def __init__(self, safety_thresholds: Dict[str, float] = None):
        self.safety_thresholds = safety_thresholds or self._default_thresholds()
        
        # Monitoring state
        self.health_metrics = {}
        self.alert_history = []
        self.intervention_history = []
        
        # System state tracking
        self.system_stability = 1.0  # 0.0 (unstable) to 1.0 (stable)
        self.performance_degradation = 0.0
        
        # Resource monitoring
        self.resource_history = []
        self.max_resource_history = 1000
        
        print("🛡️  Safety Monitor initialized")
    
    def _default_thresholds(self) -> Dict[str, float]:
        """Get default safety thresholds."""
        return {
            'memory_usage_mb': 2000,  # 2GB
            'cpu_percent': 80.0,      # 80%
            'gpu_memory_mb': 4000,    # 4GB
            'training_loss_spike': 10.0,
            'gradient_norm': 100.0,
            'parameter_growth_rate': 2.0,
            'system_stability': 0.3,
            'performance_degradation': 0.5
        }
    
    def check_system_health(self) -> Dict[str, Any]:
        """
        Perform comprehensive system health check.
        
        Returns:
            health_report: Dictionary containing health status and metrics
        """
        health_report = {
            'timestamp': datetime.now().isoformat(),
            'overall_health': 'healthy',
            'warnings': [],
            'critical_issues': [],
            'metrics': {},
            'recommendations': []
        }
        
        # Check resource usage
        self._check_resource_usage(health_report)
        
        # Check neural network health
        self._check_neural_network_health(health_report)
        
        # Check system stability
        self._check_system_stability(health_report)
        
        # Update overall health status
        if health_report['critical_issues']:
            health_report['overall_health'] = 'critical'
        elif health_report['warnings']:
            health_report['overall_health'] = 'warning'
        
        # Store health metrics
        self.health_metrics = health_report['metrics']
        
        return health_report
    
    def _check_resource_usage(self, health_report: Dict):
        """Check system resource usage."""
        try:
            # Memory usage
            memory = psutil.virtual_memory()
            memory_usage_mb = memory.used / 1024 / 1024
            
            health_report['metrics']['memory_usage_mb'] = memory_usage_mb
            health_report['metrics']['memory_percent'] = memory.percent
            
            if memory_usage_mb > self.safety_thresholds['memory_usage_mb']:
                health_report['critical_issues'].append(
                    f"High memory usage: {memory_usage_mb:.1f}MB"
                )
            elif memory.percent > 80:
                health_report['warnings'].append(
                    f"High memory percentage: {memory.percent:.1f}%"
                )
            
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=0.1)
            health_report['metrics']['cpu_percent'] = cpu_percent
            
            if cpu_percent > self.safety_thresholds['cpu_percent']:
                health_report['warnings'].append(
                    f"High CPU usage: {cpu_percent:.1f}%"
                )
            
            # GPU usage (if available)
            if torch.cuda.is_available():
                gpu_memory = torch.cuda.memory_allocated() / 1024 / 1024
                health_report['metrics']['gpu_memory_mb'] = gpu_memory
                
                if gpu_memory > self.safety_thresholds['gpu_memory_mb']:
                    health_report['warnings'].append(
                        f"High GPU memory usage: {gpu_memory:.1f}MB"
                    )
            
        except Exception as e:
            health_report['warnings'].append(f"Resource monitoring error: {e}")
    
    def _check_neural_network_health(self, health_report: Dict):
        """Check neural network health and stability."""
        # This would be called with actual neural network data
        # For now, we'll simulate some checks
        
        health_report['metrics']['neural_network_health'] = 0.9  # Simulated
        health_report['metrics']['gradient_stability'] = 0.85   # Simulated
        
        # Example checks that would be implemented with actual network data
        health_report['warnings'].append("Neural network health checks require network instance")
    
    def _check_system_stability(self, health_report: Dict):
        """Check overall system stability."""
        # Calculate stability based on recent alerts and performance
        recent_alerts = [
            alert for alert in self.alert_history
            if datetime.fromisoformat(alert['timestamp']) > datetime.now() - timedelta(hours=1)
        ]
        
        alert_count = len(recent_alerts)
        stability_score = max(0.0, 1.0 - (alert_count * 0.1))
        
        health_report['metrics']['system_stability'] = stability_score
        self.system_stability = stability_score
        
        if stability_score < self.safety_thresholds['system_stability']:
            health_report['critical_issues'].append(
                f"Low system stability: {stability_score:.2f}"
            )
    
    def monitor_training(self, model, loss: float, gradients: Dict = None) -> Dict[str, Any]:
        """
        Monitor training process for safety issues.
        
        Args:
            model: Neural network model
            loss: Current training loss
            gradients: Gradient information
            
        Returns:
            training_report: Training safety report
        """
        training_report = {
            'timestamp': datetime.now().isoformat(),
            'safe_to_continue': True,
            'issues': [],
            'metrics': {}
        }
        
        # Check for loss spikes
        if self._detect_loss_spike(loss):
            training_report['issues'].append("Training loss spike detected")
            training_report['safe_to_continue'] = False
        
        # Check gradient health
        if gradients:
            grad_norm = self._calculate_gradient_norm(gradients)
            training_report['metrics']['gradient_norm'] = grad_norm
            
            if grad_norm > self.safety_thresholds['gradient_norm']:
                training_report['issues'].append(f"High gradient norm: {grad_norm:.2f}")
        
        # Check model parameters
        param_health = self._check_parameter_health(model)
        training_report['metrics'].update(param_health)
        
        if param_health.get('has_nan_params', False):
            training_report['issues'].append("Model parameters contain NaN values")
            training_report['safe_to_continue'] = False
        
        # Record monitoring data
        self._record_training_metrics(training_report)
        
        return training_report
    
    def _detect_loss_spike(self, current_loss: float) -> bool:
        """Detect abnormal loss spikes."""
        # This would compare with recent loss history
        # For now, use a simple threshold
        return current_loss > self.safety_thresholds['training_loss_spike']
    
    def _calculate_gradient_norm(self, gradients: Dict) -> float:
        """Calculate total gradient norm."""
        total_norm = 0.0
        for param_name, gradient in gradients.items():
            if gradient is not None:
                total_norm += gradient.norm().item() ** 2
        return total_norm ** 0.5
    
    def _check_parameter_health(self, model) -> Dict[str, Any]:
        """Check health of model parameters."""
        has_nan = False
        has_inf = False
        total_params = 0
        
        for name, param in model.named_parameters():
            total_params += param.numel()
            if torch.isnan(param).any():
                has_nan = True
            if torch.isinf(param).any():
                has_inf = True
        
        return {
            'has_nan_params': has_nan,
            'has_inf_params': has_inf,
            'total_parameters': total_params
        }
    
    def _record_training_metrics(self, training_report: Dict):
        """Record training metrics for historical analysis."""
        self.resource_history.append({
            'timestamp': training_report['timestamp'],
            'metrics': training_report['metrics'],
            'issues': training_report['issues']
        })
        
        # Keep history manageable
        if len(self.resource_history) > self.max_resource_history:
            self.resource_history = self.resource_history[-self.max_resource_history:]
    
    def should_intervene(self, context: Dict[str, Any]) -> bool:
        """
        Determine if safety intervention is needed.
        
        Args:
            context: Current system context
            
        Returns:
            intervene: Whether to trigger safety intervention
        """
        # Check multiple safety conditions
        conditions = [
            self.system_stability < self.safety_thresholds['system_stability'],
            self.performance_degradation > self.safety_thresholds['performance_degradation'],
            # Add more conditions as needed
        ]
        
        return any(conditions)
    
    def trigger_safety_intervention(self, intervention_type: str, reason: str) -> Dict[str, Any]:
        """
        Trigger a safety intervention.
        
        Args:
            intervention_type: Type of intervention
            reason: Reason for intervention
            
        Returns:
            intervention_report: Intervention details
        """
        intervention = {
            'timestamp': datetime.now().isoformat(),
            'type': intervention_type,
            'reason': reason,
            'actions_taken': [],
            'success': True
        }
        
        # Execute intervention based on type
        if intervention_type == 'pause_training':
            intervention['actions_taken'].append('Paused training process')
            # Actual implementation would pause training
        
        elif intervention_type == 'rollback_model':
            intervention['actions_taken'].append('Rolled back to previous model checkpoint')
            # Actual implementation would restore checkpoint
        
        elif intervention_type == 'reduce_complexity':
            intervention['actions_taken'].append('Reduced model complexity')
            # Actual implementation would simplify model
        
        elif intervention_type == 'emergency_stop':
            intervention['actions_taken'].append('Emergency stop triggered')
            intervention['actions_taken'].append('All processes halted')
            # Actual implementation would stop everything
        
        # Record intervention
        self.intervention_history.append(intervention)
        
        # Send alert
        self.raise_alert(f"Safety intervention: {intervention_type}", 'CRITICAL')
        
        return intervention
    
    def raise_alert(self, message: str, level: str = 'WARNING'):
        """
        Raise a safety alert.
        
        Args:
            message: Alert message
            level: Alert level (INFO, WARNING, CRITICAL)
        """
        alert = {
            'timestamp': datetime.now().isoformat(),
            'level': level,
            'message': message,
            'system_stability': self.system_stability
        }
        
        self.alert_history.append(alert)
        print(f"🚨 Safety Alert [{level}]: {message}")
    
    def get_safety_report(self) -> Dict[str, Any]:
        """Generate comprehensive safety report."""
        recent_alerts = [
            alert for alert in self.alert_history
            if datetime.fromisoformat(alert['timestamp']) > datetime.now() - timedelta(hours=24)
        ]
        
        recent_interventions = [
            interv for interv in self.intervention_history
            if datetime.fromisoformat(interv['timestamp']) > datetime.now() - timedelta(hours=24)
        ]
        
        return {
            'system_stability': self.system_stability,
            'performance_degradation': self.performance_degradation,
            'recent_alerts_24h': len(recent_alerts),
            'recent_interventions_24h': len(recent_interventions),
            'critical_alerts': [a for a in recent_alerts if a['level'] == 'CRITICAL'],
            'health_metrics': self.health_metrics,
            'safety_thresholds': self.safety_thresholds
        }
    
    def update_thresholds(self, new_thresholds: Dict[str, float]):
        """
        Update safety thresholds.
        
        Args:
            new_thresholds: New threshold values
        """
        self.safety_thresholds.update(new_thresholds)
        print("⚙️  Safety thresholds updated")
    
    def force_garbage_collection(self):
        """Force garbage collection to free memory."""
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        print("🧹 Forced garbage collection")