# src/core/enn.py
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import random
import numpy as np
import copy

class ENNCore(nn.Module):
    """
    Self-Evolving Neural Entity Core - The main neural network that can evolve its architecture.
    
    Features:
    - Dynamic architecture modification
    - Continuous learning with experience replay
    - Elastic Weight Consolidation for preventing catastrophic forgetting
    - Online learning capabilities
    """
    
    def __init__(self, input_dim, hidden_dims=None, output_dim=2, learning_rate=1e-3):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        
        # Neural Architecture - dynamically modifiable
        self.blocks = nn.ModuleList()
        dims = [input_dim] + (hidden_dims or [64, 64])
        
        # Build initial neural architecture
        for i in range(len(dims) - 1):
            self.blocks.append(self._create_block(dims[i], dims[i+1]))
        
        self.output_layer = nn.Linear(dims[-1], output_dim)
        
        # Optimization
        self.optimizer = optim.Adam(self.parameters(), lr=learning_rate)
        self.criterion = nn.MSELoss()
        
        # Continuous Learning Components
        self.replay_buffer = deque(maxlen=10000)
        self.learning_rate = learning_rate
        
        # Architecture evolution tracking
        self.architecture_history = []
        self.architecture_history.append({
            'type': 'initial',
            'architecture': self.get_architecture(),
            'timestamp': 'initial'
        })
        
        print(f"🧠 ENN Core Initialized")
        print(f"📐 Architecture: {self.get_architecture()}")
        print(f"🎯 Input: {input_dim}, Output: {output_dim}")
        print(f"📈 Learning Rate: {learning_rate}")

    def _create_block(self, in_dim, out_dim):
        """Create a neural network block with linear layer and activation"""
        return nn.Sequential(
            nn.Linear(in_dim, out_dim),
            nn.ReLU(),
            nn.Dropout(0.1)
        )

    def forward(self, x):
        """Forward pass through the neural network"""
        if not isinstance(x, torch.Tensor):
            x = torch.FloatTensor(x)
        
        # Propagate through all neural blocks
        for block in self.blocks:
            x = block(x)
        
        return self.output_layer(x)

    def rebuild_output_layer(self):
        """Ensure output layer input matches current last hidden block size."""
        if len(self.blocks) == 0:
            in_dim = self.input_dim
        else:
            last = self.blocks[-1]
            if hasattr(last, 'out_features'):
                in_dim = last.out_features
            elif isinstance(last, nn.Sequential) and len(last) > 0 and hasattr(last[0], 'out_features'):
                in_dim = last[0].out_features
            else:
                # Fallback to keep existing size
                in_dim = getattr(self.output_layer, 'in_features', self.input_dim)
        self.output_layer = nn.Linear(in_dim, self.output_dim)
        # Optimizer must be rebuilt to include new parameters
        self.optimizer = optim.Adam(self.parameters(), lr=self.learning_rate)

    def add_block(self, out_dim, position=None):
        """
        Add a new neural block to the network.
        
        Args:
            out_dim: Output dimension of the new block
            position: Position to insert the block (None for end)
            
        Returns:
            success: Whether the operation was successful
        """
        if position is None:
            position = len(self.blocks)
        
        # Calculate input dimension for the new block
        if position == 0:
            in_dim = self.input_dim
        else:
            prev_block = self.blocks[position-1]
            if hasattr(prev_block, 'out_features'):
                in_dim = prev_block.out_features
            elif isinstance(prev_block, nn.Sequential) and len(prev_block) > 0:
                in_dim = prev_block[0].out_features
            else:
                # Fallback to output layer's input size
                in_dim = self.output_layer.in_features
        
        # Create and insert new block
        new_block = self._create_block(in_dim, out_dim)
        self.blocks.insert(position, new_block)
        
        # Rebuild output layer to match new last hidden size
        self.rebuild_output_layer()
        
        # Record architecture change
        self.architecture_history.append({
            'type': 'add_block',
            'position': position,
            'size': out_dim,
            'architecture': self.get_architecture(),
            'timestamp': 'now'  # Would use actual timestamp in production
        })
        
        print(f"🧠➕ Added block at position {position} with {out_dim} neurons")
        print(f"📐 New architecture: {self.get_architecture()}")
        return True

    def remove_block(self, position):
        """
        Remove a neural block from the network.
        
        Args:
            position: Position of the block to remove
            
        Returns:
            success: Whether the operation was successful
        """
        if len(self.blocks) <= 1:
            print("❌ Cannot remove the only hidden block")
            return False
            
        if position < 0 or position >= len(self.blocks):
            print(f"❌ Invalid block position: {position}")
            return False
        
        # Remove the block
        removed_block = self.blocks.pop(position)
        
        # Rebuild output layer to match new last hidden size
        self.rebuild_output_layer()
        
        # Record architecture change
        self.architecture_history.append({
            'type': 'remove_block',
            'position': position,
            'architecture': self.get_architecture(),
            'timestamp': 'now'
        })
        
        print(f"🧠➖ Removed block at position {position}")
        print(f"📐 New architecture: {self.get_architecture()}")
        return True

    def get_architecture(self):
        """Get the current neural architecture as a list of layer sizes"""
        arch = [self.input_dim]
        for block in self.blocks:
            if hasattr(block, 'out_features'):
                arch.append(block.out_features)
            elif isinstance(block, nn.Sequential) and len(block) > 0 and hasattr(block[0], 'out_features'):
                arch.append(block[0].out_features)
            else:
                # Unknown block type; fall back to previous size
                arch.append(arch[-1])
        arch.append(self.output_dim)
        return arch

    def get_parameter_count(self):
        """Get total number of trainable parameters"""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def store_experience(self, state, action, reward, next_state, done, info=None):
        """
        Store an experience in the replay buffer for later learning.
        
        Args:
            state: Current state
            action: Action taken
            reward: Reward received
            next_state: Next state
            done: Whether the episode ended
            info: Additional information (optional)
        """
        experience = {
            'state': state,
            'action': action,
            'reward': reward,
            'next_state': next_state,
            'done': done,
            'info': info or {}
        }
        self.replay_buffer.append(experience)

    def update(self, batch_size=32, ewc_object=None):
        """
        Perform a learning update from experiences in the replay buffer.
        
        Args:
            batch_size: Number of experiences to sample
            ewc_object: EWC object for regularization (optional)
            
        Returns:
            loss: Computed loss value
        """
        if len(self.replay_buffer) < batch_size:
            return 0.0
            
        # Sample batch from replay buffer
        batch = random.sample(self.replay_buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*[
            (exp['state'], exp['action'], exp['reward'], exp['next_state'], exp['done'])
            for exp in batch
        ])
        
        # Convert to tensors
        states = torch.FloatTensor(np.array(states))
        actions = torch.LongTensor(actions)
        rewards = torch.FloatTensor(rewards)
        next_states = torch.FloatTensor(np.array(next_states))
        dones = torch.BoolTensor(dones)
        
        # Compute current Q values
        self.optimizer.zero_grad()
        current_q = self(states).gather(1, actions.unsqueeze(1))
        
        # Compute next Q values
        with torch.no_grad():
            next_q = self(next_states).max(1)[0]
            target_q = rewards + (0.99 * next_q * ~dones)
        
        # Compute loss
        loss = self.criterion(current_q.squeeze(), target_q)
        
        # Add EWC regularization if provided
        if ewc_object is not None:
            ewc_penalty = ewc_object.compute_penalty()
            loss += ewc_penalty
        
        # Backward pass and optimization
        loss.backward()
        
        # Gradient clipping for stability
        torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)
        
        self.optimizer.step()
        
        return loss.item()

    def predict(self, state):
        """
        Make a prediction given a state.
        
        Args:
            state: Input state
            
        Returns:
            action: Predicted action
            confidence: Confidence score
        """
        with torch.no_grad():
            q_values = self(state)
            action = torch.argmax(q_values).item()
            confidence = torch.softmax(q_values, dim=-1).max().item()
            
        return action, confidence

    def get_architecture_history(self):
        """Get the history of architecture changes"""
        return self.architecture_history

    def get_network_info(self):
        """Get comprehensive information about the network"""
        arch = self.get_architecture()
        param_count = self.get_parameter_count()
        
        return {
            'architecture': arch,
            'total_layers': len(arch) - 1,  # Exclude input
            'hidden_layers': len(self.blocks),
            'total_parameters': param_count,
            'parameter_count_millions': param_count / 1e6,
            'learning_rate': self.learning_rate,
            'replay_buffer_size': len(self.replay_buffer),
            'evolution_steps': len(self.architecture_history) - 1  # Exclude initial
        }

    def save_checkpoint(self, filepath):
        """Save model checkpoint"""
        checkpoint = {
            'model_state_dict': self.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'architecture': self.get_architecture(),
            'architecture_history': self.architecture_history,
            'learning_rate': self.learning_rate
        }
        torch.save(checkpoint, filepath)
        print(f"💾 Checkpoint saved: {filepath}")

    def load_checkpoint(self, filepath):
        """Load model checkpoint"""
        checkpoint = torch.load(filepath)
        self.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.architecture_history = checkpoint.get('architecture_history', [])
        self.learning_rate = checkpoint.get('learning_rate', self.learning_rate)
        print(f"📂 Checkpoint loaded: {filepath}")
        print(f"📐 Architecture: {self.get_architecture()}")

# Convenience function to create ENN instances
def create_enn(input_dim, hidden_dims=None, output_dim=2, learning_rate=1e-3):
    """
    Factory function to create ENNCore instances.
    
    Args:
        input_dim: Input dimension
        hidden_dims: List of hidden layer dimensions
        output_dim: Output dimension
        learning_rate: Learning rate for optimizer
        
    Returns:
        enn_instance: Initialized ENNCore instance
    """
    return ENNCore(input_dim, hidden_dims, output_dim, learning_rate)