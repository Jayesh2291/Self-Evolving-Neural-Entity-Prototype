# src/interaction/voice_interface/wake_word.py
import pyaudio
import numpy as np
import threading
import time
from typing import Optional, Callable, List
from datetime import datetime

class WakeWordDetector:
    """
    Advanced wake word detection using audio processing.
    
    Provides customizable wake word detection with
    configurable sensitivity and multiple detection methods.
    """
    
    def __init__(self, wake_word: str = "sene", sensitivity: float = 0.7):
        self.wake_word = wake_word.lower()
        self.sensitivity = max(0.1, min(1.0, sensitivity))  # Clamp to 0.1-1.0
        
        # Audio processing
        self.audio = pyaudio.PyAudio()
        self.stream = None
        self.is_listening = False
        self.detection_thread = None
        
        # Detection parameters
        self.chunk_size = 1024
        self.format = pyaudio.paInt16
        self.channels = 1
        self.rate = 16000
        self.silence_threshold = 500
        self.voice_threshold = 1000
        
        # Detection history
        self.detection_history = []
        self.max_history = 100
        
        # Pattern matching (simplified - in practice would use ML model)
        self.wake_patterns = self._generate_wake_patterns()
        
        # Callbacks
        self.on_wake_detected = None
        self.on_audio_activity = None
        self.on_error = None
        
        print(f"🔔 Wake Word Detector initialized (Word: '{self.wake_word}')")
    
    def _generate_wake_patterns(self) -> List[str]:
        """Generate phonetic patterns for wake word detection."""
        # Simplified phonetic patterns - in practice would use proper phonetic mapping
        patterns = []
        word = self.wake_word
        
        # Add the word itself
        patterns.append(word)
        
        # Add common mispronunciations
        if word == "sene":
            patterns.extend(["seen", "senny", "sennay", "senee"])
        elif word == "computer":
            patterns.extend(["compute", "compuder", "compooter"])
        # Add more wake word variations as needed
        
        return patterns
    
    def start_listening(self):
        """Start continuous wake word detection."""
        if self.is_listening:
            print("🔴 Already listening for wake word")
            return
        
        try:
            # Open audio stream
            self.stream = self.audio.open(
                format=self.format,
                channels=self.channels,
                rate=self.rate,
                input=True,
                frames_per_buffer=self.chunk_size,
                stream_callback=self._audio_callback
            )
            
            self.is_listening = True
            
            # Start detection thread
            self.detection_thread = threading.Thread(
                target=self._detection_worker,
                daemon=True,
                name="WakeWordDetector"
            )
            self.detection_thread.start()
            
            print("🔴 Wake word detection ACTIVATED")
            print(f"   Listening for: {', '.join(self.wake_patterns)}")
            
        except Exception as e:
            print(f"❌ Failed to start wake word detection: {e}")
            if self.on_error:
                self.on_error(f"Wake word detection start failed: {e}")
    
    def stop_listening(self):
        """Stop wake word detection."""
        self.is_listening = False
        
        if self.stream:
            self.stream.stop_stream()
            self.stream.close()
        
        if self.detection_thread:
            self.detection_thread.join(timeout=2.0)
        
        print("🔴 Wake word detection stopped")
    
    def _audio_callback(self, in_data, frame_count, time_info, status):
        """Audio callback for real-time processing."""
        if status:
            print(f"Audio stream status: {status}")
        
        # Convert audio data to numpy array for processing
        audio_data = np.frombuffer(in_data, dtype=np.int16)
        
        # Simple audio activity detection
        audio_level = np.abs(audio_data).mean()
        
        if audio_level > self.voice_threshold:
            # Significant audio activity detected
            if self.on_audio_activity:
                self.on_audio_activity(audio_level)
            
            # Check for wake word pattern (simplified)
            if self._detect_wake_word_pattern(audio_data, audio_level):
                self._handle_wake_word_detection()
        
        return (in_data, pyaudio.paContinue)
    
    def _detect_wake_word_pattern(self, audio_data: np.ndarray, audio_level: float) -> bool:
        """
        Detect wake word patterns in audio data.
        
        Note: This is a simplified implementation.
        In practice, you would use a proper ML model like:
        - Snowboy
        - Porcupine  
        - Custom trained model
        
        Args:
            audio_data: Audio data as numpy array
            audio_level: Current audio level
            
        Returns:
            detected: Whether wake word was detected
        """
        # Simplified detection logic
        # In reality, this would involve proper audio feature extraction
        # and machine learning classification
        
        # Basic voice activity detection
        if audio_level < self.voice_threshold:
            return False
        
        # Simulate pattern matching with random chance based on sensitivity
        # This is where you would integrate a proper wake word detection model
        detection_chance = self.sensitivity * 0.3  # Scale sensitivity
        
        # For demo purposes, use random detection with sensitivity weighting
        import random
        if random.random() < detection_chance:
            return True
        
        return False
    
    def _detection_worker(self):
        """Background worker for advanced wake word detection."""
        print("🎧 Wake word detection worker started...")
        
        while self.is_listening:
            try:
                # This is where you would implement more sophisticated
                # wake word detection algorithms
                
                # For now, just sleep and maintain the thread
                time.sleep(0.1)
                
            except Exception as e:
                print(f"❌ Wake word detection error: {e}")
                if self.on_error:
                    self.on_error(f"Detection error: {e}")
                time.sleep(1)
    
    def _handle_wake_word_detection(self):
        """Handle successful wake word detection."""
        detection_time = datetime.now()
        
        # Record detection
        detection_record = {
            'timestamp': detection_time.isoformat(),
            'wake_word': self.wake_word,
            'confidence': self.sensitivity,
            'method': 'audio_processing'
        }
        
        self.detection_history.append(detection_record)
        
        # Keep history within limits
        if len(self.detection_history) > self.max_history:
            self.detection_history = self.detection_history[-self.max_history:]
        
        print(f"🔔 Wake word '{self.wake_word}' detected!")
        
        # Trigger callback
        if self.on_wake_detected:
            self.on_wake_detected(detection_record)
    
    def set_sensitivity(self, sensitivity: float):
        """Set detection sensitivity (0.1 to 1.0)."""
        self.sensitivity = max(0.1, min(1.0, sensitivity))
        print(f"🎛️ Wake word sensitivity set to: {self.sensitivity}")
    
    def set_wake_word(self, new_wake_word: str):
        """Change the wake word."""
        old_wake_word = self.wake_word
        self.wake_word = new_wake_word.lower()
        self.wake_patterns = self._generate_wake_patterns()
        
        print(f"🔔 Wake word changed: '{old_wake_word}' -> '{self.wake_word}'")
        print(f"   New patterns: {', '.join(self.wake_patterns)}")
    
    def add_custom_pattern(self, pattern: str):
        """Add a custom wake word pattern."""
        if pattern not in self.wake_patterns:
            self.wake_patterns.append(pattern)
            print(f"✅ Added custom wake pattern: '{pattern}'")
    
    def get_detection_stats(self) -> dict:
        """Get wake word detection statistics."""
        recent_detections = [
            det for det in self.detection_history
            if datetime.fromisoformat(det['timestamp']) > datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        ]
        
        return {
            'is_listening': self.is_listening,
            'wake_word': self.wake_word,
            'sensitivity': self.sensitivity,
            'total_detections': len(self.detection_history),
            'detections_today': len(recent_detections),
            'last_detection': self.detection_history[-1]['timestamp'] if self.detection_history else None,
            'available_patterns': len(self.wake_patterns),
            'audio_threshold': self.voice_threshold
        }
    
    def reset_detection_history(self):
        """Reset detection history."""
        self.detection_history = []
        print("🔄 Wake word detection history reset")
    
    def calibrate_threshold(self, duration: int = 5):
        """
        Calibrate audio thresholds based on ambient noise.
        
        Args:
            duration: Calibration duration in seconds
        """
        print("🔊 Calibrating audio thresholds...")
        print("   Please remain silent during calibration")
        
        try:
            # Collect ambient noise samples
            samples = []
            start_time = time.time()
            
            temp_stream = self.audio.open(
                format=self.format,
                channels=self.channels,
                rate=self.rate,
                input=True,
                frames_per_buffer=self.chunk_size
            )
            
            while time.time() - start_time < duration:
                data = temp_stream.read(self.chunk_size)
                audio_data = np.frombuffer(data, dtype=np.int16)
                samples.append(np.abs(audio_data).mean())
            
            temp_stream.stop_stream()
            temp_stream.close()
            
            # Calculate thresholds based on ambient noise
            ambient_level = np.mean(samples)
            self.silence_threshold = ambient_level * 2
            self.voice_threshold = ambient_level * 4
            
            print(f"✅ Calibration complete")
            print(f"   Silence threshold: {self.silence_threshold:.1f}")
            print(f"   Voice threshold: {self.voice_threshold:.1f}")
            
        except Exception as e:
            print(f"❌ Calibration failed: {e}")
    
    # Callback setters
    def set_wake_detected_callback(self, callback: Callable):
        """Set callback for wake word detection."""
        self.on_wake_detected = callback
    
    def set_audio_activity_callback(self, callback: Callable):
        """Set callback for audio activity."""
        self.on_audio_activity = callback
    
    def set_error_callback(self, callback: Callable):
        """Set callback for error handling."""
        self.on_error = callback
    
    def __del__(self):
        """Clean up audio resources."""
        self.stop_listening()
        if self.audio:
            self.audio.terminate()