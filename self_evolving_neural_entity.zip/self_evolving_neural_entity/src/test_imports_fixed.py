# src/test_imports_fixed.py
"""
Fixed test script for SENE imports
"""

import sys
import os

# Add current directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

def test_basic_imports():
    """Test basic module imports without complex dependencies."""
    print("🧪 Testing Basic SENE Imports...")
    print("=" * 50)
    
    tests = [
        # Core components
        ("core.enn", "ENNCore"),
        ("core.learning.ewc", "EWC"),
        ("evolution.engine", "EvolutionEngine"),
        
        # Memory components
        ("memory.conversation_memory", "ConversationMemory"),
        ("memory.decision_log", "DecisionLogger"),
        
        # Environment components
        ("environments.cartpole", "CartPoleEnvironment"),
        
        # Decision engine components
        ("decision_engine.collaborative_decider", "CollaborativeDecider"),
        ("decision_engine.suggestion_engine", "SuggestionEngine"),
        
        # Utility components
        ("utils.config", "ConfigManager"),
        ("utils.logging", "SeneLogger"),
        ("utils.safety_monitor", "SafetyMonitor"),
    ]
    
    all_passed = True
    
    for module_path, class_name in tests:
        try:
            # Import the module
            module = __import__(module_path, fromlist=[class_name])
            # Get the class
            cls = getattr(module, class_name)
            print(f"✅ {module_path}.{class_name}")
            
            # Try to create an instance for simple classes
            if class_name in ['ConfigManager', 'SeneLogger', 'ConversationMemory']:
                try:
                    instance = cls()
                    print(f"   ↳ Instance created successfully")
                except:
                    print(f"   ↳ Class imported (instance creation skipped)")
                    
        except ImportError as e:
            print(f"❌ {module_path}.{class_name} - ImportError: {e}")
            all_passed = False
        except AttributeError as e:
            print(f"❌ {module_path}.{class_name} - AttributeError: {e}")
            all_passed = False
        except Exception as e:
            print(f"⚠️  {module_path}.{class_name} - Other error: {e}")
            # Don't fail the test for non-critical errors
    
    print("=" * 50)
    
    # Test interaction components separately (they have more dependencies)
    print("\n🔍 Testing Interaction Components...")
    interaction_tests = [
        ("interaction.command_parser.intent_recognition", "IntentRecognizer"),
        ("interaction.command_parser.action_mapping", "ActionMapper"),
    ]
    
    interaction_passed = True
    for module_path, class_name in interaction_tests:
        try:
            module = __import__(module_path, fromlist=[class_name])
            cls = getattr(module, class_name)
            print(f"✅ {module_path}.{class_name}")
        except Exception as e:
            print(f"❌ {module_path}.{class_name} - {e}")
            interaction_passed = False
    
    # Test voice interface with special handling
    print("\n🎤 Testing Voice Interface...")
    try:
        from interaction.voice_interface.speech_to_text import VoiceInterface
        print("✅ interaction.voice_interface.speech_to_text.VoiceInterface")
        # Don't create instance as it requires microphone
    except Exception as e:
        print(f"⚠️  VoiceInterface - {e}")
        print("   (This is normal if microphone is not available)")
    
    print("=" * 50)
    
    if all_passed:
        print("🎉 Core imports successful!")
        print("💡 Voice interface may have warnings (normal without microphone)")
        return True
    else:
        print("❌ Some core imports failed")
        return False

if __name__ == "__main__":
    success = test_basic_imports()
    if success:
        print("\n🚀 Now testing the main system...")
        try:
            from main import demo_sene_system
            print("✅ Main system import successful!")
            print("\n" + "="*50)
            print("Ready to run: python ../run_sene.py")
        except Exception as e:
            print(f"❌ Main system import failed: {e}")
    sys.exit(0 if success else 1)