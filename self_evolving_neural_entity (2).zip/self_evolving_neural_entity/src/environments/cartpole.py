# src/environments/cartpole.py
import gym
import numpy as np
from typing import Any, Tuple, Dict
from .base_env import BaseEnvironment

class CartPoleEnvironment(BaseEnvironment):
    """
    CartPole environment wrapper for SENE system.
    
    A classic reinforcement learning environment where the goal is to
    balance a pole on a moving cart by applying forces to the cart.
    """
    
    def __init__(self, render_mode: str = None):
        super().__init__("CartPole-v1")
        
        # Initialize Gym environment
        self.env = gym.make('CartPole-v1', render_mode=render_mode)
        self.current_state = None
        self.current_score = 0
        self.max_steps_per_episode = 500
        
        print("🎯 CartPole Environment initialized")
        print(f"   Observation space: {self.env.observation_space.shape}")
        print(f"   Action space: {self.env.action_space.n} actions")
    
    def reset(self) -> np.ndarray:
        """Reset the CartPole environment."""
        result = self.env.reset()
        
        # Handle different Gym versions
        if isinstance(result, tuple):
            self.current_state = result[0]  # Newer Gym versions return (state, info)
        else:
            self.current_state = result     # Older Gym versions return state only
            
        self.current_score = 0
        self.episode_count += 1
        
        return self.current_state
    
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, Dict]:
        """
        Take a step in the CartPole environment.
        
        Args:
            action: 0 (push left) or 1 (push right)
            
        Returns:
            state: New state [cart_position, cart_velocity, pole_angle, pole_velocity]
            reward: Always 1.0 for each step survived
            done: Whether episode ended
            info: Additional information
        """
        result = self.env.step(action)
        
        # Handle different Gym versions
        if len(result) == 4:
            next_state, reward, done, info = result
            truncated = False
        else:
            next_state, reward, done, truncated, info = result
            done = done or truncated
        
        self.current_state = next_state
        self.current_score += reward
        self.total_steps += 1
        
        # Additional termination condition
        if self.current_score >= self.max_steps_per_episode:
            done = True
        
        return next_state, reward, done, info
    
    def get_action_space(self) -> gym.spaces.Discrete:
        """Get the action space."""
        return self.env.action_space
    
    def get_observation_space(self) -> gym.spaces.Box:
        """Get the observation space."""
        return self.env.observation_space
    
    def render(self) -> None:
        """Render the CartPole environment."""
        self.env.render()
        self.is_rendering = True
    
    def close(self) -> None:
        """Close the environment."""
        self.env.close()
        super().close()
    
    def get_state_description(self) -> Dict:
        """Get human-readable description of current state."""
        if self.current_state is None:
            return {"status": "Not initialized"}
        
        state = self.current_state
        return {
            'cart_position': f"{state[0]:.3f}",
            'cart_velocity': f"{state[1]:.3f}", 
            'pole_angle': f"{state[2]:.3f}",
            'pole_velocity': f"{state[3]:.3f}",
            'current_score': int(self.current_score),
            'episode': self.episode_count
        }
    
    def get_performance_metrics(self) -> Dict:
        """Get performance metrics for the current episode."""
        return {
            'current_score': self.current_score,
            'episode_number': self.episode_count,
            'total_steps': self.total_steps,
            'average_score': self.current_score / max(1, self.total_steps),
            'max_possible_score': self.max_steps_per_episode
        }
    
    def is_solved(self, score: float, threshold: float = 195.0) -> bool:
        """
        Check if the environment is considered solved.
        
        Args:
            score: Current episode score
            threshold: Score threshold for solving (default 195 for CartPole)
            
        Returns:
            solved: Whether environment is solved
        """
        return score >= threshold

# Factory function for easy environment creation
def create_cartpole_environment(render_mode: str = None) -> CartPoleEnvironment:
    """
    Create a CartPole environment instance.
    
    Args:
        render_mode: Rendering mode ('human', 'rgb_array', None)
        
    Returns:
        environment: CartPole environment instance
    """
    return CartPoleEnvironment(render_mode)