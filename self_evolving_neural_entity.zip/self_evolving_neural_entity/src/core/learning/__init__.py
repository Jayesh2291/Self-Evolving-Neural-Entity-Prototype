# src/core/learning/__init__.py
"""
Learning algorithms and continuous learning mechanisms for the Self-Evolving Neural Entity.

This module contains implementations of various learning techniques that enable
the neural network to learn continuously without catastrophic forgetting.
"""

from .ewc import EWC
from .online_learner import OnlineLearner
from .replay_buffer import ReplayBuffer

__all__ = [
    'EWC',
    'OnlineLearner', 
    'ReplayBuffer'
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Continuous learning algorithms for neural networks'

print("🧠 SENE Learning module loaded - EWC, Online Learning, and Replay Buffer available")