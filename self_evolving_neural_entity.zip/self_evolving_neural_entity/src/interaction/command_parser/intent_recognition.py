# src/interaction/command_parser/intent_recognition.py
import re
from typing import Dict, List, Tuple, Any
from datetime import datetime

class IntentRecognizer:
    """
    Recognizes user intent from natural language commands.
    
    This class processes voice or text commands and identifies
    what action the user wants the system to perform.
    """
    
    def __init__(self):
        # Comprehensive command patterns
        self.command_patterns = {
            # Architecture Evolution Commands
            'evolution_add_layer': [
                r'add.*layer', r'new layer', r'make.*bigger', r'increase.*size',
                r'grow.*network', r'expand.*network', r'add.*neuron', r'more.*capacity'
            ],
            'evolution_remove_layer': [
                r'remove.*layer', r'delete.*layer', r'make.*smaller', r'reduce.*size',
                r'simplify.*network', r'remove.*neuron', r'less.*complex'
            ],
            'evolution_change_architecture': [
                r'change.*architecture', r'modify.*structure', r'redesign.*network',
                r'restructure', r'reconfigure'
            ],
            
            # Training Commands
            'start_training': [
                r'start.*train', r'begin.*train', r'learn.*now', r'train.*network',
                r'start.*learning', r'begin.*learning', r'run.*training'
            ],
            'stop_training': [
                r'stop.*train', r'end.*train', r'pause.*train', r'halt.*train',
                r'stop.*learning', r'pause.*learning'
            ],
            'reset_training': [
                r'reset.*train', r'restart.*train', r'clear.*train', r'start over'
            ],
            
            # Evolution Commands
            'trigger_evolution': [
                r'evolve', r'improve.*network', r'optimize', r'enhance',
                r'make.*better', r'upgrade', r'auto.*evolve', r'self.*improve'
            ],
            'auto_evolve': [
                r'auto.*evolve', r'automatic.*evolution', r'continuous.*improve',
                r'self.*evolve', r'auto.*mode'
            ],
            
            # Information Commands
            'get_network_info': [
                r'show.*architecture', r'what.*network', r'current.*structure',
                r'network.*info', r'layer.*info', r'how.*built', r'display.*layout'
            ],
            'get_status': [
                r'status', r'how.*you', r'what.*doing', r'current.*state',
                r'system.*status', r'check.*status', r'report'
            ],
            'get_performance': [
                r'performance', r'how.*well', r'current.*score', r'training.*progress',
                r'results', r'metrics', r'statistics'
            ],
            
            # Research Commands
            'research': [
                r'research', r'search', r'look up', r'find.*about', r'learn about',
                r'get.*info', r'search.*web', r'internet.*search'
            ],
            
            # Application Commands
            'create_application': [
                r'create.*app', r'make.*application', r'build.*app', r'new.*project',
                r'stock.*predict', r'game.*ai', r'start.*project'
            ],
            'run_application': [
                r'run.*app', r'start.*app', r'execute.*app', r'launch.*app'
            ],
            
            # Safety Commands
            'emergency_stop': [
                r'stop', r'pause', r'halt', r'emergency', r'shutdown', r'abort',
                r'cancel', r'cease'
            ],
            'enable_safety': [
                r'enable.*safety', r'turn on.*safe', r'activate.*protection',
                r'safety.*on', r'secure.*mode'
            ],
            'disable_safety': [
                r'disable.*safety', r'turn off.*safe', r'deactivate.*protection',
                r'safety.*off', r'expert.*mode'
            ],
            
            # Configuration Commands
            'change_strategy': [
                r'change.*strategy', r'set.*strategy', r'conservative', r'aggressive',
                r'balanced', r'mode.*change', r'switch.*mode'
            ],
            'set_preference': [
                r'prefer.*safe', r'prefer.*fast', r'favor.*simple', r'favor.*complex',
                r'set.*preference', r'my.*preference'
            ],
            
            # Memory Commands
            'show_memory': [
                r'show.*memory', r'what.*remember', r'conversation.*history',
                r'past.*talk', r'our.*chat', r'history'
            ],
            'clear_memory': [
                r'clear.*memory', r'forget', r'reset.*memory', r'wipe.*history'
            ]
        }
        
        # Command confidence scores
        self.confidence_scores = {}
        self.command_history = []
        
        print("🎯 Intent Recognizer initialized")
    
    def parse_neural_command(self, text: str) -> Tuple[str, str, float]:
        """
        Parse a natural language command and identify the intent.
        
        Args:
            text: The input command text
            
        Returns:
            action: The identified action type
            cleaned_text: The original text cleaned
            confidence: Confidence score (0-1)
        """
        if not text or not text.strip():
            return 'unknown', '', 0.0
        
        cleaned_text = text.lower().strip()
        
        # Find matching intents
        matches = []
        for action_type, patterns in self.command_patterns.items():
            for pattern in patterns:
                if re.search(pattern, cleaned_text):
                    matches.append(action_type)
                    break  # One match per action type is enough
        
        # Calculate confidence based on match quality and specificity
        if matches:
            # For now, take the first match - could be enhanced with scoring
            best_action = matches[0]
            confidence = self._calculate_confidence(cleaned_text, best_action)
            
            # Record command for learning
            self._record_command(cleaned_text, best_action, confidence)
            
            return best_action, cleaned_text, confidence
        else:
            # No clear intent found
            self._record_command(cleaned_text, 'unknown', 0.0)
            return 'unknown', cleaned_text, 0.0
    
    def _calculate_confidence(self, text: str, action: str) -> float:
        """
        Calculate confidence score for intent recognition.
        
        Args:
            text: The command text
            action: The identified action
            
        Returns:
            confidence: Confidence score between 0 and 1
        """
        base_confidence = 0.7  # Base confidence for any match
        
        # Boost confidence for exact phrase matches
        exact_phrases = {
            'evolve': 0.9,
            'stop': 0.95,
            'status': 0.9,
            'train': 0.85,
            'architecture': 0.8
        }
        
        for phrase, boost in exact_phrases.items():
            if phrase in text:
                base_confidence = max(base_confidence, boost)
        
        # Boost for command length (longer commands are often more specific)
        word_count = len(text.split())
        if word_count >= 4:
            base_confidence += 0.1
        elif word_count <= 2:
            base_confidence -= 0.1
        
        # Ensure confidence is within bounds
        return max(0.1, min(0.99, base_confidence))
    
    def _record_command(self, text: str, action: str, confidence: float):
        """Record command for learning and analysis."""
        command_record = {
            'timestamp': datetime.now().isoformat(),
            'text': text,
            'action': action,
            'confidence': confidence,
            'successful': None  # Will be updated based on outcome
        }
        
        self.command_history.append(command_record)
        
        # Keep only last 1000 commands
        if len(self.command_history) > 1000:
            self.command_history = self.command_history[-1000:]
    
    def learn_from_feedback(self, command_text: str, was_correct: bool):
        """
        Learn from feedback to improve intent recognition.
        
        Args:
            command_text: The original command text
            was_correct: Whether the interpretation was correct
        """
        # Find the command in history
        for record in reversed(self.command_history):
            if record['text'] == command_text.lower():
                record['successful'] = was_correct
                break
        
        # Update confidence scores based on feedback
        # This is a simple implementation - could be enhanced with ML
        print(f"📚 Learning from feedback: command '{command_text}' was {'correct' if was_correct else 'incorrect'}")
    
    def get_command_stats(self) -> Dict[str, Any]:
        """Get statistics about command recognition."""
        total_commands = len(self.command_history)
        successful_commands = sum(1 for cmd in self.command_history if cmd.get('successful', False))
        unknown_commands = sum(1 for cmd in self.command_history if cmd['action'] == 'unknown')
        
        # Count commands by type
        action_counts = {}
        for record in self.command_history:
            action = record['action']
            action_counts[action] = action_counts.get(action, 0) + 1
        
        return {
            'total_commands_processed': total_commands,
            'successful_interpretations': successful_commands,
            'success_rate': f"{(successful_commands/total_commands*100) if total_commands > 0 else 0:.1f}%",
            'unknown_commands': unknown_commands,
            'unknown_rate': f"{(unknown_commands/total_commands*100) if total_commands > 0 else 0:.1f}%",
            'action_distribution': action_counts,
            'available_actions': len(self.command_patterns)
        }
    
    def add_custom_command(self, action: str, patterns: List[str]):
        """
        Add custom command patterns for specialized applications.
        
        Args:
            action: The action type
            patterns: List of regex patterns to match
        """
        if action not in self.command_patterns:
            self.command_patterns[action] = []
        
        self.command_patterns[action].extend(patterns)
        print(f"✅ Added custom command '{action}' with {len(patterns)} patterns")
    
    def suggest_improvements(self) -> List[str]:
        """Suggest improvements based on command history analysis."""
        suggestions = []
        
        # Analyze unknown commands
        unknown_commands = [cmd['text'] for cmd in self.command_history if cmd['action'] == 'unknown']
        if unknown_commands:
            common_unknown = max(set(unknown_commands), key=unknown_commands.count)
            suggestions.append(f"Consider adding pattern for: '{common_unknown}'")
        
        # Analyze low confidence commands
        low_confidence = [cmd for cmd in self.command_history if cmd['confidence'] < 0.5]
        if low_confidence:
            suggestions.append(f"{len(low_confidence)} commands had low confidence")
        
        return suggestions