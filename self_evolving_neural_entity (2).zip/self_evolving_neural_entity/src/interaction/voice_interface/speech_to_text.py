# src/interaction/voice_interface/speech_to_text.py
import speech_recognition as sr
import threading
import time
import queue
import os
from typing import Optional, Callable, Dict, Any
from datetime import datetime

class VoiceInterface:
    """
    Real-time speech recognition with microphone input.
    
    Provides continuous listening capabilities with wake word detection
    and command processing for natural voice interaction.
    """
    
    def __init__(self, wake_word: str = "sene", energy_threshold: int = 300, 
                 pause_threshold: float = 0.8, timeout: int = 5):
        self.wake_word = wake_word.lower()
        self.energy_threshold = energy_threshold
        self.pause_threshold = pause_threshold
        self.timeout = timeout
        
        # Speech recognition components
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()
        self.audio_queue = queue.Queue()
        self.command_queue = queue.Queue()
        
        # State management
        self.is_listening = False
        self.is_awake = False
        self.listening_thread = None
        self.processing_thread = None
        
        # Audio recording
        self.is_recording = False
        self.audio_data = []
        self.record_start_time = None
        
        # Statistics
        self.recognition_stats = {
            'total_commands': 0,
            'successful_recognition': 0,
            'failed_recognition': 0,
            'wake_word_detections': 0,
            'last_activity': None
        }
        
        # Callbacks
        self.on_wake_word_detected = None
        self.on_command_received = None
        self.on_error = None
        
        # Configure the recognizer
        self._setup_recognizer()
        
        print(f"🎤 Voice Interface initialized (Wake word: '{self.wake_word}')")
    
    def _setup_recognizer(self):
        """Configure the speech recognizer with optimal settings."""
        try:
            # Adjust for ambient noise
            print("🔊 Calibrating microphone for ambient noise...")
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=2)
            
            # Set recognition parameters
            self.recognizer.energy_threshold = self.energy_threshold
            self.recognizer.pause_threshold = self.pause_threshold
            self.recognizer.dynamic_energy_threshold = True
            
            print("✅ Microphone calibrated successfully")
            
        except Exception as e:
            print(f"❌ Microphone setup failed: {e}")
            # Continue with default settings
    
    def start_listening(self):
        """Start continuous voice listening in background threads."""
        if self.is_listening:
            print("🔴 Already listening")
            return
        
        self.is_listening = True
        self.is_awake = False
        
        # Start listening thread
        self.listening_thread = threading.Thread(
            target=self._listening_worker, 
            daemon=True,
            name="VoiceListener"
        )
        self.listening_thread.start()
        
        # Start processing thread
        self.processing_thread = threading.Thread(
            target=self._processing_worker,
            daemon=True,
            name="VoiceProcessor"
        )
        self.processing_thread.start()
        
        print("🔴 Voice listening ACTIVATED")
        print(f"   Say '{self.wake_word}' to wake me up, then give commands")
        print("   Supported commands: 'add layer', 'train', 'evolve', 'status', etc.")
    
    def stop_listening(self):
        """Stop voice listening and clean up resources."""
        self.is_listening = False
        self.is_awake = False
        
        if self.listening_thread:
            self.listening_thread.join(timeout=2.0)
        if self.processing_thread:
            self.processing_thread.join(timeout=2.0)
        
        print("🔴 Voice listening stopped")
    
    def _listening_worker(self):
        """Background worker for continuous microphone listening."""
        print("🎧 Listening worker started...")
        
        while self.is_listening:
            try:
                with self.microphone as source:
                    # Listen for audio with timeout
                    print("🎤 Listening... (waiting for audio)")
                    audio = self.recognizer.listen(
                        source, 
                        timeout=self.timeout,
                        phrase_time_limit=10
                    )
                    
                    # Add audio to processing queue
                    self.audio_queue.put(audio)
                    print("✅ Audio captured and queued for processing")
                    
            except sr.WaitTimeoutError:
                # No speech detected within timeout, continue listening
                continue
            except sr.UnknownValueError:
                print("❌ Could not understand audio")
                self.recognition_stats['failed_recognition'] += 1
                continue
            except Exception as e:
                print(f"❌ Listening error: {e}")
                if self.on_error:
                    self.on_error(f"Listening error: {e}")
                time.sleep(1)  # Prevent tight loop on errors
    
    def _processing_worker(self):
        """Background worker for processing captured audio."""
        print("🧠 Audio processing worker started...")
        
        while self.is_listening:
            try:
                # Get audio from queue with timeout
                audio = self.audio_queue.get(timeout=1.0)
                
                # Convert speech to text
                text = self._recognize_speech(audio)
                if not text:
                    continue
                
                print(f"📝 Recognized: '{text}'")
                
                # Check for wake word
                if not self.is_awake:
                    if self.wake_word in text.lower():
                        self._handle_wake_word_detection(text)
                    continue
                
                # Process command (system is awake)
                self._process_command(text, audio)
                
            except queue.Empty:
                continue
            except Exception as e:
                print(f"❌ Processing error: {e}")
                if self.on_error:
                    self.on_error(f"Processing error: {e}")
    
    def _recognize_speech(self, audio) -> Optional[str]:
        """Convert audio to text using speech recognition."""
        try:
            # Use Google Speech Recognition
            text = self.recognizer.recognize_google(audio).lower().strip()
            self.recognition_stats['successful_recognition'] += 1
            self.recognition_stats['last_activity'] = datetime.now().isoformat()
            return text
            
        except sr.UnknownValueError:
            print("❌ Speech recognition could not understand audio")
            self.recognition_stats['failed_recognition'] += 1
        except sr.RequestError as e:
            print(f"❌ Speech recognition service error: {e}")
            if self.on_error:
                self.on_error(f"Speech recognition error: {e}")
        except Exception as e:
            print(f"❌ Unexpected recognition error: {e}")
        
        return None
    
    def _handle_wake_word_detection(self, text: str):
        """Handle wake word detection and system activation."""
        self.is_awake = True
        self.recognition_stats['wake_word_detections'] += 1
        
        # Remove wake word from text for cleaner command
        command = text.replace(self.wake_word, '').strip()
        
        print(f"🔔 Wake word detected! System is now AWAKE")
        print(f"   You said: '{text}'")
        
        if self.on_wake_word_detected:
            self.on_wake_word_detected(text)
        
        # If there's additional text after wake word, process it
        if command:
            print(f"   Processing immediate command: '{command}'")
            self.command_queue.put(command)
    
    def _process_command(self, text: str, audio=None):
        """Process a recognized command."""
        self.recognition_stats['total_commands'] += 1
        
        # Clean the command text
        cleaned_text = self._clean_command_text(text)
        
        print(f"🎯 Processing command: '{cleaned_text}'")
        
        # Add to command queue for main system
        self.command_queue.put(cleaned_text)
        
        # Record audio if enabled
        if self.is_recording and audio:
            self._record_audio(audio)
        
        # Notify callback
        if self.on_command_received:
            self.on_command_received(cleaned_text, audio)
    
    def _clean_command_text(self, text: str) -> str:
        """Clean and normalize command text."""
        # Remove common filler words and normalize
        filler_words = ['um', 'uh', 'like', 'you know', 'actually', 'basically']
        cleaned = text.lower().strip()
        
        for filler in filler_words:
            cleaned = cleaned.replace(f' {filler} ', ' ')
        
        # Remove extra whitespace
        cleaned = ' '.join(cleaned.split())
        
        return cleaned
    
    def start_recording(self, output_dir: str = "recordings"):
        """Start recording audio for training or analysis."""
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        self.is_recording = True
        self.audio_data = []
        self.record_start_time = datetime.now()
        
        print(f"🔴 Started recording audio to: {output_dir}")
    
    def stop_recording(self, filename: str = None) -> Optional[str]:
        """Stop recording and save audio file."""
        if not self.is_recording:
            return None
        
        self.is_recording = False
        
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"recording_{timestamp}.wav"
        
        # Save audio data (implementation depends on audio format)
        # This is a placeholder for actual audio saving logic
        
        print(f"💾 Recording saved as: {filename}")
        return filename
    
    def _record_audio(self, audio):
        """Record audio data for later use."""
        # This would actually save the audio data
        # For now, just track that we're recording
        self.audio_data.append(audio)
    
    def get_command(self, timeout: float = None) -> Optional[str]:
        """
        Get the next voice command from queue.
        
        Args:
            timeout: Optional timeout in seconds
            
        Returns:
            command: Voice command text or None
        """
        try:
            if timeout is None:
                return self.command_queue.get_nowait()
            else:
                return self.command_queue.get(timeout=timeout)
        except queue.Empty:
            return None
    
    def wait_for_command(self, timeout: float = None) -> Optional[str]:
        """
        Wait for a voice command with optional timeout.
        
        Args:
            timeout: Maximum time to wait in seconds
            
        Returns:
            command: Voice command text or None if timeout
        """
        return self.get_command(timeout)
    
    def set_wake_word(self, new_wake_word: str):
        """Change the wake word."""
        old_wake_word = self.wake_word
        self.wake_word = new_wake_word.lower()
        print(f"🔔 Wake word changed: '{old_wake_word}' -> '{self.wake_word}'")
    
    def set_energy_threshold(self, threshold: int):
        """Adjust microphone sensitivity."""
        self.energy_threshold = threshold
        self.recognizer.energy_threshold = threshold
        print(f"🎚️ Energy threshold set to: {threshold}")
    
    def get_voice_stats(self) -> Dict[str, Any]:
        """Get voice recognition statistics."""
        return {
            'is_listening': self.is_listening,
            'is_awake': self.is_awake,
            'wake_word': self.wake_word,
            'total_commands_received': self.recognition_stats['total_commands'],
            'successful_recognitions': self.recognition_stats['successful_recognition'],
            'failed_recognitions': self.recognition_stats['failed_recognition'],
            'wake_word_detections': self.recognition_stats['wake_word_detections'],
            'last_activity': self.recognition_stats['last_activity'],
            'is_recording': self.is_recording,
            'queue_size': self.command_queue.qsize()
        }
    
    def reset_stats(self):
        """Reset recognition statistics."""
        self.recognition_stats = {
            'total_commands': 0,
            'successful_recognition': 0,
            'failed_recognition': 0,
            'wake_word_detections': 0,
            'last_activity': None
        }
        print("🔄 Voice statistics reset")
    
    # Callback setters
    def set_wake_word_callback(self, callback: Callable):
        """Set callback for wake word detection."""
        self.on_wake_word_detected = callback
    
    def set_command_callback(self, callback: Callable):
        """Set callback for command reception."""
        self.on_command_received = callback
    
    def set_error_callback(self, callback: Callable):
        """Set callback for error handling."""
        self.on_error = callback