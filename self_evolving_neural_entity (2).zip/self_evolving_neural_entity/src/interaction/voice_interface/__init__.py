# src/interaction/voice_interface/__init__.py
"""
Voice interface for the Self-Evolving Neural Entity.

This module provides speech-to-text and text-to-speech capabilities
for natural voice interaction with the SENE system.
"""

from .speech_to_text import VoiceInterface
from .text_to_speech import TextToSpeech
from .wake_word import WakeWordDetector

__all__ = [
    'VoiceInterface',
    'TextToSpeech', 
    'WakeWordDetector'
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Voice interaction system for SENE'

print("🎤 SENE Voice Interface loaded - Speech recognition ready")