# src/memory/__init__.py
"""
Memory system for the Self-Evolving Neural Entity.

This module provides persistent memory capabilities including
conversation history, decision logging, and context management
for long-term learning and personalization.
"""

from .conversation_memory import ConversationMemory
from .decision_log import DecisionLogger
from .context_window import ContextWindow

__all__ = [
    'ConversationMemory',
    'DecisionLogger', 
    'ContextWindow'
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Persistent memory system for learning and context'

print("🧠 SENE Memory module loaded - Long-term memory capabilities ready")