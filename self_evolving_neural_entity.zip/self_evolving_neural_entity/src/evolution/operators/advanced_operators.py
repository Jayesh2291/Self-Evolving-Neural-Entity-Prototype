# src/evolution/operators/advanced_operators.py
import torch
import torch.nn as nn
import random
from typing import Tuple, Dict, Any, List

class AttentionMechanismOperator:
    """
    Advanced operator that adds attention mechanisms to the neural network.
    
    Attention allows the network to focus on important parts of the input,
    improving performance on sequence and structured data tasks.
    """
    
    def __init__(self, max_attention_layers: int = 2):
        self.max_attention_layers = max_attention_layers
        self.operation_count = 0
        
        print(f"🧬 AttentionMechanismOperator initialized")
    
    def apply(self, enn: nn.Module, context: Dict = None) -> Tuple[bool, str]:
        """
        Add an attention mechanism to the network.
        
        Args:
            enn: The neural network to modify
            context: Additional context information
            
        Returns:
            success: Whether operation was successful
            message: Description of what was done
        """
        # Check if we can add more attention layers
        current_attention_layers = self._count_attention_layers(enn)
        if current_attention_layers >= self.max_attention_layers:
            return False, f"Maximum attention layers ({self.max_attention_layers}) reached"
        
        # Check if network has suitable architecture for attention
        if len(enn.blocks) < 2:
            return False, "Network too small for attention mechanism"
        
        # Add attention mechanism
        position = self._select_attention_position(enn)
        success = self._insert_attention_layer(enn, position)
        
        if success:
            self.operation_count += 1
            message = f"Added attention mechanism at position {position}"
            return True, message
        else:
            return False, "Failed to add attention mechanism"
    
    def _count_attention_layers(self, enn: nn.Module) -> int:
        """Count how many attention layers already exist in the network."""
        count = 0
        for block in enn.blocks:
            if hasattr(block, '_is_attention_layer'):
                count += 1
        return count
    
    def _select_attention_position(self, enn: nn.Module) -> int:
        """Select position to insert attention mechanism."""
        # Prefer positions after some feature extraction
        if len(enn.blocks) >= 3:
            return random.randint(1, len(enn.blocks) - 1)
        else:
            return len(enn.blocks) - 1  # Before output
    
    def _insert_attention_layer(self, enn: nn.Module, position: int) -> bool:
        """Insert an attention layer at the specified position."""
        try:
            # Get the embedding dimension from the previous layer
            if position == 0:
                embed_dim = enn.input_dim
            else:
                embed_dim = enn.blocks[position-1][0].out_features
            
            # Create multi-head attention layer
            attention_layer = nn.MultiheadAttention(
                embed_dim=embed_dim,
                num_heads=max(2, embed_dim // 32),  # Adaptive number of heads
                dropout=0.1,
                batch_first=True
            )
            
            # Mark as attention layer for tracking
            attention_layer._is_attention_layer = True
            
            # Insert into network
            enn.blocks.insert(position, attention_layer)
            
            # Reinitialize optimizer
            enn.optimizer = torch.optim.Adam(enn.parameters(), lr=enn.learning_rate)
            
            return True
            
        except Exception as e:
            print(f"❌ Error adding attention layer: {e}")
            return False
    
    def get_operator_stats(self) -> Dict[str, Any]:
        """Get statistics about this operator's usage."""
        return {
            'operator_type': 'attention_mechanism',
            'operation_count': self.operation_count,
            'max_attention_layers': self.max_attention_layers
        }


class ActivationFunctionOperator:
    """
    Operator that changes activation functions in the network.
    
    Different activation functions can significantly impact:
    - Learning speed
    - Gradient flow
    - Network non-linearity
    - Training stability
    """
    
    def __init__(self):
        self.activation_functions = {
            'relu': nn.ReLU(),
            'leaky_relu': nn.LeakyReLU(0.1),
            'selu': nn.SELU(),
            'gelu': nn.GELU(),
            'swish': nn.SiLU(),  # Also known as Swish
            'tanh': nn.Tanh(),
            'sigmoid': nn.Sigmoid()
        }
        self.operation_count = 0
        
        print(f"🧬 ActivationFunctionOperator initialized")
    
    def apply(self, enn: nn.Module, context: Dict = None) -> Tuple[bool, str]:
        """
        Change activation functions in the network.
        
        Args:
            enn: The neural network to modify
            context: Additional context information
            
        Returns:
            success: Whether operation was successful
            message: Description of what was done
        """
        if not enn.blocks:
            return False, "No layers to modify"
        
        # Select which activation to use
        new_activation_name = self._select_activation(context)
        new_activation = self.activation_functions[new_activation_name]
        
        # Select which layers to modify
        layers_to_modify = self._select_layers_to_modify(enn, context)
        
        modified_count = 0
        for layer_idx in layers_to_modify:
            if self._modify_layer_activation(enn, layer_idx, new_activation):
                modified_count += 1
        
        if modified_count > 0:
            self.operation_count += 1
            message = f"Changed activation to {new_activation_name} in {modified_count} layers"
            return True, message
        else:
            return False, "Failed to modify any activations"
    
    def _select_activation(self, context: Dict) -> str:
        """Select which activation function to use."""
        # Weight activations based on context
        activations = list(self.activation_functions.keys())
        
        if context and context.get('stability', 1.0) < 0.6:
            # Unstable - prefer stable activations
            weights = [0.3, 0.2, 0.2, 0.1, 0.1, 0.05, 0.05]  # ReLU, LeakyReLU, SELU favored
        elif context and context.get('performance', 0.5) > 0.8:
            # High performance - try advanced activations
            weights = [0.1, 0.1, 0.2, 0.3, 0.2, 0.05, 0.05]  # GELU, Swish, SELU favored
        else:
            # Balanced approach
            weights = [0.2, 0.2, 0.15, 0.15, 0.15, 0.1, 0.05]
        
        return random.choices(activations, weights=weights)[0]
    
    def _select_layers_to_modify(self, enn: nn.Module, context: Dict) -> List[int]:
        """Select which layers to modify."""
        num_layers = len(enn.blocks)
        
        # Decide how many layers to modify (1 to 50% of layers)
        max_modify = max(1, num_layers // 2)
        num_to_modify = random.randint(1, max_modify)
        
        # Select random layers
        return random.sample(range(num_layers), num_to_modify)
    
    def _modify_layer_activation(self, enn: nn.Module, layer_idx: int, new_activation: nn.Module) -> bool:
        """Modify activation function in a specific layer."""
        try:
            old_block = enn.blocks[layer_idx]
            
            if isinstance(old_block, nn.Sequential) and len(old_block) > 1:
                # Replace the activation function (assuming it's the second element)
                new_block = nn.Sequential(
                    old_block[0],  # Keep linear layer
                    new_activation,  # New activation
                    *list(old_block[2:])  # Keep any other layers (dropout, etc.)
                )
                enn.blocks[layer_idx] = new_block
                return True
            else:
                return False
                
        except Exception as e:
            print(f"❌ Error modifying layer {layer_idx}: {e}")
            return False
    
    def get_operator_stats(self) -> Dict[str, Any]:
        """Get statistics about this operator's usage."""
        return {
            'operator_type': 'activation_function',
            'operation_count': self.operation_count,
            'available_activations': list(self.activation_functions.keys())
        }


class LearningRateAdaptationOperator:
    """
    Operator that adapts the learning rate for better training performance.
    
    Learning rate is crucial for:
    - Convergence speed
    - Training stability
    - Final performance
    """
    
    def __init__(self, min_lr: float = 1e-6, max_lr: float = 1e-1):
        self.min_lr = min_lr
        self.max_lr = max_lr
        self.operation_count = 0
        
        print(f"🧬 LearningRateAdaptationOperator initialized")
    
    def apply(self, enn: nn.Module, context: Dict = None) -> Tuple[bool, str]:
        """
        Adapt the learning rate based on current performance.
        
        Args:
            enn: The neural network to modify
            context: Additional context information
            
        Returns:
            success: Whether operation was successful
            message: Description of what was done
        """
        current_lr = enn.optimizer.param_groups[0]['lr']
        new_lr = self._calculate_new_learning_rate(current_lr, context)
        
        # Apply new learning rate
        for param_group in enn.optimizer.param_groups:
            param_group['lr'] = new_lr
        
        enn.learning_rate = new_lr
        self.operation_count += 1
        
        direction = "increased" if new_lr > current_lr else "decreased"
        message = f"Learning rate {direction} from {current_lr:.2e} to {new_lr:.2e}"
        return True, message
    
    def _calculate_new_learning_rate(self, current_lr: float, context: Dict) -> float:
        """Calculate new learning rate based on context."""
        if context is None:
            # No context - small random adjustment
            change_factor = random.uniform(0.8, 1.2)
        else:
            # Context-aware adjustment
            performance = context.get('performance', 0.5)
            stability = context.get('stability', 0.5)
            
            if stability < 0.6:
                # Unstable - decrease learning rate
                change_factor = random.uniform(0.5, 0.9)
            elif performance < 0.3:
                # Low performance - try larger changes
                change_factor = random.uniform(1.5, 2.5)
            elif performance > 0.8 and stability > 0.8:
                # High performance and stable - fine-tune
                change_factor = random.uniform(0.9, 1.1)
            else:
                # Normal case - moderate changes
                change_factor = random.uniform(0.8, 1.3)
        
        new_lr = current_lr * change_factor
        
        # Apply bounds
        return max(self.min_lr, min(self.max_lr, new_lr))
    
    def get_operator_stats(self) -> Dict[str, Any]:
        """Get statistics about this operator's usage."""
        return {
            'operator_type': 'learning_rate_adaptation',
            'operation_count': self.operation_count,
            'min_learning_rate': self.min_lr,
            'max_learning_rate': self.max_lr
        }