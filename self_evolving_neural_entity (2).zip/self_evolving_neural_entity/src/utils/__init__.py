# src/utils/__init__.py
"""
Utility modules for the Self-Evolving Neural Entity.

This module provides essential utilities including configuration management,
logging, safety monitoring, and other helper functions for the SENE system.
"""

from .config import ConfigManager, SENEConfig
from .logging import SeneLogger, PerformanceTracker
from .safety_monitor import SafetyMonitor
from .serialization import ModelSerializer, DataSerializer

__all__ = [
    # Configuration
    'ConfigManager',
    'SENEConfig',
    
    # Logging & Monitoring
    'SeneLogger', 
    'PerformanceTracker',
    
    # Safety
    'SafetyMonitor',
    
    # Serialization
    'ModelSerializer',
    'DataSerializer'
]

# Version info
__version__ = '1.0.0'
__author__ = 'SENE Project'
__description__ = 'Utility functions and system management tools'

print("🔧 SENE Utilities loaded - System management tools ready")