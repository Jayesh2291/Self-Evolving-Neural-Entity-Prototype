# src/applications/stock_predictor.py
import yfinance as yf
import pandas as pd
import numpy as np
import torch
from datetime import datetime

class StockPredictorSENE:
    """SENE applied to stock prediction"""
    
    def __init__(self, sene_core):
        self.sene = sene_core
        self.stock_data = None
        self.prediction_history = []
        self.symbol = None
        
    def load_stock_data(self, symbol, period='6mo'):
        """Load stock data for training"""
        try:
            self.symbol = symbol
            stock = yf.Ticker(symbol)
            self.stock_data = stock.history(period=period)
            return True, f"Loaded {symbol} data: {len(self.stock_data)} days of trading data"
        except Exception as e:
            return False, f"Error loading stock data: {e}"
    
    def create_training_features(self, window_size=10):
        """Create features from stock data"""
        if self.stock_data is None:
            return None, None
            
        data = self.stock_data['Close'].values
        features = []
        targets = []
        
        for i in range(window_size, len(data)-1):
            window = data[i-window_size:i]
            # Normalize the window
            normalized_window = (window - window.mean()) / (window.std() + 1e-8)
            features.append(normalized_window)
            # Predict next day direction (1=up, 0=down)
            target = 1 if data[i+1] > data[i] else 0
            targets.append(target)
            
        return np.array(features), np.array(targets)
    
    def train_on_stock_data(self, symbol='AAPL', window_size=10):
        """Train the neural network on stock data"""
        success, message = self.load_stock_data(symbol)
        if not success:
            return False, message
            
        features, targets = self.create_training_features(window_size)
        if features is None:
            return False, "Could not create features from stock data"
        
        # Convert to tensors
        features_tensor = torch.FloatTensor(features)
        targets_tensor = torch.LongTensor(targets)
        
        # Train for a few epochs
        for epoch in range(10):
            total_loss = 0
            for i in range(len(features)):
                self.sene.neural_network.optimizer.zero_grad()
                output = self.sene.neural_network(features_tensor[i])
                loss = torch.nn.functional.cross_entropy(output.unsqueeze(0), targets_tensor[i].unsqueeze(0))
                loss.backward()
                self.sene.neural_network.optimizer.step()
                total_loss += loss.item()
            
            if epoch % 2 == 0:
                print(f"📈 Stock training epoch {epoch}, loss: {total_loss/len(features):.4f}")
        
        return True, f"Trained on {symbol} data. Ready for predictions."
    
    def predict_next_day(self, symbol=None):
        """Predict next day movement"""
        if symbol and symbol != self.symbol:
            self.load_stock_data(symbol)
            
        if self.stock_data is None:
            return None, "No stock data loaded"
            
        features, _ = self.create_training_features()
        if features is None or len(features) == 0:
            return None, "Not enough data for prediction"
        
        # Use the most recent window for prediction
        latest_window = features[-1]
        
        with torch.no_grad():
            prediction = self.sene.neural_network(latest_window)
            direction = torch.argmax(prediction).item()
            confidence = torch.softmax(prediction, dim=0)[direction].item()
            
        direction_text = "UP" if direction == 1 else "DOWN"
        
        prediction_info = {
            'symbol': self.symbol,
            'prediction': direction_text,
            'confidence': f"{confidence:.2%}",
            'timestamp': datetime.now().isoformat()
        }
        
        self.prediction_history.append(prediction_info)
        return prediction_info, f"Prediction: {direction_text} with {confidence:.2%} confidence"