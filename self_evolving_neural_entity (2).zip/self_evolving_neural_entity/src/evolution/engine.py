# src/evolution/engine.py
import random
import time
from datetime import datetime
from typing import Dict, List, Tuple, Any, Optional
import torch.nn as nn

from .operators import (
    AddLayerOperator,
    RemoveLayerOperator,
    AttentionMechanismOperator,
    ActivationFunctionOperator,
    LearningRateAdaptationOperator
)

class EvolutionEngine:
    """
    Main evolution engine that orchestrates neural network evolution.
    
    This engine manages the complete evolution process including:
    - Operator selection and application
    - Performance evaluation
    - Evolution strategy management
    - Safety and validation
    """
    
    def __init__(self, evolution_strategy: str = "balanced"):
        """
        Initialize the evolution engine.
        
        Args:
            evolution_strategy: Strategy for evolution ('conservative', 'balanced', 'aggressive')
        """
        self.evolution_strategy = evolution_strategy
        self.evolution_count = 0
        self.successful_evolutions = 0
        self.failed_evolutions = 0
        
        # Initialize evolution operators
        self.operators = self._initialize_operators()
        
        # Evolution history and statistics
        self.evolution_history = []
        self.performance_trend = []
        
        # Strategy configurations
        self.strategy_configs = {
            'conservative': {
                'mutation_rate': 0.1,
                'operator_weights': [0.4, 0.1, 0.1, 0.2, 0.2],  # add, remove, attention, activation, lr
                'safety_threshold': 0.8,
                'max_operations_per_cycle': 1
            },
            'balanced': {
                'mutation_rate': 0.3,
                'operator_weights': [0.3, 0.2, 0.15, 0.2, 0.15],
                'safety_threshold': 0.6,
                'max_operations_per_cycle': 2
            },
            'aggressive': {
                'mutation_rate': 0.5,
                'operator_weights': [0.25, 0.25, 0.2, 0.2, 0.1],
                'safety_threshold': 0.4,
                'max_operations_per_cycle': 3
            }
        }
        
        self.current_config = self.strategy_configs[evolution_strategy]
        
        print(f"🧬 Evolution Engine initialized with '{evolution_strategy}' strategy")
        print(f"   Mutation rate: {self.current_config['mutation_rate']}")
        print(f"   Safety threshold: {self.current_config['safety_threshold']}")
    
    def _initialize_operators(self) -> Dict[str, Any]:
        """Initialize all available evolution operators."""
        return {
            'add_layer': AddLayerOperator(max_layers=10),
            'remove_layer': RemoveLayerOperator(min_layers=1),
            'attention': AttentionMechanismOperator(max_attention_layers=3),
            'activation': ActivationFunctionOperator(),
            'learning_rate': LearningRateAdaptationOperator()
        }
    
    def propose_evolution(self, enn: nn.Module, performance_metrics: Dict) -> Tuple[bool, str]:
        """
        Propose and execute neural architecture evolution.
        
        Args:
            enn: The neural network to evolve
            performance_metrics: Current performance metrics
            
        Returns:
            evolved: Whether evolution occurred
            message: Description of what happened
        """
        # Check if we should evolve based on mutation rate
        if random.random() > self.current_config['mutation_rate']:
            return False, "No evolution triggered (mutation rate)"
        
        # Analyze current state to guide evolution
        state_analysis = self._analyze_current_state(enn, performance_metrics)
        
        # Select operators based on current state and strategy
        selected_operators = self._select_operators(state_analysis)
        
        if not selected_operators:
            return False, "No suitable operators found for current state"
        
        # Apply selected operators
        evolution_results = []
        successful_operations = 0
        
        for operator_name in selected_operators:
            operator = self.operators[operator_name]
            
            # Apply the operator
            success, message = operator.apply(enn, performance_metrics)
            
            evolution_results.append({
                'operator': operator_name,
                'success': success,
                'message': message,
                'timestamp': datetime.now().isoformat()
            })
            
            if success:
                successful_operations += 1
                print(f"🧬 Evolution: {message}")
        
        # Record evolution event
        evolution_event = {
            'evolution_id': self.evolution_count,
            'timestamp': datetime.now().isoformat(),
            'strategy': self.evolution_strategy,
            'operations_applied': successful_operations,
            'total_operations': len(selected_operators),
            'performance_metrics': performance_metrics.copy(),
            'architecture_before': state_analysis.get('previous_architecture', []),
            'architecture_after': enn.get_architecture(),
            'operator_results': evolution_results,
            'state_analysis': state_analysis
        }
        
        self.evolution_history.append(evolution_event)
        self.evolution_count += 1
        
        if successful_operations > 0:
            self.successful_evolutions += 1
            message = f"Evolution #{self.evolution_count}: Applied {successful_operations} operations"
            return True, message
        else:
            self.failed_evolutions += 1
            return False, "Evolution attempted but no operations succeeded"
    
    def _analyze_current_state(self, enn: nn.Module, metrics: Dict) -> Dict[str, Any]:
        """
        Analyze current network state to guide evolution decisions.
        
        Args:
            enn: Neural network
            metrics: Performance metrics
            
        Returns:
            analysis: State analysis dictionary
        """
        current_architecture = enn.get_architecture()
        performance = metrics.get('performance', 0.5)
        stability = metrics.get('stability', 0.5)
        complexity = self._calculate_complexity(enn)
        
        analysis = {
            'previous_architecture': current_architecture.copy(),
            'performance_level': performance,
            'stability_level': stability,
            'complexity_level': complexity,
            'needs_capacity': performance < 0.6 and stability > 0.7,
            'needs_simplification': complexity > 0.7 and performance < 0.5,
            'needs_optimization': stability < 0.6,
            'needs_innovation': performance > 0.8 and stability > 0.8,
            'layer_count': len(enn.blocks),
            'parameter_count': self._count_parameters(enn),
            'learning_rate': enn.learning_rate
        }
        
        return analysis
    
    def _calculate_complexity(self, enn: nn.Module) -> float:
        """Calculate network complexity score (0-1)."""
        if not enn.blocks:
            return 0.0
        
        # Simple complexity metric based on layers and parameters
        layer_count = len(enn.blocks)
        param_count = self._count_parameters(enn)
        
        # Normalize to 0-1 range (these thresholds can be adjusted)
        layer_complexity = min(layer_count / 10.0, 1.0)  # Max 10 layers = 1.0
        param_complexity = min(param_count / 100000.0, 1.0)  # Max 100k params = 1.0
        
        return (layer_complexity + param_complexity) / 2.0
    
    def _count_parameters(self, enn: nn.Module) -> int:
        """Count total trainable parameters."""
        return sum(p.numel() for p in enn.parameters() if p.requires_grad)
    
    def _select_operators(self, state_analysis: Dict) -> List[str]:
        """
        Select which operators to apply based on current state.
        
        Args:
            state_analysis: Analysis of current network state
            
        Returns:
            selected_operators: List of operator names to apply
        """
        base_operators = list(self.operators.keys())
        base_weights = self.current_config['operator_weights']
        
        # Adjust weights based on state analysis
        adjusted_weights = self._adjust_operator_weights(base_weights, state_analysis)
        
        # Select operators based on adjusted weights
        max_operations = self.current_config['max_operations_per_cycle']
        num_to_select = random.randint(1, max_operations)
        
        selected_operators = random.choices(
            base_operators, 
            weights=adjusted_weights, 
            k=num_to_select
        )
        
        return selected_operators
    
    def _adjust_operator_weights(self, base_weights: List[float], 
                               state_analysis: Dict) -> List[float]:
        """
        Adjust operator weights based on current network state.
        
        Args:
            base_weights: Base weights for operators
            state_analysis: Current state analysis
            
        Returns:
            adjusted_weights: Adjusted weights for operator selection
        """
        adjusted_weights = base_weights.copy()
        operators = ['add_layer', 'remove_layer', 'attention', 'activation', 'learning_rate']
        
        # Apply state-based adjustments
        if state_analysis['needs_capacity']:
            # Favor adding layers and capacity
            adjusted_weights[0] *= 1.5  # add_layer
            adjusted_weights[2] *= 1.2  # attention
        
        if state_analysis['needs_simplification']:
            # Favor removal and optimization
            adjusted_weights[1] *= 2.0  # remove_layer
            adjusted_weights[4] *= 1.3  # learning_rate
        
        if state_analysis['needs_optimization']:
            # Favor learning rate and activation optimization
            adjusted_weights[3] *= 1.5  # activation
            adjusted_weights[4] *= 1.8  # learning_rate
        
        if state_analysis['needs_innovation']:
            # Favor advanced operations
            adjusted_weights[2] *= 1.8  # attention
            adjusted_weights[3] *= 1.3  # activation
        
        # Ensure weights are positive and normalized
        adjusted_weights = [max(0.1, w) for w in adjusted_weights]
        total = sum(adjusted_weights)
        adjusted_weights = [w / total for w in adjusted_weights]
        
        return adjusted_weights
    
    def set_evolution_strategy(self, strategy: str):
        """
        Change the evolution strategy.
        
        Args:
            strategy: New strategy ('conservative', 'balanced', 'aggressive')
        """
        if strategy not in self.strategy_configs:
            print(f"❌ Unknown strategy: {strategy}. Using 'balanced'.")
            strategy = 'balanced'
        
        self.evolution_strategy = strategy
        self.current_config = self.strategy_configs[strategy]
        
        print(f"🔄 Evolution strategy changed to '{strategy}'")
        print(f"   New mutation rate: {self.current_config['mutation_rate']}")
    
    def get_evolution_stats(self) -> Dict[str, Any]:
        """Get comprehensive evolution statistics."""
        total_evolutions = self.evolution_count
        success_rate = (self.successful_evolutions / total_evolutions * 100) if total_evolutions > 0 else 0
        
        # Count operations by type
        operation_counts = {}
        for op_name, operator in self.operators.items():
            operation_counts[op_name] = operator.operation_count
        
        # Get recent evolution trend
        recent_evolutions = self.evolution_history[-10:]  # Last 10 evolutions
        recent_success_rate = (
            sum(1 for e in recent_evolutions if e['operations_applied'] > 0) / len(recent_evolutions) * 100
        ) if recent_evolutions else 0
        
        return {
            'total_evolutions': total_evolutions,
            'successful_evolutions': self.successful_evolutions,
            'failed_evolutions': self.failed_evolutions,
            'success_rate': f"{success_rate:.1f}%",
            'recent_success_rate': f"{recent_success_rate:.1f}%",
            'current_strategy': self.evolution_strategy,
            'mutation_rate': self.current_config['mutation_rate'],
            'operation_counts': operation_counts,
            'total_operations': sum(operation_counts.values()),
            'evolution_history_size': len(self.evolution_history)
        }
    
    def get_operator_stats(self) -> Dict[str, Any]:
        """Get detailed statistics for all operators."""
        stats = {}
        for op_name, operator in self.operators.items():
            stats[op_name] = operator.get_operator_stats()
        return stats
    
    def get_recent_evolution_history(self, count: int = 5) -> List[Dict]:
        """Get recent evolution history."""
        return self.evolution_history[-count:] if self.evolution_history else []
    
    def reset_evolution_history(self):
        """Reset evolution history (use with caution)."""
        self.evolution_history.clear()
        self.evolution_count = 0
        self.successful_evolutions = 0
        self.failed_evolutions = 0
        print("🔄 Evolution history reset")
    
    def suggest_strategy_change(self, performance_trend: List[float]) -> Optional[str]:
        """
        Suggest strategy changes based on performance trend.
        
        Args:
            performance_trend: List of recent performance scores
            
        Returns:
            suggested_strategy: Suggested new strategy or None
        """
        if len(performance_trend) < 5:
            return None
        
        # Analyze trend
        recent_performance = performance_trend[-5:]
        avg_recent = sum(recent_performance) / len(recent_performance)
        
        if avg_recent < 0.3 and self.evolution_strategy != 'aggressive':
            return 'aggressive'
        elif avg_recent > 0.8 and self.evolution_strategy != 'conservative':
            return 'conservative'
        elif 0.4 <= avg_recent <= 0.7 and self.evolution_strategy != 'balanced':
            return 'balanced'
        
        return None

# Factory function for easy engine creation
def create_evolution_engine(strategy: str = "balanced") -> EvolutionEngine:
    """
    Create an evolution engine with the specified strategy.
    
    Args:
        strategy: Evolution strategy ('conservative', 'balanced', 'aggressive')
        
    Returns:
        evolution_engine: Configured evolution engine instance
    """
    return EvolutionEngine(strategy)