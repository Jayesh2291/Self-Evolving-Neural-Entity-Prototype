# src/interaction/command_parser/context_tracker.py
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta

class ContextTracker:
    """
    Tracks conversation context and user preferences.
    
    This class maintains the context of ongoing conversations
    and user preferences to provide more intelligent responses.
    """
    
    def __init__(self, max_context_length: int = 20, memory_duration_hours: int = 24):
        self.max_context_length = max_context_length
        self.memory_duration_hours = memory_duration_hours
        
        # Conversation context
        self.conversation_history = []
        self.current_topic = None
        self.user_preferences = {}
        
        # System state context
        self.system_state = {}
        self.last_actions = []
        
        # User profile
        self.user_profile = {
            'experience_level': 'beginner',  # beginner, intermediate, expert
            'preferred_complexity': 'balanced',
            'risk_tolerance': 'medium',
            'interaction_style': 'collaborative'  # collaborative, directive, autonomous
        }
        
        print("🎭 Context Tracker initialized")
    
    def add_conversation_turn(self, user_input: str, system_response: str, intent: str = None):
        """
        Add a conversation turn to the context.
        
        Args:
            user_input: What the user said
            system_response: How the system responded
            intent: The recognized intent (optional)
        """
        conversation_turn = {
            'timestamp': datetime.now().isoformat(),
            'user_input': user_input,
            'system_response': system_response,
            'intent': intent,
            'turn_number': len(self.conversation_history) + 1
        }
        
        self.conversation_history.append(conversation_turn)
        
        # Update current topic based on conversation
        self._update_current_topic(user_input, system_response)
        
        # Clean old conversations
        self._clean_old_conversations()
        
        # Keep within max length
        if len(self.conversation_history) > self.max_context_length:
            self.conversation_history = self.conversation_history[-self.max_context_length:]
    
    def _update_current_topic(self, user_input: str, system_response: str):
        """Update the current topic based on conversation content."""
        # Simple topic detection based on keywords
        topics = {
            'architecture': ['layer', 'network', 'neuron', 'architecture', 'structure'],
            'training': ['train', 'learn', 'practice', 'episode', 'reward'],
            'evolution': ['evolve', 'improve', 'optimize', 'enhance', 'better'],
            'research': ['research', 'search', 'find', 'look up', 'information'],
            'applications': ['app', 'application', 'project', 'stock', 'game', 'predict'],
            'safety': ['safe', 'danger', 'risk', 'careful', 'protection']
        }
        
        combined_text = (user_input + ' ' + system_response).lower()
        
        topic_scores = {}
        for topic, keywords in topics.items():
            score = sum(1 for keyword in keywords if keyword in combined_text)
            if score > 0:
                topic_scores[topic] = score
        
        if topic_scores:
            self.current_topic = max(topic_scores, key=topic_scores.get)
        else:
            self.current_topic = 'general'
    
    def _clean_old_conversations(self):
        """Remove conversations older than the memory duration."""
        cutoff_time = datetime.now() - timedelta(hours=self.memory_duration_hours)
        
        self.conversation_history = [
            turn for turn in self.conversation_history
            if datetime.fromisoformat(turn['timestamp']) > cutoff_time
        ]
    
    def get_recent_context(self, num_turns: int = 5) -> List[Dict]:
        """
        Get recent conversation context.
        
        Args:
            num_turns: Number of recent turns to return
            
        Returns:
            recent_turns: List of recent conversation turns
        """
        return self.conversation_history[-num_turns:] if self.conversation_history else []
    
    def get_conversation_summary(self) -> Dict[str, Any]:
        """Get a summary of the current conversation context."""
        if not self.conversation_history:
            return {'summary': 'No conversation history'}
        
        recent_turns = self.get_recent_context(3)
        intents = [turn.get('intent') for turn in recent_turns if turn.get('intent')]
        
        return {
            'current_topic': self.current_topic,
            'conversation_length': len(self.conversation_history),
            'recent_intents': intents,
            'last_user_input': self.conversation_history[-1]['user_input'] if self.conversation_history else None,
            'user_experience_level': self.user_profile['experience_level']
        }
    
    def update_user_preference(self, preference_type: str, value: Any):
        """
        Update user preferences based on interactions.
        
        Args:
            preference_type: Type of preference
            value: Preference value
        """
        self.user_preferences[preference_type] = {
            'value': value,
            'last_updated': datetime.now().isoformat(),
            'confidence': 0.8  # Could be adjusted based on consistency
        }
        
        # Update user profile based on preferences
        self._update_user_profile()
    
    def _update_user_profile(self):
        """Update user profile based on accumulated preferences."""
        # Analyze preferences to determine experience level
        if 'preferred_complexity' in self.user_preferences:
            complexity = self.user_preferences['preferred_complexity']['value']
            if complexity == 'complex':
                self.user_profile['experience_level'] = 'expert'
            elif complexity == 'simple':
                self.user_profile['experience_level'] = 'beginner'
        
        # Update interaction style based on command patterns
        autonomous_commands = ['auto_evolve', 'auto_train', 'continuous']
        collaborative_commands = ['suggest', 'recommend', 'what do you think']
        directive_commands = ['do this', 'execute', 'run now']
        
        recent_commands = [turn['user_input'].lower() for turn in self.conversation_history[-10:]]
        
        autonomous_count = sum(1 for cmd in recent_commands if any(ac in cmd for ac in autonomous_commands))
        collaborative_count = sum(1 for cmd in recent_commands if any(cc in cmd for cc in collaborative_commands))
        directive_count = sum(1 for cmd in recent_commands if any(dc in cmd for dc in directive_commands))
        
        if autonomous_count > collaborative_count and autonomous_count > directive_count:
            self.user_profile['interaction_style'] = 'autonomous'
        elif directive_count > collaborative_count and directive_count > autonomous_count:
            self.user_profile['interaction_style'] = 'directive'
        else:
            self.user_profile['interaction_style'] = 'collaborative'
    
    def update_system_state(self, state_updates: Dict):
        """
        Update system state context.
        
        Args:
            state_updates: Dictionary of state updates
        """
        self.system_state.update(state_updates)
    
    def record_action(self, action: str, result: str = None):
        """
        Record a system action for context.
        
        Args:
            action: The action performed
            result: The result of the action
        """
        action_record = {
            'action': action,
            'result': result,
            'timestamp': datetime.now().isoformat()
        }
        
        self.last_actions.append(action_record)
        
        # Keep only recent actions
        if len(self.last_actions) > 10:
            self.last_actions = self.last_actions[-10:]
    
    def get_context_for_response(self) -> Dict[str, Any]:
        """
        Get comprehensive context for generating responses.
        
        Returns:
            context: Complete context information
        """
        return {
            'conversation_summary': self.get_conversation_summary(),
            'user_profile': self.user_profile.copy(),
            'user_preferences': self.user_preferences.copy(),
            'system_state': self.system_state.copy(),
            'recent_actions': self.last_actions.copy(),
            'current_topic': self.current_topic
        }
    
    def should_request_clarification(self, intent: str, confidence: float) -> bool:
        """
        Determine if clarification should be requested.
        
        Args:
            intent: The recognized intent
            confidence: Confidence score
            
        Returns:
            should_clarify: Whether to request clarification
        """
        # Low confidence always requires clarification
        if confidence < 0.5:
            return True
        
        # High-risk actions require confirmation for beginner users
        high_risk_actions = ['evolution_remove_layer', 'disable_safety', 'clear_memory']
        if (intent in high_risk_actions and 
            self.user_profile['experience_level'] == 'beginner'):
            return True
        
        # Ambiguous context might require clarification
        if (self.current_topic and 
            intent not in ['get_status', 'get_network_info'] and
            len(self.conversation_history) >= 2):
            # Check if intent matches current topic
            topic_intent_map = {
                'architecture': ['evolution_add_layer', 'evolution_remove_layer', 'get_network_info'],
                'training': ['start_training', 'stop_training', 'get_performance'],
                'research': ['research'],
                'applications': ['create_application', 'run_application']
            }
            
            if (self.current_topic in topic_intent_map and
                intent not in topic_intent_map[self.current_topic]):
                return True
        
        return False
    
    def get_context_stats(self) -> Dict[str, Any]:
        """Get statistics about context tracking."""
        return {
            'conversation_turns': len(self.conversation_history),
            'user_preferences_count': len(self.user_preferences),
            'system_state_entries': len(self.system_state),
            'recent_actions': len(self.last_actions),
            'current_topic': self.current_topic,
            'user_experience_level': self.user_profile['experience_level'],
            'interaction_style': self.user_profile['interaction_style'],
            'memory_duration_hours': self.memory_duration_hours
        }