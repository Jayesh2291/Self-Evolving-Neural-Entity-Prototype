# src/evolution/operators/add_layer.py
import torch.nn as nn
import random
from typing import Tuple, Dict, Any

class AddLayerOperator:
    """
    Evolution operator that adds new neural layers to the network.
    
    This operator increases the network's capacity by adding hidden layers,
    allowing it to learn more complex patterns.
    """
    
    def __init__(self, max_layers: int = 8, min_neurons: int = 16, max_neurons: int = 512):
        self.max_layers = max_layers
        self.min_neurons = min_neurons
        self.max_neurons = max_neurons
        self.operation_count = 0
        
        print(f"🧬 AddLayerOperator initialized (max_layers: {max_layers})")
    
    def apply(self, enn: nn.Module, context: Dict = None) -> Tuple[bool, str]:
        """
        Add a new neural layer to the network.
        
        Args:
            enn: The neural network to modify
            context: Additional context information
            
        Returns:
            success: Whether operation was successful
            message: Description of what was done
        """
        # Check if we've reached maximum layers
        if len(enn.blocks) >= self.max_layers:
            return False, f"Maximum layers ({self.max_layers}) reached"
        
        # Calculate optimal position and size for new layer
        position = self._calculate_optimal_position(enn, context)
        new_size = self._calculate_optimal_size(enn, context)
        
        # Add the new layer
        success = enn.add_block(new_size, position)
        
        if success:
            self.operation_count += 1
            message = f"Added layer at position {position} with {new_size} neurons"
            return True, message
        else:
            return False, "Failed to add layer"
    
    def _calculate_optimal_position(self, enn: nn.Module, context: Dict) -> int:
        """
        Calculate the optimal position to insert the new layer.
        
        Strategies:
        - End: For sequential capacity increase
        - Middle: For creating deeper feature hierarchies
        - Beginning: For different input processing
        """
        strategies = ['end', 'middle', 'beginning']
        strategy_weights = [0.6, 0.3, 0.1]  # Prefer end, then middle, rarely beginning
        
        strategy = random.choices(strategies, weights=strategy_weights)[0]
        
        if strategy == 'end':
            return len(enn.blocks)  # Add at the end
        elif strategy == 'middle' and len(enn.blocks) > 1:
            return random.randint(1, len(enn.blocks) - 1)  # Add in middle
        else:
            return 0  # Add at beginning
    
    def _calculate_optimal_size(self, enn: nn.Module, context: Dict) -> int:
        """
        Calculate optimal size for the new layer based on current architecture.
        """
        if not enn.blocks:
            return 64  # Default size for first hidden layer
        
        # Get current layer sizes robustly (supports AttentionBlock and Sequential)
        current_sizes = []
        for block in enn.blocks:
            if hasattr(block, 'out_features'):
                current_sizes.append(block.out_features)
            elif isinstance(block, nn.Sequential) and len(block) > 0 and hasattr(block[0], 'out_features'):
                current_sizes.append(block[0].out_features)
        if not current_sizes:
            current_sizes = [64]
        avg_size = sum(current_sizes) / len(current_sizes)
        
        # Calculate new size based on current architecture
        if context and context.get('performance', 0.5) < 0.3:
            # Low performance - try larger layer
            size_multiplier = random.uniform(1.2, 1.8)
        elif context and context.get('complexity', 0.5) > 0.8:
            # High complexity - conservative size
            size_multiplier = random.uniform(0.8, 1.2)
        else:
            # Normal case - balanced growth
            size_multiplier = random.uniform(0.9, 1.5)
        
        new_size = int(avg_size * size_multiplier)
        
        # Apply bounds
        new_size = max(self.min_neurons, min(self.max_neurons, new_size))
        
        # Round to nice numbers (16, 32, 64, 128, etc.)
        nice_sizes = [16, 32, 64, 128, 256, 512]
        closest_size = min(nice_sizes, key=lambda x: abs(x - new_size))
        
        return closest_size
    
    def get_operator_stats(self) -> Dict[str, Any]:
        """Get statistics about this operator's usage."""
        return {
            'operator_type': 'add_layer',
            'operation_count': self.operation_count,
            'max_layers': self.max_layers,
            'min_neurons': self.min_neurons,
            'max_neurons': self.max_neurons
        }