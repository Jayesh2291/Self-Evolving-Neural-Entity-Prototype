# src/core/learning/online_learner.py
import torch
import torch.nn as nn
import numpy as np
from datetime import datetime
from .replay_buffer import ReplayBuffer

class OnlineLearner:
    """
    Online learning manager for continuous learning with experience replay.
    
    Handles the training loop, loss computation, and learning updates
    for the self-evolving neural network.
    """
    
    def __init__(self, model, learning_rate=1e-3, buffer_size=10000):
        self.model = model
        self.learning_rate = learning_rate
        self.replay_buffer = ReplayBuffer(buffer_size)
        
        # Training state
        self.training_steps = 0
        self.loss_history = []
        self.performance_history = []
        
        # Optimizer
        self.optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
        
        print("🔄 Online Learner initialized")
    
    def compute_loss(self, predictions, targets, ewc_penalty=0.0):
        """
        Compute total loss including task loss and regularization.
        
        Args:
            predictions: Model predictions
            targets: Ground truth targets
            ewc_penalty: EWC regularization term
            
        Returns:
            total_loss: Combined loss value
        """
        # Task-specific loss (can be overridden for different tasks)
        if isinstance(targets, torch.LongTensor) or isinstance(targets, np.integer):
            # Classification task
            task_loss = nn.CrossEntropyLoss()(predictions, targets)
        else:
            # Regression task
            task_loss = nn.MSELoss()(predictions, targets)
        
        # Total loss with regularization
        total_loss = task_loss + ewc_penalty
        
        return total_loss
    
    def update_step(self, batch_data, ewc_object=None):
        """
        Perform a single learning update step.
        
        Args:
            batch_data: Batch of training data
            ewc_object: EWC instance for regularization
            
        Returns:
            loss_value: Computed loss for this step
        """
        # Unpack batch data (format depends on task)
        if isinstance(batch_data, (tuple, list)) and len(batch_data) == 2:
            inputs, targets = batch_data
        else:
            # Assume it's a dictionary or custom format
            inputs = batch_data.get('state', batch_data.get('input'))
            targets = batch_data.get('target', batch_data.get('action'))
        
        # Convert to tensors if needed
        if not isinstance(inputs, torch.Tensor):
            inputs = torch.FloatTensor(inputs)
        if not isinstance(targets, torch.Tensor):
            targets = torch.LongTensor(targets) if isinstance(targets, (int, np.integer)) else torch.FloatTensor(targets)
        
        # Forward pass
        self.optimizer.zero_grad()
        predictions = self.model(inputs)
        
        # Compute EWC penalty if provided
        ewc_penalty = ewc_object.compute_penalty() if ewc_object else 0.0
        
        # Compute loss
        loss = self.compute_loss(predictions, targets, ewc_penalty)
        
        # Backward pass
        loss.backward()
        
        # Gradient clipping for stability
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
        
        # Optimization step
        self.optimizer.step()
        
        # Record training progress
        self.training_steps += 1
        self.loss_history.append({
            'step': self.training_steps,
            'loss': loss.item(),
            'ewc_penalty': ewc_penalty.item() if isinstance(ewc_penalty, torch.Tensor) else ewc_penalty,
            'timestamp': datetime.now().isoformat()
        })
        
        return loss.item()
    
    def learn_from_experience(self, batch_size=32, ewc_object=None):
        """
        Learn from experiences stored in replay buffer.
        
        Args:
            batch_size: Number of experiences to sample
            ewc_object: EWC instance for preventing forgetting
            
        Returns:
            average_loss: Average loss over the batch
        """
        if len(self.replay_buffer) < batch_size:
            return 0.0
        
        # Sample batch from replay buffer
        batch = self.replay_buffer.sample(batch_size)
        
        total_loss = 0.0
        update_count = 0
        
        # Process each experience in the batch
        for experience in batch:
            loss = self.update_step(experience, ewc_object)
            total_loss += loss
            update_count += 1
        
        average_loss = total_loss / update_count if update_count > 0 else 0.0
        
        # Record performance
        self.performance_history.append({
            'step': self.training_steps,
            'average_loss': average_loss,
            'batch_size': batch_size,
            'timestamp': datetime.now().isoformat()
        })
        
        return average_loss
    
    def get_learning_stats(self):
        """Get current learning statistics"""
        recent_losses = [entry['loss'] for entry in self.loss_history[-20:]] if self.loss_history else [0]
        avg_recent_loss = sum(recent_losses) / len(recent_losses)
        
        return {
            'training_steps': self.training_steps,
            'current_learning_rate': self.optimizer.param_groups[0]['lr'],
            'replay_buffer_size': len(self.replay_buffer),
            'recent_average_loss': avg_recent_loss,
            'total_loss_records': len(self.loss_history)
        }
    
    def adjust_learning_rate(self, new_lr):
        """Dynamically adjust learning rate"""
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = new_lr
        self.learning_rate = new_lr
        print(f"📈 Learning rate adjusted to: {new_lr}")