# src/main.py
import torch
import time
import threading
import sys
import os
from typing import Dict, Any, Optional
from datetime import datetime
import traceback

# Add the current directory to Python path for direct execution
if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(__file__))

# Import all SENE components
try:
    from core import ENNCore, EWC, OnlineLearner
    from evolution.engine import EvolutionEngine
    from interaction import (
        VoiceInterface, TextToSpeech, WakeWordDetector,
        IntentRecognizer, ActionMapper, ContextTracker
    )
    from memory import ConversationMemory, DecisionLogger, ContextWindow
    from environments import CartPoleEnvironment
    from decision_engine import CollaborativeDecider, SuggestionEngine, ApprovalManager
    from utils import (
        ConfigManager, SENEConfig,
        SeneLogger, PerformanceTracker,
        SafetyMonitor,
        ModelSerializer
    )
except ImportError:
    # Try relative imports for module usage
    from .core import ENNCore, EWC, OnlineLearner
    from .evolution.engine import EvolutionEngine
    from .interaction import (
        VoiceInterface, TextToSpeech, WakeWordDetector,
        IntentRecognizer, ActionMapper, ContextTracker
    )
    from .memory import ConversationMemory, DecisionLogger, ContextWindow
    from .environments import CartPoleEnvironment
    from .decision_engine import CollaborativeDecider, SuggestionEngine, ApprovalManager
    from .utils import (
        ConfigManager, SENEConfig,
        SeneLogger, PerformanceTracker,
        SafetyMonitor,
        ModelSerializer
    )

class SelfEvolvingNeuralEntity:
    """
    Main Self-Evolving Neural Entity system class.
    
    This class integrates all SENE components into a cohesive AI system
    that can learn, evolve, and interact naturally.
    """
    
    def __init__(self, config_name: str = "balanced"):
        # Initialize configuration
        self.config_manager = ConfigManager()
        self.config = self.config_manager.load_config(config_name)
        
        # Initialize logging and monitoring
        self.logger = SeneLogger("SENE", level=self.config.log_level)
        self.performance_tracker = PerformanceTracker()
        self.safety_monitor = SafetyMonitor()
        
        # Core neural network
        self.neural_network = ENNCore(
            input_dim=self.config.input_dim,
            hidden_dims=self.config.hidden_dims,
            output_dim=self.config.output_dim,
            learning_rate=self.config.learning_rate
        )
        
        # Learning components
        self.ewc = EWC(self.neural_network)
        self.online_learner = OnlineLearner(self.neural_network)
        
        # Evolution system
        self.evolution_engine = EvolutionEngine(
            evolution_strategy=self.config.evolution_strategy
        )
        
        # Interaction system
        self.voice_interface = VoiceInterface(wake_word=self.config.wake_word)
        self.text_to_speech = TextToSpeech(
            rate=self.config.speech_rate,
            volume=self.config.speech_volume
        )
        self.wake_detector = WakeWordDetector(wake_word=self.config.wake_word)
        
        # Command processing
        self.intent_recognizer = IntentRecognizer()
        self.action_mapper = ActionMapper()
        self.context_tracker = ContextTracker()
        
        # Memory system
        self.conversation_memory = ConversationMemory(
            max_memory_size=self.config.max_conversation_memory
        )
        self.decision_logger = DecisionLogger(
            max_logs=self.config.max_decision_logs
        )
        self.context_window = ContextWindow(
            max_tokens=self.config.context_window_tokens
        )
        
        # Decision engine
        self.collaborative_decider = CollaborativeDecider()
        self.suggestion_engine = SuggestionEngine()
        self.approval_manager = ApprovalManager()
        
        # Environment
        self.environment = CartPoleEnvironment()
        
        # Serialization
        self.model_serializer = ModelSerializer()
        
        # System state
        self.is_training = False
        self.is_evolving = False
        self.system_state = {
            'performance': 0.5,
            'stability': 1.0,
            'complexity': 0.3,
            'training_episode': 0,
            'evolution_count': 0
        }
        
        # Set up callbacks
        self._setup_callbacks()
        
        # Record system startup
        self._record_system_startup()
        
        print("🚀 Self-Evolving Neural Entity Initialized!")
    
    def _setup_callbacks(self):
        """Set up system callbacks and event handlers."""
        # Voice interface callbacks
        self.voice_interface.set_command_callback(self._handle_voice_command)
        self.voice_interface.set_wake_word_callback(self._handle_wake_word)
        
        # Text-to-speech callbacks
        self.text_to_speech.set_speech_start_callback(self._handle_speech_start)
        self.text_to_speech.set_speech_end_callback(self._handle_speech_end)
        
        # Wake word detector callbacks
        self.wake_detector.set_wake_detected_callback(self._handle_wake_detection)
    
    def _record_system_startup(self):
        """Record system startup in logs and memory."""
        self.logger.info("SENE system started", config=self.config.system_name)
        
        startup_context = {
            'system': self.config.system_name,
            'version': self.config.version,
            'neural_architecture': self.neural_network.get_architecture(),
            'config': self.config_manager.get_config_info(self.config)
        }
        
        self.context_window.add_context(
            'system_startup',
            startup_context,
            importance=0.9
        )
    
    def _handle_wake_word(self, text: str):
        """Handle wake word detection."""
        self.text_to_speech.speak("Yes, I'm listening! How can I help you?")
        self.logger.info("Wake word detected", wake_word=text)
        
        # Update context
        self.context_tracker.add_conversation_turn(
            text, 
            "System awakened and ready",
            "wake_word"
        )
    
    def _handle_voice_command(self, command_text: str, audio_data=None):
        """Process voice commands from the user."""
        self.logger.info("Voice command received", command=command_text)
        
        try:
            # Recognize intent
            intent, cleaned_text, confidence = self.intent_recognizer.parse_neural_command(command_text)
            
            # Get context for decision making
            context = self.context_tracker.get_context_for_response()
            context.update(self.system_state)
            
            # Map to action
            action_spec = self.action_mapper.map_intent_to_action(intent, context)
            
            if action_spec:
                # Check if approval is required
                if action_spec.get('requires_approval', False):
                    approval_id = self.approval_manager.submit_for_approval(action_spec)
                    response = f"Action requires approval. Approval ID: {approval_id}"
                else:
                    # Execute action immediately
                    result = self._execute_action(action_spec, command_text)
                    response = result.get('response', 'Action completed')
                
                # Provide voice feedback
                self.text_to_speech.speak(response)
                
                # Update conversation memory
                self.conversation_memory.add_conversation(
                    command_text, 
                    response,
                    {
                        'intent': intent,
                        'confidence': confidence,
                        'action_type': action_spec.get('function', 'unknown')
                    }
                )
                
            else:
                # No action mapped
                response = "I'm not sure how to handle that command. Try 'help' for options."
                self.text_to_speech.speak(response)
                
        except Exception as e:
            error_msg = f"Error processing command: {str(e)}"
            self.logger.error(error_msg, command=command_text)
            self.text_to_speech.speak("Sorry, I encountered an error processing your command.")
    
    def _execute_action(self, action_spec: Dict[str, Any], original_command: str) -> Dict[str, Any]:
        """Execute a system action."""
        action_type = action_spec.get('function', 'unknown')
        parameters = action_spec.get('parameters', {})
        
        self.logger.info("Executing action", action=action_type, parameters=parameters)
        
        try:
            # Execute based on action type
            if action_type == 'add_neural_layer':
                result = self._action_add_neural_layer(parameters)
            elif action_type == 'start_training_session':
                result = self._action_start_training(parameters)
            elif action_type == 'trigger_evolution_cycle':
                result = self._action_trigger_evolution(parameters)
            elif action_type == 'get_network_information':
                result = self._action_get_network_info(parameters)
            elif action_type == 'get_system_status':
                result = self._action_get_system_status(parameters)
            elif action_type == 'emergency_stop':
                result = self._action_emergency_stop(parameters)
            else:
                result = {'success': False, 'response': f"Unknown action: {action_type}"}
            
            # Log decision and outcome
            decision_id = self.decision_logger.log_decision(
                action_type,
                action_spec,
                self.system_state
            )
            
            self.decision_logger.update_decision_outcome(decision_id, result)
            
            return result
            
        except Exception as e:
            error_result = {
                'success': False, 
                'response': f"Action failed: {str(e)}",
                'error': str(e)
            }
            self.logger.error("Action execution failed", action=action_type, error=str(e))
            return error_result
    
    def _action_add_neural_layer(self, parameters: Dict) -> Dict[str, Any]:
        """Action: Add a neural layer to the network."""
        size = parameters.get('size', 'auto')
        position = parameters.get('position', 'end')
        
        # Calculate layer size if auto
        if size == 'auto':
            current_arch = self.neural_network.get_architecture()
            if len(current_arch) >= 3:
                size = current_arch[-2]  # Use size of last hidden layer
            else:
                size = 64  # Default size
        
        # Add the layer
        success = self.neural_network.add_block(size)
        
        if success:
            # Update system state
            self.system_state['complexity'] = len(self.neural_network.get_architecture()) / 10.0
            
            response = f"Added new neural layer with {size} neurons"
            self.logger.info("Neural layer added", size=size, position=position)
            
            return {
                'success': True,
                'response': response,
                'new_architecture': self.neural_network.get_architecture(),
                'layer_size': size
            }
        else:
            return {
                'success': False,
                'response': "Failed to add neural layer"
            }
    
    def _action_start_training(self, parameters: Dict) -> Dict[str, Any]:
        """Action: Start training the neural network."""
        if self.is_training:
            return {
                'success': False,
                'response': "Training is already in progress"
            }
        
        # Start training in background thread
        self.is_training = True
        training_thread = threading.Thread(
            target=self._training_worker,
            daemon=True,
            name="TrainingWorker"
        )
        training_thread.start()
        
        response = "Starting neural network training on CartPole environment"
        self.logger.info("Training started", environment=parameters.get('environment', 'cartpole'))
        
        return {
            'success': True,
            'response': response,
            'environment': parameters.get('environment', 'cartpole')
        }
    
    def _action_trigger_evolution(self, parameters: Dict) -> Dict[str, Any]:
        """Action: Trigger neural network evolution."""
        strategy = parameters.get('strategy', 'auto')
        
        if strategy == 'auto':
            # Auto-select strategy based on performance
            if self.system_state['performance'] < 0.3:
                strategy = 'aggressive'
            elif self.system_state['performance'] > 0.8:
                strategy = 'conservative'
            else:
                strategy = 'balanced'
        
        self.evolution_engine.set_evolution_strategy(strategy)
        
        # Trigger evolution
        evolved, message = self.evolution_engine.propose_evolution(
            self.neural_network,
            self.system_state
        )
        
        if evolved:
            self.system_state['evolution_count'] += 1
            response = f"Evolution successful: {message}"
        else:
            response = f"Evolution not triggered: {message}"
        
        self.logger.info("Evolution triggered", strategy=strategy, success=evolved)
        
        return {
            'success': evolved,
            'response': response,
            'strategy': strategy,
            'evolution_count': self.system_state['evolution_count']
        }
    
    def _action_get_network_info(self, parameters: Dict) -> Dict[str, Any]:
        """Action: Get neural network information."""
        network_info = self.neural_network.get_network_info()
        
        response = (
            f"Current neural architecture: {network_info['architecture']}. "
            f"Total parameters: {network_info['total_parameters']:,}. "
            f"Hidden layers: {network_info['hidden_layers']}."
        )
        
        return {
            'success': True,
            'response': response,
            'network_info': network_info
        }
    
    def _action_get_system_status(self, parameters: Dict) -> Dict[str, Any]:
        """Action: Get system status information."""
        status_info = {
            'training': 'active' if self.is_training else 'inactive',
            'evolution_count': self.system_state['evolution_count'],
            'performance': f"{self.system_state['performance']:.2f}",
            'stability': f"{self.system_state['stability']:.2f}",
            'architecture': self.neural_network.get_architecture(),
            'parameters': self.neural_network.get_parameter_count()
        }
        
        response = (
            f"System status: Training is {status_info['training']}. "
            f"Performance: {status_info['performance']}. "
            f"Evolution steps: {status_info['evolution_count']}. "
            f"Network parameters: {status_info['parameters']:,}."
        )
        
        return {
            'success': True,
            'response': response,
            'status_info': status_info
        }
    
    def _action_emergency_stop(self, parameters: Dict) -> Dict[str, Any]:
        """Action: Emergency stop all operations."""
        self.is_training = False
        self.is_evolving = False
        
        # Stop voice interface
        self.voice_interface.stop_listening()
        self.wake_detector.stop_listening()
        
        response = "Emergency stop activated. All operations halted."
        self.logger.critical("Emergency stop activated", level=parameters.get('level', 'immediate'))
        
        return {
            'success': True,
            'response': response,
            'operations_stopped': ['training', 'evolution', 'voice_listening']
        }
    
    def _training_worker(self):
        """Background worker for training the neural network."""
        self.logger.info("Training worker started")
        
        try:
            episode = 0
            while self.is_training and episode < self.config.training_episodes:
                # Training logic here
                state = self.environment.reset()
                total_reward = 0
                done = False
                
                while not done and self.is_training:
                    # Ensure correct tensor type/shape (batch, features)
                    if isinstance(state, torch.Tensor):
                        state_tensor = state.to(dtype=torch.float32)
                    else:
                        state_tensor = torch.tensor(state, dtype=torch.float32)
                    if state_tensor.ndim == 1:
                        state_tensor = state_tensor.unsqueeze(0)

                    # Neural network decision
                    with torch.no_grad():
                        q_values = self.neural_network(state_tensor)
                        action = torch.argmax(q_values, dim=1).item()
                    
                    # Environment step
                    next_state, reward, done, _ = self.environment.step(action)
                    total_reward += reward
                    
                    # Store experience
                    self.neural_network.store_experience(state, action, reward, next_state, done)
                    
                    # Learn from experience
                    loss = self.neural_network.update()
                    
                    state = next_state
                    
                    # Brief pause to prevent excessive CPU usage
                    time.sleep(0.01)
                
                # Update system state
                self.system_state['training_episode'] = episode
                self.system_state['performance'] = min(1.0, total_reward / 500.0)  # Normalize
                
                # Log progress
                if episode % 100 == 0:
                    self.logger.info("Training progress", 
                                   episode=episode, 
                                   reward=total_reward,
                                   performance=self.system_state['performance'])
                
                episode += 1
                
                # Check for evolution opportunity
                if episode % 50 == 0:
                    self._check_evolution_opportunity()
            
            self.is_training = False
            self.logger.info("Training completed", total_episodes=episode)
            
        except Exception as e:
            self.logger.error("Training worker error", error=str(e), stack=traceback.format_exc())
            self.is_training = False
    
    def _check_evolution_opportunity(self):
        """Check if evolution should be triggered based on performance."""
        if self.system_state['performance'] < 0.3:
            # Low performance - try evolution
            evolved, message = self.evolution_engine.propose_evolution(
                self.neural_network,
                self.system_state
            )
            
            if evolved:
                self.system_state['evolution_count'] += 1
                self.logger.info("Auto-evolution triggered", evolution_message=message)
    
    def _handle_speech_start(self, name: str):
        """Handle speech start event."""
        self.logger.debug("Speech started", utterance=name)
    
    def _handle_speech_end(self, name: str, completed: bool):
        """Handle speech end event."""
        self.logger.debug("Speech ended", utterance=name, completed=completed)
    
    def _handle_wake_detection(self, detection_info: Dict):
        """Handle wake word detection from dedicated detector."""
        # Make the STT interface accept commands immediately after wake event
        try:
            self.voice_interface.is_awake = True
        except Exception:
            pass
        self.text_to_speech.speak("I'm listening, what would you like me to do?")
    
    def start_system(self):
        """Start the complete SENE system."""
        self.logger.info("Starting complete SENE system")
        
        # Start voice interaction
        self.voice_interface.start_listening()
        self.wake_detector.start_listening()
        
        # Initialize context
        self.context_window.set_active_context('system_ready', True)
        
        print("=" * 60)
        print("🚀 SENE SYSTEM ACTIVE")
        print("=" * 60)
        print("Voice commands enabled!")
        print("Say 'SENE' to wake up, then try:")
        print("  • 'Add a neural layer'")
        print("  • 'Start training'") 
        print("  • 'Evolve the network'")
        print("  • 'Show network architecture'")
        print("  • 'System status'")
        print("  • 'Stop' (emergency stop)")
        print("=" * 60)
        
        # Provide voice greeting
        self.text_to_speech.speak(
            "Self Evolving Neural Entity system activated. "
            "Say SENE to wake me up and give commands."
        )
    
    def stop_system(self):
        """Stop the SENE system gracefully."""
        self.logger.info("Stopping SENE system")
        
        # Stop all operations
        self.is_training = False
        self.is_evolving = False
        
        # Stop voice interfaces
        self.voice_interface.stop_listening()
        self.wake_detector.stop_listening()
        
        # Save checkpoints and logs
        self.model_serializer.save_checkpoint(
            self.neural_network,
            training_state=self.system_state,
            metadata={'shutdown': True, 'timestamp': datetime.now().isoformat()}
        )
        
        self.logger.export_logs("sene_shutdown_logs.json")
        
        print("✅ SENE system stopped gracefully")
    
    def process_command(self, command_text: str) -> str:
        self.logger.info("Text command received", command=command_text)
        try:
            intent, cleaned_text, confidence = self.intent_recognizer.parse_neural_command(command_text)
            context = self.context_tracker.get_context_for_response()
            context.update(self.system_state)
            action_spec = self.action_mapper.map_intent_to_action(intent, context)
            if action_spec:
                if action_spec.get('requires_approval', False):
                    approval_id = self.approval_manager.submit_for_approval(action_spec)
                    response = f"Action requires approval. Approval ID: {approval_id}"
                else:
                    result = self._execute_action(action_spec, command_text)
                    response = result.get('response', 'Action completed')
                self.conversation_memory.add_conversation(
                    command_text,
                    response,
                    {
                        'intent': intent,
                        'confidence': confidence,
                        'action_type': action_spec.get('function', 'unknown')
                    }
                )
            else:
                response = "I'm not sure how to handle that command. Try 'help' for options."
            return response
        except Exception as e:
            error_msg = f"Error processing command: {str(e)}"
            self.logger.error(error_msg, command=command_text)
            return "Error: failed to process command."

    def start_text_cli(self):
        print("=" * 60)
        print("🧠 SENE TEXT MODE ACTIVE")
        print("Type commands like:")
        print("  - add a neural layer")
        print("  - start training")
        print("  - evolve the network")
        print("  - show network architecture")
        print("  - system status")
        print("Type 'exit' or 'quit' to leave.")
        print("=" * 60)
        try:
            while True:
                try:
                    cmd = input("sene> ").strip()
                except EOFError:
                    break
                if not cmd:
                    continue
                low = cmd.lower()
                if low in ("exit", "quit"):
                    break
                resp = self.process_command(cmd)
                print(resp)
        finally:
            pass

    def get_system_report(self) -> Dict[str, Any]:
        """Get comprehensive system report."""
        return {
            'system': {
                'name': self.config.system_name,
                'version': self.config.version,
                'status': 'active' if self.is_training else 'ready',
                'uptime': 'N/A'  # Could track actual uptime
            },
            'neural_network': self.neural_network.get_network_info(),
            'training': {
                'active': self.is_training,
                'episode': self.system_state['training_episode'],
                'performance': self.system_state['performance']
            },
            'evolution': {
                'count': self.system_state['evolution_count'],
                'strategy': self.evolution_engine.evolution_strategy
            },
            'memory': {
                'conversations': len(self.conversation_memory.conversations),
                'decisions': self.decision_logger.analytics['total_decisions'],
                'context_items': len(self.context_window.context_items)
            },
            'safety': self.safety_monitor.get_safety_report(),
            'performance': self.performance_tracker.get_performance_report()
        }


# Convenience function for quick startup
def create_sene_system(config_name: str = "balanced"):
    """
    Create and initialize a complete SENE system.
    
    Args:
        config_name: Configuration preset name
        
    Returns:
        sene_system: Initialized SENE system
    """
    return SelfEvolvingNeuralEntity(config_name)


# Demo and test function
def demo_sene_system():
    """Run a demonstration of the SENE system."""
    print("🧠 SENE System Demonstration")
    print("=" * 50)
    
    # Create system
    sene = create_sene_system("balanced")
    
    # Show initial state
    report = sene.get_system_report()
    print("Initial System State:")
    print(f"  Architecture: {report['neural_network']['architecture']}")
    print(f"  Parameters: {report['neural_network']['total_parameters']:,}")
    print(f"  Evolution Strategy: {report['evolution']['strategy']}")
    
    # Demo some actions
    print("\nDemo Actions:")
    
    # Add a layer
    result = sene._action_add_neural_layer({'size': 128})
    if result['success']:
        print(f"✅ Added layer: {result['new_architecture']}")
    
    # Get network info
    result = sene._action_get_network_info({})
    if result['success']:
        print(f"✅ Network info: {result['response']}")
    
    # Trigger evolution
    result = sene._action_trigger_evolution({'strategy': 'balanced'})
    print(f"✅ Evolution: {result['response']}")
    
    print("\n🎯 Demonstration completed!")
    print("Use sene.start_system() to begin voice interaction")


if __name__ == "__main__":
    # Run demonstration when executed directly
    demo_sene_system()