# src/decision_engine/collaborative_decider.py
import torch
import numpy as np
from datetime import datetime
from typing import Dict, List, Any, Tuple
import json

class CollaborativeDecider:
    """
    Main collaborative decision maker that orchestrates between human preferences
    and AI suggestions for neural network evolution.
    """
    
    def __init__(self, safety_threshold=0.7, human_preference_weight=0.6):
        self.safety_threshold = safety_threshold
        self.human_preference_weight = human_preference_weight
        
        # Decision history and user preferences
        self.decision_history = []
        self.user_preferences = {
            'risk_tolerance': 'medium',  # low, medium, high
            'preferred_architecture': 'balanced',  # simple, balanced, complex
            'evolution_pace': 'moderate',  # slow, moderate, aggressive
            'safety_priority': 'high'
        }
        
        # Performance tracking
        self.performance_metrics = {
            'successful_evolutions': 0,
            'failed_evolutions': 0,
            'human_overrides': 0,
            'average_confidence': 0.0
        }
        
        print("🤖 Collaborative Decider initialized")
    
    def evaluate_evolution_proposal(self, proposal: Dict, current_state: Dict) -> Tuple[bool, str, float]:
        """
        Evaluate an evolution proposal considering safety and user preferences.
        
        Args:
            proposal: Evolution proposal from suggestion engine
            current_state: Current system state
            
        Returns:
            approved: Whether proposal should proceed
            reasoning: Explanation for decision
            confidence: Confidence score (0-1)
        """
        # Extract proposal details
        proposal_type = proposal.get('type', 'unknown')
        risk_level = proposal.get('risk_level', 'medium')
        expected_benefit = proposal.get('expected_benefit', 0.0)
        complexity_change = proposal.get('complexity_change', 0.0)
        
        # Calculate approval score
        safety_score = self._calculate_safety_score(proposal, current_state)
        preference_score = self._calculate_preference_score(proposal)
        benefit_score = self._calculate_benefit_score(proposal)
        
        # Weighted decision score
        decision_score = (
            safety_score * 0.4 +
            preference_score * 0.3 +
            benefit_score * 0.3
        )
        
        # Determine approval
        approved = decision_score >= self.safety_threshold
        confidence = min(decision_score, 1.0)
        
        # Generate reasoning
        reasoning = self._generate_decision_reasoning(
            approved, safety_score, preference_score, benefit_score, proposal
        )
        
        # Record decision
        self._record_decision(proposal, approved, decision_score, reasoning)
        
        return approved, reasoning, confidence
    
    def _calculate_safety_score(self, proposal: Dict, current_state: Dict) -> float:
        """Calculate safety score for a proposal (0-1)"""
        risk_levels = {'low': 0.9, 'medium': 0.7, 'high': 0.4, 'critical': 0.1}
        base_risk = risk_levels.get(proposal.get('risk_level', 'medium'), 0.5)
        
        # Adjust based on current system stability
        system_stability = current_state.get('stability', 1.0)
        stability_factor = min(system_stability, 1.0)
        
        # Adjust based on rollback capability
        has_rollback = current_state.get('has_rollback', True)
        rollback_factor = 0.9 if has_rollback else 0.5
        
        safety_score = base_risk * stability_factor * rollback_factor
        return safety_score
    
    def _calculate_preference_score(self, proposal: Dict) -> float:
        """Calculate how well proposal aligns with user preferences (0-1)"""
        score = 0.5  # Neutral starting point
        
        # Check architecture preferences
        if self.user_preferences['preferred_architecture'] == 'simple':
            if proposal.get('complexity_change', 0) <= 0:
                score += 0.3
            else:
                score -= 0.2
        elif self.user_preferences['preferred_architecture'] == 'complex':
            if proposal.get('complexity_change', 0) >= 0:
                score += 0.3
            else:
                score -= 0.2
        
        # Check risk tolerance
        user_risk = self.user_preferences['risk_tolerance']
        proposal_risk = proposal.get('risk_level', 'medium')
        
        risk_mapping = {'low': 0, 'medium': 1, 'high': 2}
        user_risk_val = risk_mapping.get(user_risk, 1)
        proposal_risk_val = risk_mapping.get(proposal_risk, 1)
        
        risk_diff = abs(user_risk_val - proposal_risk_val)
        score -= risk_diff * 0.15
        
        return max(0.0, min(1.0, score))
    
    def _calculate_benefit_score(self, proposal: Dict) -> float:
        """Calculate expected benefit score (0-1)"""
        expected_benefit = proposal.get('expected_benefit', 0.0)
        benefit_confidence = proposal.get('benefit_confidence', 0.5)
        
        # Normalize benefit to 0-1 range (assuming benefits are typically 0-100% improvement)
        normalized_benefit = min(expected_benefit / 100.0, 1.0)
        
        # Combine benefit and confidence
        benefit_score = normalized_benefit * benefit_confidence
        return benefit_score
    
    def _generate_decision_reasoning(self, approved: bool, safety: float, 
                                   preference: float, benefit: float, proposal: Dict) -> str:
        """Generate human-readable reasoning for decision"""
        if approved:
            reasons = []
            if safety > 0.8:
                reasons.append("high safety confidence")
            if preference > 0.7:
                reasons.append("aligns well with your preferences")
            if benefit > 0.6:
                reasons.append("significant expected benefits")
            
            if reasons:
                reason_text = ", ".join(reasons)
                return f"Approved: {reason_text}"
            else:
                return "Approved: balanced overall assessment"
        else:
            issues = []
            if safety < 0.5:
                issues.append("safety concerns")
            if preference < 0.4:
                issues.append("conflicts with your preferences")
            if benefit < 0.3:
                issues.append("limited expected benefits")
            
            if issues:
                issue_text = ", ".join(issues)
                return f"Rejected: {issue_text}"
            else:
                return "Rejected: overall risk too high"
    
    def _record_decision(self, proposal: Dict, approved: bool, score: float, reasoning: str):
        """Record decision in history"""
        decision_record = {
            'timestamp': datetime.now().isoformat(),
            'proposal_type': proposal.get('type', 'unknown'),
            'approved': approved,
            'decision_score': score,
            'reasoning': reasoning,
            'proposal_details': {
                'risk_level': proposal.get('risk_level'),
                'expected_benefit': proposal.get('expected_benefit'),
                'complexity_change': proposal.get('complexity_change')
            }
        }
        
        self.decision_history.append(decision_record)
        
        # Update performance metrics
        if approved:
            self.performance_metrics['successful_evolutions'] += 1
        else:
            self.performance_metrics['failed_evolutions'] += 1
        
        # Keep only last 1000 decisions
        if len(self.decision_history) > 1000:
            self.decision_history = self.decision_history[-1000:]
    
    def update_user_preferences(self, new_preferences: Dict):
        """Update user preferences based on feedback"""
        self.user_preferences.update(new_preferences)
        print("✅ User preferences updated")
    
    def get_decision_stats(self) -> Dict:
        """Get decision engine statistics"""
        total_decisions = len(self.decision_history)
        approval_rate = (self.performance_metrics['successful_evolutions'] / total_decisions * 100) if total_decisions > 0 else 0
        
        return {
            'total_decisions': total_decisions,
            'approval_rate': f"{approval_rate:.1f}%",
            'successful_evolutions': self.performance_metrics['successful_evolutions'],
            'failed_evolutions': self.performance_metrics['failed_evolutions'],
            'human_overrides': self.performance_metrics['human_overrides'],
            'safety_threshold': self.safety_threshold,
            'user_preferences': self.user_preferences
        }
    
    def learn_from_feedback(self, decision_id: int, was_correct: bool, feedback: str = ""):
        """Learn from human feedback on decisions"""
        if 0 <= decision_id < len(self.decision_history):
            decision = self.decision_history[decision_id]
            decision['feedback'] = {
                'was_correct': was_correct,
                'user_feedback': feedback,
                'feedback_timestamp': datetime.now().isoformat()
            }
            
            # Adjust safety threshold based on feedback
            if was_correct and decision['approved']:
                # Good approval decision
                self.safety_threshold = min(0.9, self.safety_threshold + 0.01)
            elif not was_correct and decision['approved']:
                # Bad approval decision
                self.safety_threshold = max(0.3, self.safety_threshold - 0.02)
            
            print(f"📚 Learned from feedback: safety threshold adjusted to {self.safety_threshold:.3f}")