# src/utils/serialization.py
import torch
import pickle
import json
import yaml
from typing import Dict, Any, Optional
from pathlib import Path
from datetime import datetime
import hashlib

class ModelSerializer:
    """
    Advanced model serialization for saving and loading SENE states.
    
    Provides comprehensive serialization capabilities including
    model checkpoints, training states, and configuration preservation.
    """
    
    def __init__(self, checkpoint_dir: str = "checkpoints"):
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(exist_ok=True)
        
        self.checkpoint_history = []
        self.max_checkpoints = 20
        
        print(f"💾 Model Serializer initialized (checkpoint dir: {self.checkpoint_dir})")
    
    def save_checkpoint(self, model, optimizer=None, scheduler=None, 
                       training_state: Dict[str, Any] = None, 
                       metadata: Dict[str, Any] = None) -> str:
        """
        Save a comprehensive model checkpoint.
        
        Args:
            model: Neural network model to save
            optimizer: Optimizer state
            scheduler: Learning rate scheduler state
            training_state: Additional training state information
            metadata: Additional metadata
            
        Returns:
            checkpoint_path: Path to the saved checkpoint
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        checkpoint_name = f"checkpoint_{timestamp}.pt"
        checkpoint_path = self.checkpoint_dir / checkpoint_name
        
        # Prepare checkpoint data
        checkpoint_data = {
            'model_state_dict': model.state_dict(),
            'model_architecture': getattr(model, 'get_architecture', lambda: 'unknown')(),
            'timestamp': timestamp,
            'version': '1.0'
        }
        
        # Add optimizer state if provided
        if optimizer is not None:
            checkpoint_data['optimizer_state_dict'] = optimizer.state_dict()
        
        # Add scheduler state if provided
        if scheduler is not None:
            checkpoint_data['scheduler_state_dict'] = scheduler.state_dict()
        
        # Add training state
        if training_state is not None:
            checkpoint_data['training_state'] = training_state
        
        # Add metadata
        if metadata is not None:
            checkpoint_data['metadata'] = metadata
        
        # Add model-specific information
        if hasattr(model, 'get_network_info'):
            checkpoint_data['model_info'] = model.get_network_info()
        
        # Save checkpoint
        torch.save(checkpoint_data, checkpoint_path)
        
        # Record checkpoint
        checkpoint_record = {
            'path': str(checkpoint_path),
            'timestamp': timestamp,
            'size_mb': checkpoint_path.stat().st_size / 1024 / 1024,
            'model_architecture': checkpoint_data.get('model_architecture', 'unknown')
        }
        
        self.checkpoint_history.append(checkpoint_record)
        
        # Clean up old checkpoints
        self._cleanup_old_checkpoints()
        
        print(f"✅ Checkpoint saved: {checkpoint_path} ({checkpoint_record['size_mb']:.1f} MB)")
        return str(checkpoint_path)
    
    def load_checkpoint(self, checkpoint_path: str, model=None, 
                       optimizer=None, scheduler=None) -> Dict[str, Any]:
        """
        Load a model checkpoint.
        
        Args:
            checkpoint_path: Path to the checkpoint file
            model: Model to load state into (optional)
            optimizer: Optimizer to load state into (optional)
            scheduler: Scheduler to load state into (optional)
            
        Returns:
            checkpoint_data: Loaded checkpoint data
        """
        checkpoint_path = Path(checkpoint_path)
        
        if not checkpoint_path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
        
        try:
            checkpoint_data = torch.load(checkpoint_path, map_location='cpu')
            
            # Load model state
            if model is not None and 'model_state_dict' in checkpoint_data:
                model.load_state_dict(checkpoint_data['model_state_dict'])
                print("✅ Model state loaded")
            
            # Load optimizer state
            if optimizer is not None and 'optimizer_state_dict' in checkpoint_data:
                optimizer.load_state_dict(checkpoint_data['optimizer_state_dict'])
                print("✅ Optimizer state loaded")
            
            # Load scheduler state
            if scheduler is not None and 'scheduler_state_dict' in checkpoint_data:
                scheduler.load_state_dict(checkpoint_data['scheduler_state_dict'])
                print("✅ Scheduler state loaded")
            
            print(f"✅ Checkpoint loaded: {checkpoint_path}")
            return checkpoint_data
            
        except Exception as e:
            print(f"❌ Error loading checkpoint: {e}")
            raise
    
    def _cleanup_old_checkpoints(self):
        """Remove old checkpoints to save disk space."""
        if len(self.checkpoint_history) <= self.max_checkpoints:
            return
        
        # Sort by timestamp (oldest first)
        self.checkpoint_history.sort(key=lambda x: x['timestamp'])
        
        # Remove oldest checkpoints
        while len(self.checkpoint_history) > self.max_checkpoints:
            old_checkpoint = self.checkpoint_history.pop(0)
            old_path = Path(old_checkpoint['path'])
            
            if old_path.exists():
                old_path.unlink()
                print(f"🗑️  Removed old checkpoint: {old_path}")
    
    def create_rollback_point(self, model, description: str = "") -> str:
        """
        Create a quick rollback point for safety.
        
        Args:
            model: Model to save
            description: Description of the rollback point
            
        Returns:
            rollback_id: ID of the created rollback point
        """
        rollback_id = f"rollback_{datetime.now().strftime('%H%M%S')}"
        rollback_path = self.checkpoint_dir / f"{rollback_id}.pt"
        
        rollback_data = {
            'model_state_dict': model.state_dict(),
            'timestamp': datetime.now().isoformat(),
            'description': description,
            'type': 'rollback'
        }
        
        torch.save(rollback_data, rollback_path)
        
        print(f"🔄 Rollback point created: {rollback_id}")
        return rollback_id
    
    def list_checkpoints(self) -> list:
        """List all available checkpoints."""
        checkpoint_files = list(self.checkpoint_dir.glob("*.pt"))
        checkpoints = []
        
        for checkpoint_file in checkpoint_files:
            try:
                # Load minimal data to get info
                checkpoint_data = torch.load(checkpoint_file, map_location='cpu')
                checkpoints.append({
                    'path': str(checkpoint_file),
                    'timestamp': checkpoint_data.get('timestamp', 'unknown'),
                    'size_mb': checkpoint_file.stat().st_size / 1024 / 1024,
                    'type': checkpoint_data.get('type', 'checkpoint'),
                    'description': checkpoint_data.get('description', '')
                })
            except:
                # Skip corrupted checkpoints
                continue
        
        return sorted(checkpoints, key=lambda x: x['timestamp'], reverse=True)
    
    def export_model(self, model, export_path: str, format: str = 'torch') -> bool:
        """
        Export model in various formats.
        
        Args:
            model: Model to export
            export_path: Export file path
            format: Export format ('torch', 'onnx')
            
        Returns:
            success: Whether export was successful
        """
        try:
            if format == 'torch':
                torch.save(model.state_dict(), export_path)
            elif format == 'onnx':
                # This would require proper input sample for ONNX export
                # For now, just save as torch
                torch.save(model.state_dict(), export_path)
            else:
                print(f"❌ Unsupported export format: {format}")
                return False
            
            print(f"📤 Model exported to: {export_path} ({format})")
            return True
            
        except Exception as e:
            print(f"❌ Export failed: {e}")
            return False

class DataSerializer:
    """
    Data serialization utilities for SENE system data.
    """
    
    @staticmethod
    def save_data(data: Any, filepath: str, format: str = 'pickle') -> bool:
        """
        Save data to file in specified format.
        
        Args:
            data: Data to save
            filepath: Output file path
            format: Serialization format ('pickle', 'json', 'yaml')
            
        Returns:
            success: Whether save was successful
        """
        try:
            if format == 'pickle':
                with open(filepath, 'wb') as f:
                    pickle.dump(data, f)
            elif format == 'json':
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
            elif format == 'yaml':
                with open(filepath, 'w', encoding='utf-8') as f:
                    yaml.dump(data, f, default_flow_style=False, indent=2)
            else:
                print(f"❌ Unsupported format: {format}")
                return False
            
            print(f"💾 Data saved: {filepath} ({format})")
            return True
            
        except Exception as e:
            print(f"❌ Data save failed: {e}")
            return False
    
    @staticmethod
    def load_data(filepath: str, format: str = 'pickle') -> Any:
        """
        Load data from file.
        
        Args:
            filepath: Input file path
            format: Serialization format
            
        Returns:
            data: Loaded data
        """
        try:
            if format == 'pickle':
                with open(filepath, 'rb') as f:
                    return pickle.load(f)
            elif format == 'json':
                with open(filepath, 'r', encoding='utf-8') as f:
                    return json.load(f)
            elif format == 'yaml':
                with open(filepath, 'r', encoding='utf-8') as f:
                    return yaml.safe_load(f)
            else:
                print(f"❌ Unsupported format: {format}")
                return None
                
        except Exception as e:
            print(f"❌ Data load failed: {e}")
            return None
    
    @staticmethod
    def calculate_data_hash(data: Any) -> str:
        """
        Calculate hash of data for integrity checking.
        
        Args:
            data: Data to hash
            
        Returns:
            hash: MD5 hash of the data
        """
        data_bytes = pickle.dumps(data)
        return hashlib.md5(data_bytes).hexdigest()